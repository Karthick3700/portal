"use strict";
module.exports = function (mongoose, utils, config, constants) {
  const Schema = mongoose.Schema;
  const ObjectId = Schema.ObjectId;
  // const autoIncrement = require('mongoose-auto-increment');

  let schema = new Schema(
    {
      userId: {
        type: String,
        required: true,
      },
      firstName: String,
      lastName: String,
      email: {
        type: String,
        index: { unique: true },
        required: true,
      },
      phoneCode: {
        type: String,
        default: "91"
      },
      phone: {
        type: String,
        index: { unique: true },
        required: true,
      },
      role: {
        type: Number,
        enum: Object.values(constants.roles)
      },
      status: {
        type: Number,
        enum: Object.values(constants.userStatus),
        default: constants.userStatus.IN_ACTIVE,
      },
      pwd: {
        type: String,
        select: false,
      },
      salt: {
        type: String,
        select: false,
      },
      resetpwdToken: String,
      resetpwdExpires: Date,
      emailVerified: {
        type: Boolean,
        default: false,
      },
      phoneVerified: {
        type: Boolean,
        default: false,
      },
      otpSecretKey: String
    },
    {
      timestamps: true,
      versionKey: false,
    }
  );

  schema = require("./index.js")(schema, mongoose, utils);

  schema.pre("save", function (next) {
    if (this.pwd && this.isModified("pwd")) {
      this.salt = utils.generateRandomSalt();
      this.pwd = utils.hashPassword(this.pwd, this.salt);
    }
    next();
  });

  schema.index({ email: 1 });
  schema.index({ phone: 1 });

  return mongoose.model("User", schema);
};
