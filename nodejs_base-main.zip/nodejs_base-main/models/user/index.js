/* eslint-disable no-useless-catch */
"use strict";

module.exports = function (schema) {
  schema.statics.addUser = async function (userData) {
    try {
      let self = this;
      let user = new self(userData);
      await user.save();
      return user;
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  schema.statics.getAllUsers = async function () {
    try {
      let self = this;
      let users = await self.find({});
      return users;
    } catch (err) {
      throw err;
    }
  };

  schema.statics.getUserByType = async function (type) {
    try {
      let self = this;
      let user = await self.find({type: type});
      return user;
    } catch (err) {
      throw err;
    }
  };

  schema.statics.getUserById = async function (id) {
    try {
      let self = this;
      return await self.findOne({_id: id}).lean();
    } catch (err) {
      throw err;
    }
  };

  schema.statics.getUser = async function (query, opts) {
    let self = this;
    let data = await self.findOne(query, {}, opts).lean();
    return data;
  };

  schema.statics.updateUser = async function (userData, id) {
    try {
      let self = this;
      let response = await self.findOneAndUpdate({_id: id}, {$set: userData}, {new: true});
      return response;
    } catch (err) {
      throw err;
    }
  };

  schema.statics.getUserWhoResetPwd = async function (token) {
    try {
      let self = this;
      let query = {};
      query.resetpwdToken = token;
      query.resetpwdExpires = {
        $gt: Date.now(),
      };
      let user = await self.findOne(query);
      return user;
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  return schema;
};
