"use strict";
const mongoose = require("mongoose");
const UserModel = mongoose.model("User");
const config = require("./../configs/config");
const utils = require("./../utils/util");
const jwt = require("jsonwebtoken");
const _ = require("lodash");

module.exports = function () {
  const authenticate = {};

  authenticate.validateToken = async (req, res, next) => {
    let { authorization } = req.headers;
    if (!authorization) {
      return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
    }
    let token = authorization.split(" ")[1];
    if (!token) {
      return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
    }
    jwt.verify(token, config.SERVER_SECRET, async (err, decoded) => {
      if (err) {
        if (err.message === "jwt expired") {
          return utils.sendResponseNew(req, res, "BAD_REQUEST", "INVALID_TOKEN", null, null, "INVALID_TOKEN");
        }
        return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
      }
      let user = await UserModel.findOne({
        _id: decoded._id,
      });
      if (!user) {
        return utils.sendResponseNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }
      req.userInfo = user;
      return next();
    });
  };

  authenticate.checkToken = async (req, res, next) => {
    let { authorization } = req.headers;
    if (!authorization) {
      return next();
    } else {
      authenticate.validateToken(req, res, next);
    }
  };

  authenticate.validateAdminToken = async (req, res, next) => {
    let { authorization } = req.headers;
    if (!authorization) {
      return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
    }
    let token = authorization.split(" ")[1];
    if (!token) {
      return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
    }
    jwt.verify(token, config.SERVER_SECRET, async (err, decoded) => {
      if (err) {
        console.log(err)
        return utils.sendResponseNew(req, res, "UNAUTHORIZED", "UNAUTHORIZED_REQUEST");
      }
      let user = await UserModel.findOne({ _id: decoded._id }); //, role: constants.roles.SUPERADMIN
      if (!user) {
        return utils.sendResponseNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }
      req.userInfo = user;

      return next();
    });
  };

  authenticate.isValidToken = async (req, res) => {
    try {
      let { authorization } = req.headers;
      if (authorization) {
        let token = authorization.split(" ")[1];
        let user = await utils.verifyToken(token);
        if (!_.isEmpty(user)) {
          return utils.sendResponseNew(req, res, "OK", "SUCCESS");
        }
      }
      return utils.sendResponseNew(req, res, "BAD_REQUEST", "INVALID_USER");
    } catch (err) {
      console.error(err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  authenticate.addUserInfo = async (req, res, next) => {
    let { authorization } = req.headers;
    if (!authorization) {
      return utils.sendResponse(req, res, "NOT_AUTHERIZED", {}, "UNAUTHORIZED_REQUEST", "NOT_AUTHERIZED");
    }
    let token = authorization.split(" ")[1];
    if (!token) {
      return utils.sendResponse(req, res, "NOT_AUTHERIZED", {}, "UNAUTHORIZED_REQUEST", "NOT_AUTHERIZED");
    }
    jwt.verify(token, config.SERVER_SECRET, async (err) => {
      if (err) {
        return utils.sendResponse(req, res, "NOT_AUTHERIZED", {}, "UNAUTHORIZED_REQUEST", "NOT_AUTHERIZED");
      }
      let { userid } = req.headers;
      let user = await UserModel.findOne({ userId: userid });
      if (!user) {
        return utils.sendResponse(req, res, "BAD_REQUEST", {}, "INVALID_USER", "BAD_REQUEST");
      }
      req.info = user;
      return next();
    });
  };

  return authenticate;
};
