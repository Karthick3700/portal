"use strict";

module.exports = function (mongoose, utils, config, constants, upload, ac) {
  const ctrl = {};
  const { totp } = require("otplib");
  const { moment, lodash } = utils;
  const User = mongoose.model("User");
  const userSer = require("../services/user")(mongoose, utils, config, constants, upload, ac);
  // const emailSer = require("../services/email");
  const { userStatus: userStatus, loginType: loginType } = constants;
  // const { ADMIN, DISTRIBUTER, RETAILER, CUSTOMER } = constants.roles;
  const { ACTIVE, IN_ACTIVE, DELETED } = userStatus;
  const { OTP } = loginType;

  ctrl.register = async (req, res) => {
    try {
      //Payload for verificatoin
      let { email, phone } = req.body;


      // Check the Given email or Phone Number Already Exists or Not
      let exists = await User.findOne({
        $or: [{ email }, { phone }],
      });

      // if Email or Phone Number Already Exists Throw Error
      if (exists) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "USER_EXISTS");
      }
      let user = await userSer.registerUser(req.body);
      let activateToken = utils.generateActivateToken({ phone: user.phone, email: user.email, id: user._id }, true);
      let inviteLink = config.webHost + "/activate?token=" + activateToken;
      let context = {
        name: user.name,
        userId: user.userId,
        phone: user.phone,
        inviteLink,
      };
      console.log("email-context::", context);
      // emailSer.sendRegisterMail(user.email, context);
      return utils.sendResponseNew(req, res, "OK", "USER_REG_SUCC", { ...user, activateToken });
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.isValid = async (req, res) => {
    try {
      let { email, phone } = req.body;
      let payload;

      if (email) {
        payload = { email };
      }
      if (phone) {
        payload = { phone };
      }
      let exists = await User.findOne(payload);
      return utils.sendResponseNew(req, res, "OK", "SUCCESS", exists ? true : false);
    } catch (err) {
      console.error(err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.activate = async (req, res) => {
    try {
      const { token } = req.body;
      const userObj = await utils.verifyToken(token);
      let user = await User.findOne({ _id: userObj.id });
      if (!lodash.isEmpty(user)) {
        user.status = ACTIVE;
        user.emailVerified = true;
        await User.updateUser(user, user._id);
        return utils.sendResponseNew(req, res, "OK", "USER_ACTIVATED_SUCC", {});
      } else {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.login = async (req, res) => {
    try {
      let { email, phone, pwd, loginType, otp } = req.body;
      let findInActObj = {};
      if (email) {
        findInActObj = { email, status: { $in: [IN_ACTIVE, DELETED] } };
      } else {
        findInActObj = { phone, status: { $in: [IN_ACTIVE, DELETED] } };
      }
      let [isUserNotActivated, emailValidation] = await Promise.all([
        User.findOne(findInActObj).lean(),
        User.findOne({ email }).select("salt pwd otpSecretKey role").lean(),
      ]);
      if (isUserNotActivated !== null) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "ACC_NOT_ACTIVATED");
      };
      if (email && !emailValidation) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_EMAIL");
      };
      if (emailValidation && emailValidation.pwd !== utils.hashPassword(pwd, emailValidation.salt)) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_PASS");
      }
      let findObj = {};
      if (email) {
        findObj = { email, status: ACTIVE };
      } else {
        findObj = { phone, status: ACTIVE };
      }
      let user = await User.findOne(findObj).select("salt pwd otpSecretKey role").lean();
      // if (user.role !== CUSTOMER) {
      //   return utils.sendErrorNew(req, res, "BAD_REQUEST", "NOT_CUSTOMER")
      // }
      if (loginType === OTP) {
        let secret = user.otpSecretKey;
        let isValid = totp.check(otp, secret);
        if (!isValid) {
          return utils.sendErrorNew(req, res, "BAD_REQUEST", "OTP_EXPIRED");
        }
        let token = utils.generateToken(user);
        let refreshToken = utils.generateRefreshToken({ _id: user._id, isRefresh: true });
        user = await User.findOne({ _id: user._id }, { resetpwdExpires: 0, resetpwdToken: 0, __v: 0 }).lean();
        return utils.sendResponseNew(req, res, "OK", "USER_LOGGED_IN_SUCC", {
          ...user,
          ...{ token },
          ...{ refreshToken },
        });
      } else {
        if (user && user.pwd === utils.hashPassword(pwd, user.salt)) {
          delete user.salt;
          delete user.pwd;
          user = await User.findOne({ _id: user._id }, { resetpwdExpires: 0, resetpwdToken: 0, __v: 0, recentlyViewed: 0, statusChangeTimeline: 0 }).populate([{ path: 'profile', select: 'firstName lastName' }]).lean();

          let token = utils.generateToken(user);
          let refreshToken = utils.generateRefreshToken({ _id: user._id, isRefresh: true });

          return utils.sendResponseNew(req, res, "OK", "USER_LOGGED_IN_SUCC", {
            ...user,
            ...{ token },
            ...{ refreshToken },
          });
        } else {
          return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_PASS");
        }
      }
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.exchangeToken = async (req, res) => {
    try {
      let { refreshToken } = req.body;
      if (!refreshToken) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_REFRESH_TOK");
      }
      let data = await utils.verifyToken(refreshToken);
      let user = await User.findOne({ _id: data._id }).lean();
      let token = utils.generateToken(user);
      user = { ...user, ...{ token: token } };
      return utils.sendResponseNew(req, res, "OK", null, user);
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.forgotpwd = async (req, res) => {
    try {
      let { email } = req.body;
      let user = await User.findOne({ email });
      if (!user) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }

      let token = await utils.generateToken({ email }, true);
      user.resetpwdToken = token; // save the token

      let expires = moment().add(1, "day").format();
      user.resetpwdExpires = expires;
      await User.updateUser(user, user._id);

      let link = config.webHost + "/reset-password?token=" + token;
      let context = { email: user.email, name: user.name, link };
      console.log("context::", context);
      // await emailSer.sendForgotPwdMail(user.email, context);
      return utils.sendResponseNew(req, res, "OK", "RESET_PWD_LINK_SEND_SUCC", {
        link,
      });
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.resetpwd = async (req, res) => {
    try {
      let { token, pwd } = req.body;
      let { email } = await utils.verifyToken(token);

      let user = await User.findOne({ email }, { salt: 1 });
      if (!user) {
        // IS VALID USER CHECK
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }

      let isValidToken = await User.getUserWhoResetPwd(token);
      if (!isValidToken) {
        // IS VALID TOKEN
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_RESET_PWD_LINK");
      }
      user.pwd = utils.hashPassword(pwd, user.salt);
      user.resetpwdExpires = null;
      user.resetpwdToken = null;
      let userUpdateResp = await User.updateUser(user, user._id);

      // let context = { email: user.email, name: userUpdateResp.name };
      // await emailSer.resetPwdMail(email, context);

      return utils.sendResponseNew(req, res, "OK", "PASSWORD_RESET_SUCC", userUpdateResp);
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.mobileOTP = async (req, res) => {
    try {
      let { phone } = req.body;
      let user = await User.findOne({ phone });
      if (!user) {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }
      let secret = utils.codeGenerator();
      let info = { otpSecretKey: secret };
      await User.updateUser(info, user._id);
      totp.options = { digits: 4, step: 50000 };
      const token = totp.generate(secret);
      return utils.sendResponseNew(req, res, "OK", "OTP_SENT", token);
    } catch (error) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  return ctrl;
};
