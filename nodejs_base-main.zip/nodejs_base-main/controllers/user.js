"use strict";

module.exports = function (mongoose, utils, config, constants, upload, ac) {
  const ctrl = {};
  const { lodash } = utils;
  const User = mongoose.model("User");

  ctrl.changepwd = async (req, res) => {
    try {
      let { oldpwd, newpwd } = req.body;
      let { phone } = req.userInfo;
      let user = await User.findOne({ phone }).select("+salt +pwd");
      if (user && utils.isEmail(user.email) && user.pwd === utils.hashPassword(oldpwd, user.salt)) {
        delete user.salt;
        user.pwd = newpwd;
        await User.addUser(user);
        return utils.sendResponseNew(req, res, "OK", "PASSWORD_CHANGED", {});
      } else {
        if (user.pwd !== utils.hashPassword(oldpwd, user.salt)) {
          return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_CUR_PWD");
        } else {
          return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
        }
      }
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };

  ctrl.getUser = async (req, res) => {
    try {
      let { _id: userId } = req.userInfo;
      let user = await User.findOne({ _id: userId }).lean();
      if (!lodash.isEmpty(user)) {
        delete user.pwd;
        delete user.salt;
        return utils.sendResponseNew(req, res, "OK", "SUCCESS", { ...user });
      } else {
        return utils.sendErrorNew(req, res, "BAD_REQUEST", "INVALID_USER");
      }
    } catch (err) {
      console.error("err::", err);
      if (err.message) {
        console.log(err.message)
        return utils.sendErrorNew(req, res, "NOT_FOUND", null, err.message);
      };
      return utils.sendServerErrorNew(req, res);
    }
  };


  return ctrl;
};
