"use strict";

const textEn = require("../localization/en.json");
const { StatusCodes } = require("http-status-codes");

module.exports = {
  lang: "en",
  codeNew: StatusCodes,
  code: {
    HTTP_SUCCESS: 200,
    SUCCESS: 200,
    HTTP_POST_S: 201, //post request succcess
    POST_S: 201,
    HTTP_GET_S: 200, //get request Success
    GET_S: 200,
    ERR: 400,
    INVALID: 400,
    FAILURE: 400,
    PWD_MISMATCH: 400,
    BAD_REQUEST: 400,
    HTTP_ERR: 400,
    NOT_AUTHERIZED: 401,
    FORBIDDEN: 403,
    USER_FORBIDDEN: 403,
    HTTP_GET_NF: 404, //get request NotFound (No Data)
    GET_NF: 404,
    HTTP_GET_F: 404, //get request Failure
    NOT_FOUND: 404,
    NO_RECORDS: 404,
    CONFLICT: 409,
    DB_FAILURE: 500,
    DB_ERR: 500,
  },
  text: {
    en: textEn,
  },
  roles: {
    ADMIN: 10
  },
  userStatus: {
    ACTIVE: 10,
    IN_ACTIVE: 20,
    DELETED: 30,
  },
  loginType: {
    PWD: 10,
    OTP: 20,
  }
};
