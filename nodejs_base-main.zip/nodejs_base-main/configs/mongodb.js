/**
 * Project          : nodejs_basic
 * Module           : Mongodb config
 * Source filename  : mongodb.js
 * Description      : Mongodb related configuration
 * Author           : FlipFlop Infotech < flipflopinfotech@gmailin.com>
 * Copyright        : Copyright © 2019, True Friend
 *                    Written under contract by FlipFlop Infotech
 */
"use strict";

const mongoose = require("mongoose");
const autoIncrement = require("mongoose-auto-increment");
const config = require("./config");

module.exports = () => {
  return new Promise((resolve) => {
    //added to avoid mongoose Promise warning
    mongoose.Promise = global.Promise;

    // Connect to MongoDB
    mongoose.connect(config.mongo.dbURL, config.mongo.options);
    console.log("Config", config.mongo.dbURL);
    console.log("Con", config.mongo.options);
    const db = mongoose.connection;
    autoIncrement.initialize(db);
    db.on("connected", console.info.bind(console, "MongoDB connected:"));
    db.on("error", console.error.bind(console, "MongoDB error:"));
    db.on("reconnected", console.warn.bind(console, "MongoDB reconnected:"));
    db.once("open", function callback() {
      console.log("Database connection to MongoDB opened.");
      resolve(mongoose);
    });

    console.log("Loading MongoDB Settings ...");
  });
};
