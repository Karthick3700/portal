"use strict";
var winston = require("winston");
const { combine, timestamp, prettyPrint } = winston.format;
var config = require("./config");
require('winston-daily-rotate-file');

module.exports = function () {

    var transport = new winston.transports.DailyRotateFile({
        filename: 'app-%DATE%.log',
        dirname: "./logs",
        datePattern: 'YYYY-MM-DD',
        // frequency: '*/10 * * * *',
        zippedArchive: true,
        // maxSize: '20m',
        maxFiles: '90d'
    });
    var logger = winston.createLogger({
        format: combine(
            timestamp(),
            prettyPrint()
        ),
        transports: [
            transport
        ]
    });

    const originalConsole = {
        log: console.log,
        error: console.error,
        info: console.info,
        debug: console.debug,
        warn: console.warn
    }

    console.log = async function () {
        try {
            if (config.useStackDriverLogs === true) {
                logger.info(JSON.stringify(arguments));
            }
            if (config.useConsole === true) {
                originalConsole.log.apply(console, arguments);
            }
        } catch (e) {
            originalConsole.log.apply(console, arguments);
        }
    }

    console.error = async function () {
        try {
            if (config.useStackDriverLogs === true) {
                let updatedArguments = [];
                if (arguments && arguments.length > 0) {
                    for (let i = 0, j = arguments.length; i < j; i++) {
                        let e = arguments[i];
                        if (typeof e === "object" && e instanceof Error) {
                            let errObj = {
                                ...(e.message && {
                                    message: e.message
                                }),
                                ...(e.name && {
                                    name: e.name
                                }),
                                ...(e.errors && {
                                    errors: e.errors
                                }),
                                ...(e.response && { // This object comes up when the axios throws error object
                                    data: e.response.data,
                                    status: e.response.status
                                }),
                                ...(e.fileName && {
                                    fileName: e.fileName
                                }),
                                ...(e.lineNumber && {
                                    lineNumber: e.lineNumber
                                }),
                                ...(e.columnNumber && {
                                    columnNumber: e.columnNumber
                                }),
                                ...(e.stack && {
                                    stack: e.stack
                                })
                            };
                            updatedArguments.push(errObj);
                        } else {
                            updatedArguments.push(e);
                        }
                    }
                }
                logger.error(JSON.stringify(updatedArguments));
            }
            if (config.useConsole === true) {
                originalConsole.error.apply(console, arguments);
            }
        } catch (e) {
            originalConsole.error.apply(console, arguments);
        }
    }

    console.info = async function () {
        try {
            if (config.useStackDriverLogs === true) {
                logger.info(JSON.stringify(arguments));
            }
            if (config.useConsole === true) {
                originalConsole.info.apply(console, arguments);
            }
        } catch (e) {
            originalConsole.info.apply(console, arguments);
        }
    }

    console.debug = async function () {
        try {
            if (config.useStackDriverLogs === true) {
                logger.debug(JSON.stringify(arguments));
            }
            if (config.useConsole === true) {
                originalConsole.debug.apply(console, arguments);
            }
        } catch (e) {
            originalConsole.debug.apply(console, arguments);
        }
    }

    console.warn = async function () {
        try {
            if (config.useStackDriverLogs === true) {
                logger.debug(JSON.stringify(arguments));
            }
            if (config.useConsole === true) {
                originalConsole.warn.apply(console, arguments);
            }
        } catch (e) {
            originalConsole.warn.apply(console, arguments);
        }
    }

    console.log("Loading logger ...");


    return logger;
}