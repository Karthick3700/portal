/* eslint-disable no-undef */
/**
 * Project          : nodejs_basic
 * Module           : Configuration
 * Source filename  : config.js
 * Description      : Environment related configuration variables
 * Author           : flipflopinfotech <flipflopinfotech@gmail.com>
 * Copyright        : Copyright © 2019, True Friend
 *                    Written under contract by FlipFlop Infotech
 */

"use strict";

const _ = require("lodash");

const defaults = {
  secretKey: "$c3!321#",
  root: require("path").normalize(__dirname + "/.."),
  host: process.env.HOST || "localhost",
  webHost: process.env.WEB_HOST || "http://localhost:3000/",
  apiHost: process.env.API_HOST || "http://localhost:3000/",
  SERVER_SECRET: process.env.SERVER_SECRET || "SecretKey",
  PASSWORD_SECRET: process.env.PASSWORD_SECRET || "SecretKey",
  imageDir: process.env.IMAGE_DIRECTORY,
  port: process.env.PORT || 3002,
  options: {
    skip: 0,
    limit: 10,
    sortBy: "_id",
    sort: -1,
  },
  useConsole: true,
  useStackDriverLogs: true,
  mongo: {
    dbURL: "mongodb://localhost:27017?authSource=admin",
    options: {},
  },
  security: {
    refreshToken: Number(process.env.REFRESH_TOKEN), // 10 days
    accessToken: Number(process.env.REFRESH_TOKEN), // seconds  (10day)
    emailLinkToken: Number(process.env.EMAIL_LINK_TOKEN), // seconds  (1day)
    resetPasswordToken: Number(process.env.EMAIL_LINK_TOKEN), //seconds (7 days)
    defaultToken: Number(process.env.DEFAULT_TOKEN_EXP), // 2hours
  },
  prefix: {
    USER: "USER"
  },
};

const config = {
  local: {
    mongo: {
      dbURL: process.env.MONGO,
      options: {},
    },
  },
  development: {
    mongo: {
      dbURL: process.env.MONGO,
      options: {
        authSource: "admin",
        auth: {
          username: process.env.MONGO_USERNAME,
          password: process.env.MONGO_PASSWORD,
        },
      },
    },
  },
  production: {
    mongo: {
      dbURL: process.env.MONGO,
      options: {},
    },
  },
};

module.exports = (function () {
  const env = process.env.NODE_ENV || "development";
  return _.merge(defaults, config[env]);
})();
