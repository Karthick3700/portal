/**
 * Project          : True Friend
 * Module           : Loader
 * Source filename  : loader.js
 * Description      : Loading all models and routes.
 * Author           : flipflopinfotech <flipflopinfotech@gmail.com>
 * Copyright        : Copyright © 2019, True Friend
 *                    Written under contract by FlipFlop Infotech
 */
"use strict";

module.exports = function (app, mongoose, utils, config, constants) {
  const fs = require("fs");
  const multer = require("multer");
  const path = require("path");
  const swaggerUI = require("swagger-ui-express");
  const swaggerJsDoc = require("swagger-jsdoc");
  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      let userIdAsString = String(req.userInfo._id);
      let dir;
      const dirName = __dirname + "/../public/images";
      fs.mkdirSync(dir, { recursive: true });

      cb(null, dir);
    },
    filename: function (req, file, cb) {
      let userIdAsString = String(req.userInfo._id);
      let ext = path.extname(file.originalname).toLocaleLowerCase();
      let newFileName = "Orginal_" + userIdAsString + "_" + Date.now() + ext;
      cb(null, newFileName);
    },
  });

  const upload = multer({
    storage: storage,
    fileFilter: function (req, file, callback) {
      var ext = path.extname(file.originalname).toLocaleLowerCase();
      console.log("ext::", ext);      
      if (ext !== ".png" && ext !== ".jpg" && ext !== ".gif" && ext !== ".jpeg" && ext !== ".xlsx") {
        return callback({msg: "INVALID_IMAGE"});
      }
      callback(null, true);
    },
    limits: {
      fileSize: 1024 * 1024,
    },
  });

  // Paths();
  const models = config.root + "/models";
  const routes = config.root + "/routes";
  const adminRoutes = config.root + "/admin-routes";
  const seedDatas = config.root + "/seed-datas";
  // const servicesPath = config.root + "/services";

  // Bootstrap models
  fs.readdirSync(models).forEach(function (file) {
    console.log("Loading models : " + file);
    require(models + "/" + file + "/schema.js")(mongoose, utils, config, constants, upload);
  });

  // Bootstrap routes
  fs.readdirSync(routes).forEach(function (file) {
    console.log("Loading routes : " + file);
    require(routes + "/" + file)(app, mongoose, utils, config, constants, upload);
  });

  // // Bootstrap admin routes
  // fs.readdirSync(adminRoutes).forEach(function (file) {
  //   console.log("Loading admin routes : " + file);
  //   require(adminRoutes + "/" + file)(app, mongoose, utils, config, constants, upload);
  // });

  // // Bootstrap seed datas

  // fs.readdirSync(seedDatas).forEach(function (file) {
  //   console.log("Loading admin routes : " + file);
  //   require(seedDatas + "/" + file)(app, mongoose, utils, config, constants, upload);
  // });
  const options = {
    failOnErrors: true, // Whether or not to throw when parsing errors. Defaults to false.
    definition: {
      openapi: "3.0.0",
      info: {
        title: "Basic Code",
        version: "1.0.0",
        description: "Api Desc",
      },
      servers: [
        {
          url: "http://localhost:3000/api/v1/",
          description: "Local server",
        },
        // {
        //   url: "https://apidev.truefriendmatrimony.com/api/v1/",
        //   description: "DEV Env",
        // },
      ],
    },
    apis: [routes + "/*.js"],
  };

  app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerJsDoc(options)));
};
