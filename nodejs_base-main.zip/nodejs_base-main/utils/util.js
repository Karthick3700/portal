/**
 * Project          : nodejs_basic
 * Module           : Utilities
 * Source filename  : utility.js
 * Description      : Utility functions for multiple modules.
 * Author           : FlipFlop Infotech < flipflopinfotech@gmailin.com>
 * Copyright        : Copyright © 2019, True Friend
 *                     Written under contract by FlipFlop Infotech
 */

"use strict";
const _ = require("lodash");
const constants = require("../configs/constants");
const config = require("./../configs/config.js");
const validator = require("validator");
const request = require("request");
const moment = require("moment-timezone");
const jwt = require("jsonwebtoken");
const CODE = constants.code;
const CODE_NEW = constants.codeNew;
const MSG = constants.text;
const lang = constants.lang;
const crypto = require("crypto");
const CryptoJS = require("crypto-js");
const moment_lib = require("moment");
const lodash_lib = require("lodash");
const pdf = require('dynamic-html-pdf');
const fs = require("fs");
const Joi = require("joi");
const { roles: roles } = constants;
const { CUSTOMER, RETAILER, ADMIN, DISTRIBUTER, MECHANIC, FINANCE } = roles;
module.exports = {
  moment: moment_lib,
  lodash: lodash_lib,
  Joi,

  isEmail: function (email) {
    if (email) {
      return validator.isEmail(email);
    } else {
      return false;
    }
  },

  isEmpty: function (email) {
    if (email) {
      return validator.isEmail(email);
    } else {
      return false;
    }
  },

  decryptPasswordFromUI: function (password) {
    return CryptoJS.AES.decrypt(password, config.secretKey).toString(CryptoJS.enc.Utf8);
  },

  generateRandomSalt: function () {
    // eslint-disable-next-line no-undef
    return Buffer.from(crypto.randomBytes(16).toString("base64"), "base64");
  },

  hashPassword: function (password, salt) {
    return crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("base64");
  },

  validatePassword: function (password) {
    return /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/.test(password);
  },

  //generic format function for sending error response
  notifyError: function (req, res, httpStatus, code, message, extraMsg) {
    //setting http status code for response
    httpStatus = typeof httpStatus === "undefined" ? 400 : CODE[httpStatus];

    if (!code) {
      code = "ERR";
    }

    if (!message) {
      message = "ERR";
    }
    let errorMsg = MSG[lang][message];
    if (extraMsg) {
      if (lang === "en") {
        errorMsg = errorMsg + " : " + extraMsg;
      } else {
        errorMsg = extraMsg + " : " + errorMsg;
      }
    }
    res.status(httpStatus).json({
      meta: {
        code: CODE[code],
        message: errorMsg,
        timestamp: new Date().toISOString(),
      },
    });
  },

  sendCustomError: function (req, res, httpStatus, code, message) {
    //setting http status code for response
    httpStatus = typeof httpStatus === "undefined" ? 400 : CODE[httpStatus];

    if (!code) {
      code = CODE.ERR;
    }

    if (!message) {
      message = MSG[lang].ERR;
    }

    res.status(httpStatus).json({
      meta: {
        code: code,
        message: message,
        timestamp: new Date().toISOString(),
      },
    });
  },

  //generic format function for sending Success response
  sendResponse: function (req, res, httpStatus, data, message, code, count, customMsg) {
    code = typeof code === "undefined" ? "SUCCESS" : code;
    httpStatus = typeof httpStatus === "undefined" ? 200 : CODE[httpStatus];

    let skip;
    let limit;
    if (req.query.skip) skip = req.query.skip;
    if (req.query.limit) limit = req.query.limit;

    res.status(httpStatus).json({
      meta: {
        code: CODE[code],
        message: MSG[lang][message] || customMsg,
        timestamp: new Date().toISOString(),
      },
      pagination: {
        skip: skip,
        limit: limit,
        totalCount: count,
      },
      data: data,
    });
  },

  sendPaginationResponseNew: function (req, res, code, message, data, count, customMsg) {
    code = typeof code === "undefined" ? "OK" : code;

    let skip = req.query.skip ? req.query.skip : req.body.skip;
    let limit = req.query.limit ? req.query.limit : req.body.limit;

    let resp = {
      meta: {
        code: CODE_NEW[code],
        message: MSG[lang][message] || customMsg,
        timestamp: new Date().toISOString(),
      },
      pagination: {
        skip: skip,
        limit: limit,
        totalCount: count,
      },
      data,
    };

    res.status(CODE_NEW[code]).json(resp);
  },

  sendResponseNew: function (req, res, code, message, data, customMsg, customMetaCode = null) {
    code = typeof code === "undefined" ? "OK" : code;

    let resp = {
      meta: {
        code: customMetaCode ? CODE[customMetaCode] : CODE_NEW[code],
        message: MSG[lang][message] || customMsg,
        timestamp: new Date().toISOString(),
      },
      data,
    };

    res.status(CODE_NEW[code]).json(resp);
  },

  notifyErrorNew: function (req, res, code, message, customMsg) {
    code = typeof code === "undefined" ? "OK" : code;

    res.status(CODE_NEW[code]).json({
      meta: {
        code: CODE_NEW[code],
        message: MSG[lang][message] || customMsg,
        timestamp: new Date().toISOString(),
      },
    });
  },

  sendErrorNew: function (req, res, code, msg, customMsg) {
    return module.exports.notifyErrorNew(req, res, code, msg, customMsg);
  },

  sendServerErrorNew: function (req, res) {
    return module.exports.notifyErrorNew(req, res, "INTERNAL_SERVER_ERROR", "ERR");
  },

  sendPostSuccess: function (req, res, data) {
    return module.exports.sendResponse(req, res, "HTTP_POST_S", data, "POST_S", "POST_S");
  },

  sendDBError: function (req, res, err) {
    console.info("sendDBError", err);
    if (err && err.code === 11000) {
      return module.exports.notifyError(req, res, "CONFLICT", "DB_DUPLICATE", "DB_DUPLICATE");
    } else if (err && err.code === 11009) {
      return module.exports.notifyError(req, res, "CONFLICT", "DB_AGE_DUPLICATE", "DB_AGE_DUPLICATE");
    } else if (err && err.code === 12009) {
      return module.exports.notifyError(req, res, "CONFLICT", "DB_SKILL_DUPLICATE", "DB_SKILL_DUPLICATE");
    } else if (err && err.name == "ValidationError") {
      return module.exports.notifyError(req, res, "BAD_REQUEST", "BAD_REQUEST", "BAD_REQUEST");
    } else {
      return module.exports.notifyError(req, res, "HTTP_ERR", "DB_ERR", "DB_ERR");
    }
  },

  sendNoRecordError: function (req, res, code) {
    if (code) {
      return module.exports.notifyError(req, res, "NOT_FOUND", "NO_RECORDS", code);
    } else {
      return module.exports.notifyError(req, res, "NOT_FOUND", "NO_RECORDS", "NO_RECORDS");
    }
  },

  sendDBCallbackErrs: function (req, res, err, data) {
    if (err) {
      return module.exports.sendDBError(req, res, err);
    } else {
      if (!data) {
        data = {};
      }
      return module.exports.sendResponse(req, res, "SUCCESS", data, "NO_RECORDS", "NO_RECORDS");
    }
  },

  sendParamsError: function (req, res, code, extraMsg) {
    if (code && code === "invalid") {
      return module.exports.notifyError(req, res, "HTTP_ERR", "BAD_PARAMS", "BAD_PARAMS", extraMsg);
    } else if (code && code === "required") {
      return module.exports.notifyError(req, res, "HTTP_ERR", "PARAM_MISSING", "PARAM_MISSING", extraMsg);
    } else {
      return module.exports.notifyError(req, res, "HTTP_ERR", "PARAM_MISSING", "PARAM_MISSING");
    }
  },

  sendBadReqError: function (req, res) {
    return module.exports.notifyError(req, res, "HTTP_ERR", "BAD_REQUEST", "BAD_REQUEST");
  },

  sendAuthError: function (req, res, code) {
    if (code) {
      return module.exports.notifyError(req, res, "UNAUTHORIZED", "UNAUTHORIZED", code);
    } else {
      return module.exports.notifyError(req, res, "UNAUTHORIZED", "UNAUTHORIZED", "UNAUTHORIZED");
    }
  },

  sendForbiddenError: function (req, res, code) {
    if (code) {
      return module.exports.notifyError(req, res, "FORBIDDEN", "FORBIDDEN", code);
    } else {
      return module.exports.notifyError(req, res, "FORBIDDEN", "FORBIDDEN", "FORBIDDEN");
    }
  },

  parseQueryParams: function (params) {
    let queryObj = {};
    queryObj.query = params.query ? params.query : {};
    queryObj.updateQuery = {};
    queryObj.selectFields = {};
    let selectMode = 1;
    if (params.unselect) {
      selectMode = 0;
    }
    queryObj.options = params.options ? params.options : {};

    if (params.skip) {
      queryObj.options.skip = +params.skip;
    }
    if (params.limit) {
      queryObj.options.limit = +params.limit;
    }
    if (params.sort) {
      queryObj.options.sort = params.sort;
    }
    if (params.update) {
      queryObj.updateQuery = params.update;
    }
    if (params.selectFields) {
      if (typeof params.selectFields === "string") {
        let selectArr = params.selectFields.trim().split(",");
        selectArr.forEach(function (value) {
          if (value.length > 0) {
            queryObj.selectFields[value.trim()] = selectMode;
          }
        });
      } else {
        queryObj.selectFields = params.selectFields !== undefined ? params.selectFields : null;
      }
    }

    if (params.extraSelectField) {
      Object.keys(params.extraSelectField).forEach(function (key) {
        queryObj.selectFields[key.trim()] = params.extraSelectField[key];
      });
    }

    if (params.populate) {
      queryObj.populate = params.populate;
    }
    return queryObj;
  },

  checkRequired: function (req, params, cb) {
    // eslint-disable-next-line no-undef
    async.each(
      params,
      function (param, callback) {
        if ((req.method == "POST" || req.method == "PUT") && typeof req.body[param] == "undefined") {
          if (param != "password") {
            console.info("Paramter missing :", param);
            callback(new Error(param));
          } else {
            callback(new Error("ParameterMissingError"));
          }
        } else {
          callback();
        }
      },
      function (err) {
        if (err) {
          return cb(err);
        } else {
          return cb(null);
        }
      }
    );
  },

  encryptPassword: function (password) {
    return crypto.createHmac("sha1", config.PASSWORD_SECRET).update(password).digest("hex");
  },

  dbCallbackHandler: function (req, res, data, err) {
    if (!err && data) {
      return module.exports.sendResponse(req, res, "SUCCESS", data);
    } else {
      return module.exports.sendDBCallbackErrs(req, res, err, data);
    }
  },

  dbArrayCallbackHandler: function (req, res, data, err, count) {
    if (!err && data) {
      if (typeof count === "undefined") {
        return module.exports.sendResponse(req, res, "SUCCESS", data);
      } else {
        if (data.length > 0) {
          //Object.keys(data).length > 0
          return module.exports.sendResponse(req, res, "SUCCESS", data, undefined, undefined, count, undefined);
        } else {
          return module.exports.sendResponse(req, res, "SUCCESS", data, "NO_RECORDS", "NO_RECORDS");
        }
      }
    } else {
      return module.exports.sendDBCallbackErrs(req, res, err, data);
    }
  },

  checkFields: function (fields, params, cb) {
    // eslint-disable-next-line no-undef
    async.each(
      params,
      function (param, callback) {
        if (typeof fields[param] == "undefined") {
          callback(new Error("ParameterMissingError"));
        } else {
          callback();
        }
      },
      function (err) {
        if (err) {
          return cb(err);
        } else {
          return cb(null);
        }
      }
    );
  },

  httpRequest: function (options, callback) {
    request(options, function (error, response, body) {
      callback(error, response, body);
    });
  },

  verifyToken: async function (token) {
    try {
      let decoded = await this.validateJWTToken(token);
      return decoded;
    } catch (err) {
      console.log("err::", err);
      throw err;
    }
  },

  validateJWTToken: function (token) {
    return new Promise(function (resolve, reject) {
      jwt.verify(token, config.SERVER_SECRET, function (err, data) {
        if (err) {
          console.log("err test");
          reject(err);
        } else {
          console.log("data test");
          resolve(data);
        }
      });
    });
  },

  generateToken: function (info, link) {
    let cloneInfo = _.clone(info);
    delete cloneInfo.otp;
    delete cloneInfo.otpTime;
    delete cloneInfo.resetPasswordToken;
    delete cloneInfo.resetPasswordExpires;
    delete cloneInfo.status;
    delete cloneInfo.password;
    delete cloneInfo.salt;
    delete cloneInfo.createdAt;
    delete cloneInfo.updatedAt;
    return jwt.sign(cloneInfo, config.SERVER_SECRET, {
      expiresIn: link ? config.security.emailLinkToken : this.getExpiryDuration(cloneInfo.role),
    });
  },

  getExpiryDuration: function (type) {
    let expiresIn = "2h";
    switch (type) {
      case ADMIN:
        expiresIn = config.security.emailLinkToken;
        break;
      case DISTRIBUTER:
        expiresIn = config.security.emailLinkToken;
        break;
      case RETAILER:
        expiresIn = config.security.emailLinkToken;
        break;
      case CUSTOMER:
        expiresIn = config.security.refreshToken;
        break;
      case MECHANIC:
        expiresIn = config.security.emailLinkToken;
        break;
      case FINANCE:
        expiresIn = config.security.emailLinkToken;
        break;
      default:
        expiresIn = config.security.defaultToken;
        break;
    }
    return expiresIn;
  },

  generateRefreshToken: function (info) {
    return jwt.sign(info, config.SERVER_SECRET, {
      expiresIn: config.security.refreshToken,
    });
  },

  generateActivateToken: function (info) {
    return jwt.sign(info, config.SERVER_SECRET);
  },

  generateResetPasswordToken: function (info) {
    return jwt.sign(info, config.SERVER_SECRET, {
      expiresIn: config.security.resetPasswordToken,
    });
  },

  defaultProfilePic: function () {
    return "https://static1.squarespace.com/static/56157d96e4b0a69ff974b145/t/580538cbcd0f681a5814bfca/1476737228280/blank+profile.png";
  },

  joiValidateParams: function (req, res, next, data, schema) {
    // validate the request data against the schema
    const { error } = schema.validate(data);
    if (error) {
      return this.sendResponse(req, res, "BAD_REQUEST", {}, undefined, "BAD_REQUEST", undefined, error.toString());
    } else {
      return next();
    }
  },

  getWeekDays: function () {
    return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  },

  getUserTypes: function () {
    return ["customer", "staff", "superAdmin"];
  },

  getWeeks: function () {
    return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  },

  getStudentStatus: function () {
    return ["current", "paused", "alumni"];
  },

  getAllMinutesForHour: function (timeArray) {
    let data = [];
    for (var i = 0; i < timeArray.length; i++) {
      var a = moment(timeArray[i], "hh:mm A");
      let timeData = timeArray[i].replace(":00", ":59");
      var b = moment(timeData, "hh:mm A");
      for (var m = moment(a); m.diff(b, "minute") <= 0; m.add(1, "minute")) {
        data.push(m.format("hh:mm A"));
      }
    }
    return data;
  },

  getAvailabilityStart: function () {
    let data = [];
    var a = moment("08:00 AM", "hh:mm A");
    var b = moment("07:00 PM", "hh:mm A");
    for (var m = moment(a); m.diff(b, "minute") <= 0; m.add(1, "minute")) {
      data.push(m.format("hh:mm A"));
    }
    return data;
  },

  getTwelveHourStart: function () {
    let data = [];
    var a = moment("00:00 PM", "hh:mm A");
    var b = moment("00:59 PM", "hh:mm A");
    for (var m = moment(a); m.diff(b, "minute") <= 0; m.add(1, "minute")) {
      data.push(m.format("hh:mm A"));
    }
    return data;
  },

  getYearGroups: function () {
    return ["K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
  },

  getLessonTypes: function () {
    return ["Group", "1:1", "Online"];
  },

  getTerms: function () {
    return ["T1", "T2", "T3", "T4"];
  },

  getUnique: function (array) {
    let uniqueArray = [];
    // Loop through array values
    for (let value of array) {
      if (uniqueArray.indexOf(String(value)) === -1) {
        uniqueArray.push(String(value));
      }
    }
    return uniqueArray;
  },

  insertSampleData: async function (model, sampleData) {
    try {
      let promises = [];
      let self = this;
      _.each(sampleData, function (document) {
        if (!_.isEmpty(document._id)) {
          promises.push(self.findAndAdd(model, document));
        }
      });
      await Promise.all(promises);
      console.log(model.collection.collectionName + " collection sample data added");
    } catch (err) {
      console.error(err);
      return err;
    }
  },

  findAndAdd: function (model, document) {
    return new Promise(function (resolve, reject) {
      model.findById(document._id, function (err, data) {
        if (err) {
          reject(err);
        } else {
          if (_.isEmpty(data)) {
            let doc = new model(document);
            doc.save(function (err) {
              if (err) {
                reject(err);
              } else {
                resolve();
              }
            });
          } else {
            resolve();
          }
        }
      });
    });
  },

  mergeArrayOfObjects: function (aggregate, field1, field2, key1, key2, field1Keys, field2Keys, projectFields) {
    let fieldWithKey1 = field1 + "." + key1;
    let fieldWithKey2 = field2 + "." + key2;

    aggregate.push({
      $unwind: { path: "$" + field1, preserveNullAndEmptyArrays: true },
    });
    aggregate.push({
      $unwind: { path: "$" + field2, preserveNullAndEmptyArrays: true },
    });

    aggregate.push({
      $redact: {
        $cond: [
          {
            $eq: ["$" + fieldWithKey1, "$" + fieldWithKey2],
          },
          "$$KEEP",
          "$$PRUNE",
        ],
      },
    });

    projectFields.splice(projectFields.indexOf(field2), 1);

    let project1 = {};
    _.each(projectFields, function (projectField) {
      if (projectField === field1) {
        project1[projectField] = {};
        _.each(field1Keys, function (field1Key) {
          project1[projectField][field1Key] = "$" + field1 + "." + field1Key;
        });
        _.each(field2Keys, function (field2Key) {
          project1[projectField][field2Key] = "$" + field2 + "." + field2Key;
        });
      } else {
        project1[projectField] = 1;
      }
    });

    aggregate.push({
      $project: project1,
    });

    let groupFields = {};
    let unGroupFields = {};
    _.each(projectFields, function (projectField) {
      if (projectField !== field1) {
        groupFields[projectField] = "$" + projectField;
      } else {
        unGroupFields = { $push: "$" + projectField };
      }
    });

    let $group = {};
    $group["_id"] = groupFields;
    $group[field1] = unGroupFields;

    aggregate.push({
      $group: $group,
    });

    let project2 = {};
    _.each(projectFields, function (projectField) {
      if (projectField !== field1) {
        project2[projectField] = "$_id." + projectField;
      } else {
        project2[projectField] = "$" + projectField;
      }
    });

    aggregate.push({
      $project: project2,
    });

    return aggregate;
  },

  formatDateAndTime: function (date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? "pm" : "am";
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? "0" + minutes : minutes;
    var strTime = hours + ":" + minutes + " " + ampm;
    return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear() + "  " + strTime; //  mm/dd/yyyy
  },

  makeSearchable: (text) => (text ? text.toString().toLowerCase().replace(/\s/g, "") : ""),

  getAge: function (dateString) {
    let today = new Date();
    let birthDate = new Date(dateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    let m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  },

  codeGenerator: function () {
    let char = "ABCDEFGHIJKLMNOPQRSTUVWXTZ1234567890";
    let codeLength = 6;
    let randomCode = "";
    for (var i = 0; i < codeLength; i++) {
      var rnum = Math.floor(Math.random() * char.length);
      randomCode += char.substring(rnum, rnum + 1);
    }
    return randomCode;
  },

  getSkipLimitStages: function (reqQuery) {
    let {
      skip = config.options.skip,
      limit = config.options.limit,
      sortBy = config.options.sortBy,
      sort = config.options.sort,
    } = reqQuery;

    let sortObj = {};
    sortObj[sortBy] = Number(sort);

    return [{ $sort: sortObj }, { $skip: Number(skip) }, { $limit: Number(limit) }];
  },

  nestedObjectsToMongoQueryParser: function (obj, replaceActualValue) {
    if (!replaceActualValue) replaceActualValue = obj;
    let transact = (obj, replaceActualValue) => {
      let objectKeys = Object.keys(obj);
      let resObj = {};
      for (var key of objectKeys) {
        if (obj[key] && typeof obj[key] == "object") {
          let replacableValue = replaceActualValue;
          if (replaceActualValue && typeof replaceActualValue == "object") {
            replacableValue = replaceActualValue[key];
          }
          let res = transact(obj[key], replacableValue);
          for (var k in res) resObj[`${key}.${k}`] = res[k];
        } else {
          let replacableValue = replaceActualValue;
          if (replaceActualValue && typeof replaceActualValue == "object") {
            replacableValue = replaceActualValue[key];
          }
          if (replacableValue != null) resObj[key] = replacableValue;
        }
      }
      return resObj;
    };
    return transact(obj, replaceActualValue);
  },

  getRegexUuid: function () {
    return /^[0-9a-fA-F]{24}$/;
  },
};
