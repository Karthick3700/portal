"use strict";
const express = require("express");
module.exports = function (app, mongoose, utils, config, constants, upload, ac) {
  const { Joi } = utils;
  const { validateToken } = require("../middleware/authenticate")();
  const validator = require("../validators/user")(Joi, utils, config, constants);
  const ctrl = require("../controllers/user")(mongoose, utils, config, constants, upload, ac);
  const userRouter = express.Router();

  userRouter.get("/", validateToken, ctrl.getUser);
  userRouter.post("/changepwd", validateToken, validator.changepwd, ctrl.changepwd);

  app.use("/api/v1/user", userRouter);
};
