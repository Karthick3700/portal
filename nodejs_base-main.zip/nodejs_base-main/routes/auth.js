"use strict";
const express = require("express");
module.exports = function (app, mongoose, utils, config, constants, upload, ac) {
  const {Joi} = utils;
  const {isValidToken} = require("../middleware/authenticate")();
  const validator = require("../validators/auth")(Joi, utils, config, constants);
  const ctrl = require("../controllers/auth")(mongoose, utils, config, constants, upload, ac);
  const userRouter = express.Router();

  userRouter.post("/isValid", ctrl.isValid);
  userRouter.post("/login", validator.login, ctrl.login);
  userRouter.post("/sent-otp", validator.sentOTP, ctrl.mobileOTP);
  userRouter.post("/exchange-token", validator.exchangeToken, ctrl.exchangeToken);
  userRouter.post("/register", validator.register, ctrl.register);
  userRouter.post("/activate", validator.activate, ctrl.activate);
  userRouter.get("/session", isValidToken);
  userRouter.post("/forgotpwd", validator.forgotpwd, ctrl.forgotpwd);
  userRouter.post("/resetpwd", validator.resetpwd, ctrl.resetpwd);

  app.use("/api/v1/auth", userRouter);
};
