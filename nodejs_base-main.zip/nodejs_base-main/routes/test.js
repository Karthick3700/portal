"use strict";
const express = require("express");
module.exports = function (app, mongoose, utils, config, constants, upload, ac) {
    const moment = require('moment');
    // const authToken = "c16db926c9abe2a87b4115d5c7c87af2"
    // const accountId = "AC70ad2993f5097a5367b1597b1ce6bda5"
    // const twilio = require('twilio')(accountId, authToken)
    const stripe = require('stripe')('sk_test_51KHAYbGcWZBq3ZE11cXUqmz50ttCIB42vWUhY10K6yhjf60B1OXQ9CFmoGK6GCusF65VfFnbnvp07MB4z9EudMwD00MNQRRnFP')
    const userRouter = express.Router();
    userRouter.get("/test", async (req, res) => {
        // // twilio.messages
        // //     .create({
        // //         body: 'Hi',
        // //         from: '+15074172101',
        // //         to: '+919789741475'
        // //     })
        // //     .then(message => console.log(message.sid));
        // let customer = await stripe.customers.create({
        //     email: "prasanna.flipflop@gmail.com",
        //     name: "prasanna"
        // })
        // console.log(customer)
        // let cus = await stripe.charges.create({
        //     amount: 1000,
        //     currency: 'usd',
        //     customer: customer._id,
        //     description: 'Charge for test@example.com'
        // })
        let a = moment().subtract(1, "month").startOf("day");
        console.log(a);
        // console.log(cus);

        return utils.sendResponseNew(req, res, "OK", "SUCCESS");

    });

    app.use("/api/v1", userRouter);
};
