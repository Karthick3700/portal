"use strict";
const users = require("../data/users.json");
class AdminUser {
  constructor(app, mongoose, utils, config, constants) {
    this.app = app;
    this.mongoose = mongoose;
    this.utils = utils;
    this.config = config;
    this.constants = constants;
    this.init();
  }
  async init() {

    const userModel = this.mongoose.model("User");
    let count = await userModel.countDocuments({});

    if (count == 0) {
      users.forEach(async (ele) => {
        let _id = this.mongoose.Types.ObjectId();
        ele._id = _id,
          userModel.addUser(ele)
      });
    }
  }
}
module.exports = (app, mongoose, utils, config, constants) => new AdminUser(app, mongoose, utils, config, constants);
