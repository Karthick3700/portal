"use strict";

module.exports = function (Joi, utils, config, constants) {
  const validator = {};
  Joi.objectId = require("joi-objectid")(Joi);
  const { joiPasswordExtendCore } = require("joi-password");
  const joiPassword = Joi.extend(joiPasswordExtendCore);

  validator.changepwd = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      oldpwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .required()
        .error(() => Error("Invalid old Password")),
      newpwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .required()
        .error(() => Error("Invalid new Password")),
      confirmPwd: Joi.string()
        .required()
        .valid(Joi.ref("newpwd"))
        .error(() => Error("Invalid confirmPwd")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };


  return validator;
};
