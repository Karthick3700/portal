"use strict";

module.exports = function (Joi, utils, config, constants) {
  const validator = {};
  Joi.objectId = require("joi-objectid")(Joi);
  const moment = require("moment");
  const { joiPasswordExtendCore } = require("joi-password");
  const joiPassword = Joi.extend(joiPasswordExtendCore);
  const { roles: constRoles, userStatus: constUserStatus, loginType: constLoginType } = constants;
  const { ADMIN, RETAILER, DISTRIBUTER, CUSTOMER } = constRoles;
  const { ACTIVE, IN_ACTIVE } = constUserStatus;
  const { PWD, OTP } = constLoginType;

  validator.login = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      email: Joi.string()
        .email()
        .when("loginType", {
          is: Joi.valid(constants.loginType.PWD),
          then: Joi.required(),
          otherwise: Joi.forbidden(),
        })
        .required()
        .error(() => Error("Invalid email")),
      phone: Joi.string()
        .length(10)
        .pattern(/^[0-9]+$/)
        .when("loginType", {
          is: Joi.valid(constants.loginType.OTP),
          then: Joi.required(),
          otherwise: Joi.forbidden(),
        })
        .required()
        .error(() => Error("Invalid Phone")),
      loginType: Joi.number()
        .valid(...Object.values(constants.loginType))
        .error(() => Error("Invalid login type")),
      otp: Joi.string()
        .when("loginType", {
          is: Joi.valid(constants.loginType.OTP),
          then: Joi.required(),
          otherwise: Joi.forbidden(),
        })
        .error(() => Error("Invalid OTP")),
      pwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .when("loginType", {
          is: Joi.valid(constants.loginType.PWD),
          then: Joi.required(),
          otherwise: Joi.forbidden(),
        })
        .error(() => Error("Invalid Password")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.sentOTP = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      phone: Joi.string()
        .length(10)
        .pattern(/^[0-9]+$/)
        .required()
        .error(() => Error("Invalid Phone")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.exchangeToken = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      refreshToken: Joi.string()
        .required()
        .error(() => Error("Invalid refreshToken")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.adminLogin = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      email: Joi.string()
        .email()
        .required()
        .error(() => Error("Invalid email")),
      pwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .required()
        .error(() => Error("Invalid password")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.loginOtp = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      email: Joi.string()
        .email()
        .required()
        .error(() => Error("Invalid email")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.register = (req, res, next) => {
    const data = req.body;
    const schema = Joi.object({
      email: Joi.string()
        .email({ minDomainSegments: 2, tlds: false })
        .required()
        .error(() => Error("Invalid email")),
      role: Joi.number()
        .valid(...Object.values(constants.roles))
        .required()
        .error(() => Error("Invalid role")),
      phone: Joi.string()
        .length(10)
        .pattern(/^[0-9]+$/)
        .required()
        .error(() => Error("Invalid Phone")),
      pwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .error(() => Error("Invalid password")),
      confirmPwd: Joi.string()
        .required()
        .valid(Joi.ref("pwd"))
        .error(() => Error("Invalid confirmPwd")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.activate = (req, res, next) => {
    const data = req.body;
    const schema = Joi.object({
      token: Joi.string()
        .trim()
        .required()
        .error(() => Error("Invalid token")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.forgotpwd = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      email: Joi.string()
        .trim()
        .email()
        .required()
        .error(() => Error("Invalid email")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.resetpwd = function (req, res, next) {
    const data = req.body;
    const schema = Joi.object({
      token: Joi.string()
        .trim()
        .required()
        .error(() => Error("Invalid Token")),
      pwd: joiPassword
        .string()
        .minOfSpecialCharacters(1)
        .minOfLowercase(1)
        .minOfUppercase(1)
        .minOfNumeric(1)
        .noWhiteSpaces()
        .required()
        .error(() => Error("Invalid Password")),
      confirmpwd: Joi.string()
        .required()
        .valid(Joi.ref("pwd"))
        .error(() => Error("Invalid Confirm Password")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  validator.isValidToken = function (req, res, next) {
    const data = req.params;
    const schema = Joi.object({
      token: Joi.string()
        .trim()
        .required()
        .error(() => Error("Invalid token")),
    });
    return utils.joiValidateParams(req, res, next, data, schema);
  };

  return validator;
};
