"use strict";

// eslint-disable-next-line no-unused-vars
module.exports = function (mongoose, utils, config, constants, upload) {
  const Coupon = mongoose.model("Coupon");
  const moment = require("moment");

  const {ACTIVE, IN_ACTIVE} = constants.status;

  const cronFns = {};
  cronFns.activeCoupon = async function () {
    let currDate = moment(new Date()).startOf("day");
    let endOfDay = moment(new Date()).endOf("day");
    let startDateCoupons = await Coupon.find({startAt: {$gte: currDate, $lte: endOfDay}});
    let couponIds = [];
    for (let ele of startDateCoupons) {
      couponIds.push(ele._id);
    }
    if (couponIds.length !== 0) {
      await Coupon.updateMany({_id: {$in: couponIds}}, {$set: {status: ACTIVE}});
    }
  };

  cronFns.deActiveCoupon = async function () {
    let currDate = moment(new Date()).startOf("day");
    let endDateCoupons = await Coupon.find({expiresAt: {$lte: currDate}});
    let couponIds = [];
    for (let ele of endDateCoupons) {
      couponIds.push(ele._id);
    }
    if (couponIds.length !== 0) {
      await Coupon.updateMany({_id: {$in: couponIds}}, {$set: {status: IN_ACTIVE}});
    }
  };

  return cronFns;
};
