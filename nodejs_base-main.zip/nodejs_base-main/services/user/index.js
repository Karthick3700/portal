"use strict";

// eslint-disable-next-line no-unused-vars
module.exports = function (mongoose, utils, config, constants, upload) {
  const Counter = mongoose.model("IdentityCounter");
  const User = mongoose.model("User");
  const moment = require("moment");
  const userFns = {};

  userFns.getNextUserId = async function () {
    let { count: seqNo } = await Counter.findOneAndUpdate(
      { model: "User", field: "userId" },
      { $inc: { count: 1 } },
      { upsert: true, new: true }
    );
    let pre = "000000";
    let userId = config.prefix.USER + pre.slice(String(seqNo).length) + String(seqNo);
    // let userId = config.prefix.USER + String(seqNo);
    return userId;
  };

  userFns.registerUser = async function (payload, user) {
    let { firstName, lastName, email, role, phone, pwd } = payload;

    let userId = await userFns.getNextUserId();
    let info, userRegResp;
    if (user) {
      info = { userId, role: RETAILER, phone, email, pwd, firstName, lastName, isParent: user };
      userRegResp = await User.create(info);
      await User.findOneAndUpdate({ _id: user }, { $push: { isChild: userRegResp._id } }, { new: true }).lean();
    } else {
      info = { userId, role, phone, email, pwd };
      userRegResp = await User.create(info);
    };
    let response = await User.findOne({ _id: userRegResp._id }).lean();
    return response;
  };

  return userFns;
};
