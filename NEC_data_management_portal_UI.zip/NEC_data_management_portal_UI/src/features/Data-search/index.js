import {
    Box,
    Grid,
    Paper,
    SvgIcon,
    Typography
} from '@mui/material';
import React from 'react';
import Chat from '../DataSearch/Chat';

const Datasearch = () => {
    return (
        <Box>

            <Box>
                <Typography sx={
                    {
                        color: '#D9DDE5',
                        fontFamily: 'Montserrat',
                        fontSize: '14px'
                    }
                }>
                    data search page
                    <Chat />
                </Typography>
            </Box>

        </Box>
    );
}

export default Datasearch;
