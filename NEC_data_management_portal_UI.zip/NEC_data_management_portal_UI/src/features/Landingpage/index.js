import { Box, SvgIcon } from '@mui/material';
import { ReactComponent as Seasons } from "../../assets/seasons.svg";
import { ReactComponent as Socialmediaicon } from "../../assets/socialmediaicon.svg";
import { ReactComponent as Tourism } from "../../assets/tourism.svg";
import { ReactComponent as Zones } from "../../assets/zones.svg";
import { ReactComponent as Restaurant } from "../../assets/restaurants.svg";
import { ReactComponent as Events } from "../../assets/events.svg";
import { ReactComponent as Satisfaction } from "../../assets/satisfaction.svg";
import { ReactComponent as Tickets } from "../../assets/ticketsandvisitors.svg";
import { ReactComponent as Logo } from '../../assets/logobig_login.svg'
import background from '../../assets/backgroundvideo.mp4';

function Landingpage() {
    return (
        <>
        <Box>
            <video autoPlay loop muted
                style={{
                    position: "fixed",
                    width: "100%",
                    left: "50%",
                    top: "50%",
                    minHeight: "100%",
                    minWidth: "100%",
                    objectFit: "cover",
                    transform: "translate(-50%, -50%)",
                    zIndex: "-1",
                }}>
                <source src={background} type="video/mp4" />
            </video>
        </Box>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 20, // Adjust this for the desired gap
                    ml: 55,
                    mt: 6
                }}
            >
                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Socialmediaicon />
                </SvgIcon>

                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Seasons />
                </SvgIcon>
            </Box>

            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 40, // Adjust this for the desired gap
                    ml: 45,
                    mt: 4
                }}
            >
                <SvgIcon sx={{
                    width: 70,
                    height: 71,
                    bgcolor: 'white'
                    , borderRadius: '2.5rem'
                }}>
                    <Tourism />
                </SvgIcon>

                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Zones />
                </SvgIcon>
            </Box>

            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 40, // Adjust this for the desired gap
                    ml: 61.5,
                    mt: 28,
                    position: 'absolute'
                }}
            >
                <SvgIcon sx={{
                    width: 200,
                    height: 200,
                    bgcolor: 'rgb(19,25,106)'
                    , borderRadius: '6rem'
                }}>



                </SvgIcon>


            </Box>

            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 40, // Adjust this for the desired gap
                    ml: 64.5,
                    mt: 31,
                    position: 'absolute'
                }}
            >

                <SvgIcon sx={{
                    width: 150,
                    height: 150,
                    bgcolor: 'white'
                    , borderRadius: '5.5rem'
                }}>
                    <SvgIcon sx={
                        {
                            height: '50px',
                            width: '10px',
                            padding: '1px'
                        }
                    }
                        component={Logo}
                        inheritViewBox />

                </SvgIcon>
            </Box>



            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 40, // Adjust this for the desired gap
                    ml: 45,
                    mt: 4
                }}
            >
                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Restaurant />
                </SvgIcon>

                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Events />
                </SvgIcon>
            </Box>
            {/* <!-- line 4 */}
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 20, // Adjust this for the desired gap
                    ml: 55,
                    mt: 4
                }}
            >
                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Satisfaction />
                </SvgIcon>

                <SvgIcon sx={{
                    width: 70,
                    height: 70,
                    bgcolor: 'white'
                    , borderRadius: '2rem'
                }}>
                    <Tickets />
                </SvgIcon>
            </Box>
        </>
    );
}
export default Landingpage;