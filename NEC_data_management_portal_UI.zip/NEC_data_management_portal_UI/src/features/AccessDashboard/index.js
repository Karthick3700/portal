import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useStyles } from './styles';
import {
  Box,
  Card,
  Grid,
  Breadcrumbs,
  Link,
  Typography,
  TextField,
  Divider,
  Button,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton
} from '@mui/material';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import HomeIcon from '@mui/icons-material/Home';
import { fetchdashboardList, fetchdashboardStreamsList, resetStreamData }
  from '../../redux/dashboard/dashboardSlice';
import { useTranslation } from 'react-i18next';
import { fetchservicerequestCreate, resetStatus } from '../../redux/servicerequest/servicerequestSlice';
import CloseIcon from "@mui/icons-material/Close";
import tickIcon from "../../assets/img/tickIcon.svg";
import alertIcon from "../../assets/img/alerticon.svg";

const AccessDashboard = () => {
  const navigate = useNavigate();
  const [lang, setLang] = React.useState('');
  const [businessDomain, setBusinessDomain] = useState('');
  const [streams, setStreams] = useState([]);
  const [streamLists, setStreamLists] = useState([]);
  const classes = useStyles();
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  const language = useSelector(state => state.language);
  const [dashboardName, setDashboardName] = useState('');
  const [dashboardCustomProperty, setDashboardCustomProperty] = useState({});
  const { data, fetchStatus, fetchStreamStatus, streamData } = useSelector(state => state.dashboardList);
  const [priority, setPriority] = useState('');
  const [purpose, setPurpose] = useState('');
  const [reason, setReason] = useState('');
  const [showReasonField, setShowReasonField] = useState(false);
  const [comment, setComment] = useState('');
  const [isSuccessDialogOpen, setIsSuccessDialogOpen] = useState(false);
  const fetchCreateStatus = useSelector(state => state.servicerequest.fetchCreateStatus);
  const dashboardStreamListData = useSelector(state => state.dashboardList.streamData);
  const [isErrorDialogOpen, setIsErrorDialogOpen] = useState(false);

  const viewDashboardName = localStorage.getItem('permission-dashboard-name');
  const streamName = localStorage.getItem('stream_name');
  const storedCustomProperty = localStorage.getItem('dashboard_custom_property');

  useEffect(() => {
    if (fetchCreateStatus.status && dashboardName !== "") {
      setIsSuccessDialogOpen(true);
    }
  }, [fetchCreateStatus.status]);

  // function to change language
  useEffect(() => {
    i18n.changeLanguage(language);

    if (data && data.output) {
      setStreams(data.output);
    }
  }, [i18n, language, data]);

  useEffect(() => {
    if (dashboardStreamListData && dashboardStreamListData.output.length > 0) {
      setStreamLists(dashboardStreamListData.output);
    }
  }, [dashboardStreamListData]);

  useEffect(() => {
    if (streamName) {
      setBusinessDomain(streamName);
    }
    if (viewDashboardName) {
      setDashboardName(viewDashboardName);
    }
    if (storedCustomProperty) {
      setDashboardCustomProperty(JSON.parse(storedCustomProperty));
    }
  }, [streamName, viewDashboardName, storedCustomProperty]);

  useEffect(() => {
    dispatch(fetchdashboardList());
  }, [dispatch]);

  const handleBusinessDomainChange = (event) => {
    const selectedBusinessDomain = event.target.value;
    setBusinessDomain(selectedBusinessDomain);

    const streamId = streams.find((stream) => stream.stream_name === selectedBusinessDomain)?.stream_id;

    if (streamId) {
      dispatch(fetchdashboardStreamsList({ stream_id: streamId }));

    }
  };

  const handleDashboardChange = (e, currentDashboard) => {
    setDashboardCustomProperty(currentDashboard.custom_properties?.[0] || {})
  };

  const handleCommentChange = (event) => {
    setComment(event.target.value);
  };

  const handlePurposeChange = (event) => {
    setPurpose(event.target.value);
    setShowReasonField(event.target.value === 'Others');
  };

  const handlePriorityChange = (event) => {
    setPriority(event.target.value);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();

    const streamId = streams.find((stream) => stream.stream_name === businessDomain)?.stream_id;
    const formattedPurpose = purpose.toLowerCase() === 'daily operation' ? 'daily_operation' : purpose.toLowerCase();
    const createPayload = {
      request_type: 'dashboard_access',
      business_domain_id: streamId, // Update with the actual business domain ID
      business_domain_name: businessDomain, // Update with the actual business domain name
      dashboard_id: streamId, // Update with the actual dashboard ID
      dashboard_name: dashboardName,
      priority: priority.toLowerCase(),
      purpose: formattedPurpose,
      comment: comment,
      file_id: 1,
      custom_property: dashboardCustomProperty
    };

    if (formattedPurpose === 'others') {
      createPayload.reason = reason;
    }
    if (businessDomain && dashboardName && priority && purpose && comment) {
      dispatch(fetchservicerequestCreate(createPayload));
      setIsSuccessDialogOpen(true);
    } else {
      // Handle case where not all required fields are filled
      setIsErrorDialogOpen(true);
    }
  };

  const closeErrorDialog = () => {
    setIsErrorDialogOpen(false);
  };

  const closeSuccessDialog = () => {
    localStorage.removeItem('permission-dashboard-name');
    localStorage.removeItem('stream_name')
    localStorage.removeItem('dashboard_custom_property')
    setIsSuccessDialogOpen(false);
    dispatch(resetStatus());
    navigate("/dashboard")
  };

  const purposeData = [
    { key: 1, value: 'Daily operation' },
    { key: 2, value: 'Reconciliation' },
    { key: 3, value: 'Monitoring' },
    { key: 4, value: 'Others' }
  ]

  const priorityData = [
    { key: 1, value: 'High' },
    { key: 2, value: 'Medium' },
    { key: 3, value: 'Low' }
  ]

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ p: 0, mb: 3 }}>
        <Box sx={{ pt: 4, px: 3 }}>
          <Breadcrumbs aria-label="breadcrumb">
            <Link
              underline="none"
              to='/home'
              className={classes.breadCrumb}
            >
              Home
            </Link>
            <Link underline="none" to='/request-dashboard' className={classes.activeBreadCrumb}>Access to Dashboard</Link>
          </Breadcrumbs>
        </Box>
        <Box sx={{ width: '100%', px: 3, py: 1 }} className={classes.mainheading}>
          <Typography variant="h1" gutterBottom>
            Access to Dashboard
          </Typography>
        </Box>
      </Box>
      <Box sx={{ px: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} lg={8}>
            <Card className="boxRounded2">
              <Box className="blockHeading2">
                <Typography variant="h3" gutterBottom>
                  Access to Dashboard
                </Typography>
              </Box>
              <Box sx={{ width: '100%', mt: 3 }} component="form">
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Business Domain <span className="required">*</span>
                      </label>

                      {
                        viewDashboardName ?
                          (
                            <TextField
                              sx={{ width: '100%' }}
                              size="small"
                              type="text"
                              placeholder="Businness domain"
                              required
                              value={businessDomain}
                              disabled
                              onChange={(event) => setBusinessDomain(event.target.value)}
                            />
                          ) :
                          <Box className='custom-select'>
                            <FormControl variant="standard" sx={{ width: '100%' }}>
                              <Select
                                value={businessDomain}
                                onChange={handleBusinessDomainChange}
                                label="Select"
                                displayEmpty
                              >
                                <MenuItem value="" disabled>
                                  Please Select
                                </MenuItem>
                                {streams?.map((stream) => (
                                  <MenuItem key={stream.stream_id} value={stream.stream_name}>
                                    {stream.stream_name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                          </Box>
                      }

                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Dashboard Name <span className="required">*</span>
                      </label>

                      {viewDashboardName ? (
                        <TextField
                          sx={{ width: '100%' }}
                          size="small"
                          type="text"
                          placeholder="Enter dashboard name"
                          required
                          disabled
                          value={dashboardName}
                          onChange={(event) => setDashboardName(event.target.value)}
                        />
                      ) : (
                        <Box className='custom-select'>
                          <FormControl variant="standard" sx={{ width: '100%' }}>
                            <Select
                              // value={dashboardName}
                              // onChange={(event) => setDashboardName(event.target.value)}
                              label="Select"
                              displayEmpty
                            >
                              <MenuItem value="" disabled>
                                Please Select
                              </MenuItem>
                              {streamLists?.map((stream) => (
                                <MenuItem key={stream.app_id} value={stream.app_name} onClick={(e) => handleDashboardChange(e, stream)}>
                                  {stream.app_name}
                                </MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                        </Box>
                      )}
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Priority <span className="required">*</span>
                      </label>
                      <Box className='custom-select'>
                        <FormControl variant="standard" sx={{ width: '100%' }}>
                          <Select
                            value={priority}
                            onChange={handlePriorityChange}
                            label="Select"
                            displayEmpty
                          >
                            <MenuItem value="">
                              Please Select
                            </MenuItem>
                            {priorityData.map((item) => (
                              <MenuItem key={item.key} value={item.value}>
                                {item.value}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Purpose <span className="required">*</span>
                      </label>
                      <Box className='custom-select'>
                        <FormControl variant="standard" sx={{ width: '100%' }}>
                          <Select
                            label="Select"
                            displayEmpty
                            value={purpose}
                            onChange={handlePurposeChange}
                          >
                            <MenuItem value="">
                              Please Select
                            </MenuItem>
                            {purposeData.map((item) => (
                              <MenuItem key={item.key} value={item.value}>
                                {item.value}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>

                  {showReasonField && (
                    <Grid item xs={12} md={6}>
                      <Box className="form-group d-flex flex-column w-100">
                        <label>
                          Reason <span className="required">*</span>
                        </label>
                        <TextField
                          sx={{ width: '100%' }}
                          size="small"
                          type="text"
                          placeholder="Enter reason"
                          value={reason}
                          onChange={(event) => setReason(event.target.value)}
                        />
                      </Box>
                    </Grid>
                  )}

                  <Grid item xs={12}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Comments <span className="required">*</span>
                      </label>
                      <TextField
                        sx={{ width: '100%' }}
                        multiline
                        rows={4}
                        size=""
                        type="text"
                        placeholder="Enter here..."
                        className="input-filled textarea"
                        value={comment}
                        onChange={handleCommentChange}
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={12}>
                    <Box sx={{ mb: 3 }}>
                      <Button variant="contained" className="btn-primary" onClick={handleFormSubmit}>
                        Request
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Card>
          </Grid>
        </Grid>
      </Box>

      <Dialog
        open={isSuccessDialogOpen}
        onClose={closeSuccessDialog}
        className="customDialog medium"
      >
        <IconButton
          aria-label="close"
          onClick={closeSuccessDialog}
          className="dialogClose"
        >
          <CloseIcon />
        </IconButton>
        {/* <DialogTitle>Request Created Successfully</DialogTitle> */}
        <DialogContent dividers>
          <Box className='d-flex flex-column'>
            <img src={tickIcon} className='dialogIcon medium' />
            <Typography gutterBottom className='msgText'>
              Your request has been created successfully.
            </Typography>
          </Box>
          <Box className='dialogButtons'>
            <Button
              onClick={closeSuccessDialog}
              variant='outlined'
              className='btn-outline large'
              autoFocus
            >
              OK
            </Button>
          </Box>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isErrorDialogOpen}
        onClose={closeErrorDialog}
        className="customDialog medium"
      >
        <IconButton
          aria-label="close"
          onClick={closeErrorDialog}
          className="dialogClose"
        >
          <CloseIcon />
        </IconButton>

        {/* <DialogTitle>Required Fields Missing</DialogTitle> */}
        <DialogContent dividers>
          <Box className='d-flex flex-column'>
            <img src={alertIcon} className='dialogIcon medium' />
            <Typography gutterBottom className='msgText'>
              Please fill all the required fields.
            </Typography>
          </Box>
          <Box className='dialogButtons'>
            <Button
              onClick={closeErrorDialog}
              variant='outlined'
              className='btn-outline large'
              autoFocus
            >
              OK
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default AccessDashboard;
