import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    // below is example style, please change it
    breadcrumb: {
        padding: 0,
        '& ol li a': {
            fontFamily: 'Roboto, sans-serif',
            fontSize: '0.75rem',
            textTransform: 'uppercase',
    
            '&:hover': {
                color: '#19223B',
            }
        }
    },
    mainheading: {
       '& h1': {
        fontFamily: 'Poppins, sans-serif',
        fontSize: '2rem',
        fontWeight: 500,
        marginBottom:0,
       }
    },
    breadCrumb:{
        textDecoration:"none",
        color:'#19223B !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textTransform: 'uppercase',
    },
    activeBreadCrumb:{
        color:'#9196A7 !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textDecoration: 'none',
        textTransform: 'uppercase',
    },
});

export { useStyles };