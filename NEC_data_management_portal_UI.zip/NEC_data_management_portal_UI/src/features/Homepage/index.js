import {
    Box,
    Container,
    Grid,
    Paper,
    SvgIcon,
    Typography,
    Breadcrumbs,
    Button
} from '@mui/material';
import { Link } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import DynamicFormIcon from '@mui/icons-material/DynamicForm';
import ShareIcon from '@mui/icons-material/Share';
import DataSaverOnIcon from '@mui/icons-material/DataSaverOn';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import StartIcon from '@mui/icons-material/Start';

const Homepage = () => {
    const { t, i18n } = useTranslation();

    // Get language from Redux store
    const language = useSelector(state => state.language);

    useEffect(() => {
        // Change i18n language when `language` changes
        i18n.changeLanguage(language);
    }, [i18n, language]); // add `language` to dependency array

    return (
        <>
        <Box sx={{ width: '100%' }}>
            <Box sx={{ p: 0, mb: 3 }}>
                <Box 
                    sx={{ 
                        width: '100%', 
                        px: 3, 
                        mt: 2, 
                        py: 1, 
                        display: 'flex', 
                        flexDirection: 'column' 
                    }} 
                    className='mainheading'
                >
                    <Typography variant="h1" gutterBottom>
                        {t('home.title')}
                    </Typography>
                    <Typography 
                        sx={{py: 2}}
                        className='dashboardText'
                    >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
                    </Typography>
                </Box>
            </Box>
            <Box sx={{ px: 3 }}>
                <Box display='flex'>
                    <Grid container
                        rowSpacing={1}
                        columnSpacing={
                            {
                                xs: 1,
                                sm: 2,
                                md: 2
                            }
                        }>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={0}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'}>
                                        <Box className='blockHeading truncate'>
                                            <DashboardCustomizeIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.dashbaord_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.dashboard_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/dashboard"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={0}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'} >
                                        <Box className='blockHeading truncate'>
                                            <DynamicFormIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.form_builder_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.form_builder_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/formbuilder"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={0}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'} >
                                        <Box className='blockHeading truncate'>
                                            <ShareIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.sharing_and_Collaboration_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.sharing_and_Collaboration_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/Sharingandcollaboration"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={3}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'} >
                                        <Box className='blockHeading truncate'>
                                            <DataSaverOnIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.data_search_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.data_search_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/Datasearch"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={3}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'} >
                                        <Box className='blockHeading truncate'>
                                            <ImportExportIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.data_import_upload_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.data_import_upload_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/Datasearch"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                        <Grid item
                            xs={12}
                            md={6}
                            xl={4}
                            padding='15px'>
                            <Box borderRadius='15px'>
                                <Paper elevation={0}
                                    sx={
                                        { borderRadius: '15px', overflow: 'hidden' }
                                    }
                                    className='boxRounded2 formbuilder'
                                >
                                    <Box display='flex' padding='0 0 20px' flexDirection={'column'} >
                                        <Box className='blockHeading truncate'>
                                            <DashboardCustomizeIcon sx={{ color: '#fff' }} />
                                            <Typography variant='h3'>
                                                {t('home.request_new_dashboard_title')}
                                            </Typography>
                                        </Box>
                                        <Box className='blocContent minHeightdash'>
                                            <Typography className='dashboardDescText'>
                                                {t('home.request_new_dashboard_desc')}
                                            </Typography>
                                        </Box>
                                        <Box sx={{ mt: 2 }}>
                                            <Button
                                                className='btn-nooutline border-light'
                                                href="/request-dashboard"
                                            >
                                                <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                                            </Button>
                                        </Box>
                                    </Box>
                                </Paper>
                            </Box>
                        </Grid>
                    </Grid>
                    <Grid paddingLeft='20px'>
                        <Paper elevation={3} className='boxRounded' sx={{ height: 'calc(100% - 16px)', p: 0 }}>
                            <Box display='flex' padding='0 20px 20px' flexDirection={'column'}>
                                <Box className='blockHeading truncate'>
                                    <StartIcon sx={{ color: '#fff' }} />
                                    <Typography variant='h3'>
                                        {t('home.quick_access')}
                                    </Typography>
                                </Box>
                                <Box sx={{ pt: 1, pb: 2 }}>
                                    <Typography className='dashboardText'>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                    </Typography>
                                </Box>

                                <Box sx={{ my: 1, boxShadow: 'none' }}>
                                    <Box display='flex' justifyContent='space-between'>
                                        <Box sx={{ width: '100%' }}>
                                            <Button
                                                variant='contained'
                                                className='btn-gradient'
                                                endIcon={<ArrowForwardIosIcon sx={{ pl: 1, width: 16, boxShadow: 'none' }} />}
                                                sx={
                                                    {
                                                        width: '100%',
                                                        justifyContent: 'space-between'
                                                    }
                                                }>
                                                Dashboard 1
                                            </Button>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box sx={{ my: 1, boxShadow: 'none' }}>
                                    <Box display='flex' justifyContent='space-between'>
                                        <Box sx={{ width: '100%' }}>
                                            <Button
                                                variant='contained'
                                                className='btn-gradient'
                                                endIcon={<ArrowForwardIosIcon sx={{ pl: 1, width: 16, boxShadow: 'none' }} />}
                                                sx={
                                                    {
                                                        width: '100%',
                                                        justifyContent: 'space-between'
                                                    }
                                                }>
                                                Dashboard 2
                                            </Button>
                                        </Box>
                                    </Box>
                                </Box>

                                <Box sx={{ my: 1, boxShadow: 'none' }}>
                                    <Box display='flex' justifyContent='space-between'>
                                        <Box sx={{ width: '100%' }}>
                                            <Button
                                                variant='contained'
                                                className='btn-gradient'
                                                endIcon={<ArrowForwardIosIcon sx={{ pl: 1, width: 16, boxShadow: 'none' }} />}
                                                sx={
                                                    {
                                                        width: '100%',
                                                        justifyContent: 'space-between'
                                                    }
                                                }>
                                                Dashboard 3
                                            </Button>
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                        </Paper>
                    </Grid>
                </Box>
            </Box>
        </Box>
        </>
    );
}

export default Homepage;
