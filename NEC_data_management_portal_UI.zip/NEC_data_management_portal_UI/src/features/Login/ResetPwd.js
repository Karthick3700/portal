import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  Avatar,
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Typography,
  Container,
  SvgIcon,
  IconButton,
  Dialog,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import {
  CheckCircleOutline as CheckCircleOutlineIcon,
  Close as CloseIcon,
  ErrorOutline as ErrorOutlineIcon,
  LockOutlined as LockOutlinedIcon
} from '@mui/icons-material';
import { ReactComponent as Logo } from "../../assets/logo.svg";
import { initResetPassword, resetUserRegisterData } from "../../redux/users/slice";

const ResetPwd = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();

  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    token: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});

  const userResponseStatus = useSelector((state) => state.users.userResponseStatus) || "error";
  const userResponseMessage = useSelector((state) => state.users.userResponseMessage);

  const validateForm = () => {
    let valid = true;
    let newErrors = {};

    if (!formData.password) {
      newErrors.password = "Password is required.";
      valid = false;
    } else if (formData.password.length < 8) {
      newErrors.password = "Password should be at least 8 characters long.";
      valid = false;
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let newErrors = { ...errors };

    switch (name) {
      case "password":
        if (!value) {
          newErrors.password = "Password is required.";
        } else if (value.length < 8) {
          newErrors.password = "Password should be at least 8 characters long.";
        } else {
          delete newErrors.password;
        }
        break;
      case "confirmPassword":
        if (value !== formData.password) {
          newErrors.confirmPassword = "Passwords do not match.";
        } else {
          delete newErrors.confirmPassword;
        }
        break;
      default:
        break;
    }

    setErrors(newErrors);
    setFormData({ ...formData, [name]: value });
  };

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const token = params.get("token");
    setFormData((prevData) => ({ ...prevData, token }));
  }, [location.search]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (validateForm()) {
      const data = new FormData(event.currentTarget);

      const bodyData = {
        token: formData.token,
        password: data.get("password"),
        confirm_password: data.get("confirmPassword"),
      };

      try {
        dispatch(initResetPassword(bodyData));
      } catch (error) {
        console.error(error);
      }
    }
  };

  useEffect(() => {
    return () => {
      dispatch(resetUserRegisterData());
    };
  }, [dispatch]);

  useEffect(() => {
    if (userResponseMessage && userResponseStatus) {
      if (userResponseStatus === 'success') {
        setFormData({
          token: "",
          password: "",
          confirmPassword: ""
        })
      }
      handleOpen();
    } else {
      handleClose();
    }
  }, [userResponseMessage, userResponseStatus]);

  const styles = {
    container: {
      marginTop: 2,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      background: "#fff",
      boxShadow: 3,
      borderRadius: 2,
      px: 4,
      py: 2,
    },
    form: { mt: 3 },
    button: {
      mt: 3,
      mb: 2,
      justifyContent: "center",
    },
    dialogTitle: { m: 0, p: 2 },
    dialogContent: { m: 2 },
    icon: { display: "flex", width: "100%", justifyContent: "center", m: 4 },
  };

  return (
    <Container component="main" maxWidth="xs" sx={{ marginBottom: 5 }}>
      <CssBaseline />
      <Box sx={{ display: "flex", justifyContent: "center", cursor: "pointer" }}>
        <SvgIcon
          sx={{ height: "50px", width: "350px", padding: "0 10px" }}
          component={Logo}
          onClick={() => navigate("/")}
          inheritViewBox
        />
      </Box>
      <Box sx={styles.container}>
        <Avatar sx={{ m: 1, bgcolor: "#e51448" }}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Reset Password
        </Typography>
        <Box component="form" noValidate onSubmit={handleSubmit} sx={styles.form}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="new-password"
                value={formData.password}
                error={errors.password ? true : false}
                helperText={errors.password}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                name="confirmPassword"
                label="Confirm Password"
                type="password"
                id="confirmPassword"
                autoComplete="confirm-password"
                value={formData.confirmPassword}
                error={errors.confirmPassword ? true : false}
                helperText={errors.confirmPassword}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
          <Grid
            container
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              background: "#fff",
              justifyContent: "center",
            }}
          >
            <Grid item xs={12} justifyContent="center">
              <Button
                type="submit"
                variant="contained"
                sx={styles.button}
                className="btn-primary"
                style={{ justifyContent: "center" }}
              >
                Reset Password
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Dialog onClose={handleClose} open={open}>
        <DialogTitle sx={styles.dialogTitle} id="customized-dialog-title" />
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent sx={styles.dialogContent}>
          <div style={styles.icon}>
            {userResponseStatus === "error" ? (
              <ErrorOutlineIcon color="error" fontSize="large" />
            ) : (
              <CheckCircleOutlineIcon color="success" fontSize="large" />
            )}
          </div>
          <Typography sx={{ m: 2 }}>{userResponseMessage}</Typography>
        </DialogContent>
      </Dialog>
    </Container>
  );
};

export default ResetPwd;