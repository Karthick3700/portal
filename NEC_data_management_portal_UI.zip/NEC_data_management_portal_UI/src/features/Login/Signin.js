import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  Grid,
  Box,
  Typography,
  TextField,
  Button,
  SvgIcon,
  Paper,
  FormControl,
  InputAdornment,
  OutlinedInput,
  IconButton,
} from "@mui/material";
import { ReactComponent as Logo } from "../../assets/logo.svg";
import { initUserInfo, resetUserRegisterData } from "../../redux/users/slice";
import AlertMessage from "../../app/common/AlertMessage";
import { Visibility, VisibilityOff } from '@mui/icons-material';

const Signin = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [isAlertMessage, setIsAlertMessage] = useState(false);

  const userResponseStatus = useSelector((state) => state.users.userResponseStatus) || "error";
  const userResponseMessage = useSelector((state) => state.users.userResponseMessage);

  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email || !password) {
      setEmailError(!email);
      setPasswordError(!password);
      return;
    }
    const data = new FormData(event.currentTarget);
    const userData = {
      email: data.get("email"),
      password: data.get("password"),
    };
    dispatch(
      initUserInfo({ username: userData.email, password: userData.password })
    );
  };

  useEffect(() => {
    return () => {
      dispatch(resetUserRegisterData());
    };
  }, [dispatch]);

  useEffect(() => {
    if (userResponseMessage && userResponseStatus) {
      setIsAlertMessage(true);
    } else {
      setIsAlertMessage(false);
    }
  }, [userResponseMessage, userResponseStatus])

  useEffect(() => {
    if (!isAlertMessage) {
      setTimeout(() => {
        dispatch(resetUserRegisterData());
      }, 400);
    }
  }, [dispatch, isAlertMessage]);

  return (
    <Box className='LoginContainer'>
      <Box className='LogoContainer'>
        <SvgIcon
          sx={{
            height: "auto",
            width: "300px",
            padding: "0",
          }}
          component={Logo}
          onClick={() => navigate('/')}
          inheritViewBox
        />
      </Box>
      <Paper elevation={0} className='LoginBox'>
        <Box>
          <AlertMessage 
            type={userResponseStatus} 
            message={userResponseMessage} 
            open={isAlertMessage} 
            onClose={() => setIsAlertMessage(false)} 
          />
          <Box className='mainheading'>
            <Typography variant="h2" gutterBottom>
                Sign in
            </Typography>
          </Box>
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
            <FormControl variant="outlined" className='formGroup'>
              <OutlinedInput
                className="inputField"
                placeholder="Enter Email Address"
                margin="normal"
                required
                fullWidth
                id="email"
                label=""
                name="email"
                autoComplete="email"
                autoFocus
                value={email}
                error={emailError}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setEmailError(false);
                  setIsAlertMessage(false);
                }}
                onBlur={() => {
                  const emailRegex = /^\S+@\S+\.\S+$/;
                  if (!email.match(emailRegex)) {
                    setEmailError(true);
                  }
                }}
                helperText={emailError ? "Please enter a valid email" : ""}
              />
            </FormControl>
            <FormControl variant="outlined" className='formGroup'>
              <OutlinedInput
                className="inputField"
                placeholder="Password"
                margin="normal"
                required
                fullWidth
                name="password"
                label=""
                type={showPassword ? 'text' : 'password'}
                id="password"
                autoComplete="current-password"
                value={password}
                error={passwordError}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setPasswordError(false);
                  setIsAlertMessage(false);
                }}
                onBlur={() => {
                  if (!password) {
                    setPasswordError(true);
                  }
                }}
                helperText={passwordError ? "Please enter a password" : ""}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={(e) => e.preventDefault()}
                      edge="end"
                      sx={{ py: 0, top: '-1px' }}
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl>
              <Box className='d-flex flex-row align-items-center justify-content-between'>
                <Button
                  type="submit"
                  variant="contained"
                  className="btn-primary"
                >
                  Sign In
                </Button>
                <Link to="/forgot-password" className="link-text">
                  Forgot password?
                </Link>
              </Box>
              <Box className='d-flex justify-content-center' sx={{mt:2}}>
                <Typography className="FontInter">
                  Don't have an account?   
                    <Link to="/signup" className="link-text">
                      {`Sign Up`}
                    </Link>
                </Typography>
              </Box>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default Signin;
