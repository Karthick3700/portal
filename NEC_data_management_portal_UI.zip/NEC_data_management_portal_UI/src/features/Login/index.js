import React from "react";
import Footer from "../../app/component/Footer";
import {
  Box,
} from "@mui/material";
import background from "../../assets/backgroundvideo.mp4";
import Signin from "./Signin";

const LoginPage = ({ children }) => {
  // Define state in the parent component
  return (
    <Box
      position="relative"
      overflow="auto"
      style={{ minHeight: "80vh", width: "100%" }}
    >
      {/* <video
        autoPlay
        loop
        muted
        style={{
          position: "fixed",
          width: "100%",
          left: "50%",
          top: "50%",
          minHeight: "100%",
          minWidth: "100%",
          objectFit: "cover",
          transform: "translate(-50%, -50%)",
          zIndex: "-1",
        }}
      >
        <source src={background} type="video/mp4" />
      </video> */}
      <Signin />
      {/* <Footer /> */}
    </Box>
  );
};

export default LoginPage;

