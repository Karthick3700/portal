import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  Avatar,
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Typography,
  Container,
  SvgIcon,
  IconButton,
  Dialog,
  DialogContent,
  DialogTitle,
  Paper,
  OutlinedInput,
  InputAdornment,
} from "@mui/material";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import CloseIcon from "@mui/icons-material/Close";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { ReactComponent as Logo } from "../../assets/logo.svg";
import AlertMessage from "../../app/common/AlertMessage";
import { initRegisterInfo, resetUserRegisterData } from "../../redux/users/slice";
import { Visibility, VisibilityOff } from '@mui/icons-material';
import tickIcon from '../../assets/img/tickIcon.svg';

const SignUp = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    mobileCode: "",
    mobileNumber: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});
  const [isAlertMessage, setIsAlertMessage] = useState(false);

  const userResponseStatus = useSelector((state) => state.users.userResponseStatus) || "error";
  const userResponseMessage = useSelector((state) => state.users.userResponseMessage);

  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const [showPassword2, setShowPassword2] = useState(false);
  const handleClickShowPassword2 = () => setShowPassword2((show) => !show);

  const validateForm = () => {
    let valid = true;
    let newErrors = {};

    if (!formData.firstName) {
      newErrors.firstName = "First name is required.";
      valid = false;
    }

    if (!formData.lastName) {
      newErrors.lastName = "Last name is required.";
      valid = false;
    }

    if (!formData.email) {
      newErrors.email = "Email is required.";
      valid = false;
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Invalid email format.";
      valid = false;
    }

    if (!formData.mobileCode) {
      newErrors.mobileCode = "Mobile code is required.";
      valid = false;
    } else if (!/^\+[0-9]+$/.test(formData.mobileCode)) {
      newErrors.mobileCode = "Mobile code should start with a single plus sign and contain only numbers.";
      valid = false;
    }

    if (!formData.mobileNumber) {
      newErrors.mobileNumber = "Mobile number is required.";
      valid = false;
    } else if (!/^[0-9]+$/.test(formData.mobileNumber)) {
      newErrors.mobileNumber = "Mobile number should contain only numbers.";
      valid = false;
    }

    if (!formData.password) {
      newErrors.password = "Password is required.";
      valid = false;
    } else if (formData.password.length < 8) {
      newErrors.password = "Password should be at least 8 characters long.";
      valid = false;
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let newErrors = { ...errors };

    switch (name) {
      case "firstName":
        if (!value) {
          newErrors.firstName = "First name is required.";
        } else {
          delete newErrors.firstName;
        }
        break;
      case "lastName":
        if (!value) {
          newErrors.lastName = "Last name is required.";
        } else {
          delete newErrors.lastName;
        }
        break;
      case "email":
        if (!value) {
          newErrors.email = "Email is required.";
        } else if (!/^\S+@\S+\.\S+$/.test(value)) {
          newErrors.email = "Invalid email format.";
        } else {
          delete newErrors.email;
        }
        break;
      case "mobileCode":
        if (!value) {
          newErrors.mobileCode = "Mobile code is required.";
        } else if (!/^\+[0-9]+$/.test(value)) {
          newErrors.mobileCode =
            "Mobile code should start with a single plus sign and contain only numbers.";
        } else {
          delete newErrors.mobileCode;
        }
        break;
      case "mobileNumber":
        if (!value) {
          newErrors.mobileNumber = "Mobile number is required.";
        } else if (!/^[0-9]+$/.test(value)) {
          newErrors.mobileNumber = "Mobile number should contain only numbers.";
        } else {
          delete newErrors.mobileNumber;
        }
        break;
      case "password":
        if (!value) {
          newErrors.password = "Password is required.";
        } else if (value.length < 8) {
          newErrors.password = "Password should be at least 8 characters long.";
        } else {
          delete newErrors.password;
        }
        break;
      case "confirmPassword":
        if (value !== formData.password) {
          newErrors.confirmPassword = "Passwords do not match.";
        } else {
          delete newErrors.confirmPassword;
        }
        break;
      default:
        break;
    }

    setIsAlertMessage(false);
    setErrors(newErrors);
    setFormData({ ...formData, [name]: value });
  };

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (validateForm()) {
      const data = new FormData(event.currentTarget);

      const formData = {
        usr_email_id: data.get("email"),
        usr_password: data.get("password"),
        usr_first_name: data.get("firstName"),
        usr_last_name: data.get("lastName"),
        usr_login_id: data.get("email"),
        usr_mob_code: data.get("mobileCode"),
        usr_mobile_number: data.get("mobileNumber"),
      };

      try {
        dispatch(initRegisterInfo(formData));
      } catch (error) {
        console.error(error);
      }
    }
  };

  useEffect(() => {
    return () => {
      dispatch(resetUserRegisterData());
    };
  }, [dispatch]);

  useEffect(() => {
    if (userResponseMessage && userResponseStatus) {
      if (userResponseStatus === 'success') {
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          mobileCode: "",
          mobileNumber: "",
          password: "",
          confirmPassword: ""
        })
      }
      setIsAlertMessage(true);
    } else {
      setIsAlertMessage(false);
    }
  }, [userResponseMessage, userResponseStatus])

  useEffect(() => {
    if (!isAlertMessage) {
      setTimeout(() => {
        dispatch(resetUserRegisterData());
      }, 400);
    }
  }, [dispatch, isAlertMessage]);

  const styles = {
    container: {
      marginTop: 2,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      background: "#fff",
      boxShadow: 3,
      borderRadius: 2,
      px: 4,
      py: 2,
    },
    form: { mt: 3 },
    button: {
      mt: 3,
      mb: 2,
      justifyContent: "center",
    },
    dialogTitle: { m: 0, p: 2 },
    dialogContent: { m: 2 },
    icon: { display: "flex", width: "100%", justifyContent: "center", m: 4 },
  };

  return (
    <Box className='LoginContainer'>
      <Box className='LogoContainer'>
        {/* <CssBaseline /> */}
        <SvgIcon
          sx={{ 
            height: "auto", 
            width: "300px", 
            padding: "0" 
          }}
          component={Logo}
          onClick={() => navigate("/")}
          inheritViewBox
        />
      </Box>
      <Paper elevation={0} className='LoginBox'>
        <Box>
          <AlertMessage 
            type={userResponseStatus} 
            message={userResponseMessage} 
            open={isAlertMessage} onClose={() => setIsAlertMessage(false)} 
          />
          {/* <Avatar sx={{ m: 1, bgcolor: "#e51448" }}>
            <LockOutlinedIcon />
          </Avatar> */}
          <Typography component="h1" variant="h5">
            Sign up
          </Typography>
          <Box component="form" noValidate onSubmit={handleSubmit} sx={styles.form}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6} marginTop={1}>
                <OutlinedInput
                 className="inputField"
                  placeholder="First Name"
                  autoComplete="given-name"
                  name="firstName"
                  required
                  fullWidth
                  id="firstName"
                  label=""
                  autoFocus
                  value={formData.firstName}
                  error={errors.firstName ? true : false}
                  helperText={errors.firstName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} sm={6} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Last Name"
                  required
                  fullWidth
                  id="lastName"
                  label=""
                  name="lastName"
                  autoComplete="family-name"
                  value={formData.lastName}
                  error={errors.lastName ? true : false}
                  helperText={errors.lastName}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Email Address"
                  required
                  fullWidth
                  id="email"
                  label=""
                  name="email"
                  autoComplete="email"
                  value={formData.email}
                  error={errors.email ? true : false}
                  helperText={errors.email}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} sm={6} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Mobile Code"
                  required
                  fullWidth
                  id="mobileCode"
                  label=""
                  name="mobileCode"
                  autoComplete="mobileCode"
                  value={formData.mobileCode}
                  error={errors.mobileCode ? true : false}
                  helperText={errors.mobileCode}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} sm={6} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Mobile Number"
                  required
                  fullWidth
                  id="mobileNumber"
                  label=""
                  name="mobileNumber"
                  autoComplete="mobile"
                  value={formData.mobileNumber}
                  error={errors.mobileNumber ? true : false}
                  helperText={errors.mobileNumber}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Password"
                  required
                  fullWidth
                  name="password"
                  label=""
                  type={showPassword2 ? 'text' : 'password'}
                  id="password"
                  autoComplete="new-password"
                  value={formData.password}
                  error={errors.password ? true : false}
                  helperText={errors.password}
                  onChange={handleChange}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword2}
                        onMouseDown={(e) => e.preventDefault()}
                        edge="end"
                        sx={{ py: 0, top: '-1px' }}
                      >
                        {showPassword2 ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </Grid>
              <Grid item xs={12} marginTop={1}>
                <OutlinedInput
                  className="inputField"
                  placeholder="Confirm Password"
                  required
                  fullWidth
                  name="confirmPassword"
                  label=""
                  type={showPassword ? 'text' : 'password'}
                  id="confirmPassword"
                  autoComplete="confirm-password"
                  value={formData.confirmPassword}
                  error={errors.confirmPassword ? true : false}
                  helperText={errors.confirmPassword}
                  onChange={handleChange}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={(e) => e.preventDefault()}
                        edge="end"
                        sx={{ py: 0, top: '-1px' }}
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </Grid>
            </Grid>
            <Box className='d-flex flex-row justify-content-between'>
                <Button
                  type="submit"
                  variant="contained"
                  sx={styles.button}
                  className="btn-primary"
                >
                  Sign Up
                </Button>
            </Box>
            <Box className='d-flex justify-content-center' sx={{mt:2}}>
              <Typography className="FontInter">
                  Already have an account?
                  <Link to="/login" className="link-text">
                    {`Sign in`}
                  </Link>
              </Typography>
            </Box>
          </Box>
        </Box>
      </Paper>
        <Dialog 
          onClose={handleClose} 
          open={open} 
          className="customDialog"
        >
          <DialogTitle id="customized-dialog-title" />
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
            className='dialogClose'
          >
            <CloseIcon />
          </IconButton>
          <DialogContent sx={{p:4}}>
            {/* <div style={styles.icon}>
              <CheckCircleOutlineIcon color="success" fontSize="large" />
            </div> */}
            <img src={tickIcon} className="dialogIcon" />
            <Typography className="msgText">Successfully Registered</Typography>
            <Box className='dialogButtons' sx={{mt:2, display: 'flex', justifyContent: 'center'}}>
              <Button 
                variant='outlined' 
                className='btn-outline large' 
                onClick={handleClose}
              >
                Close
              </Button>
            </Box>
          </DialogContent>
        </Dialog>
    </Box>
  );
};

export default SignUp;