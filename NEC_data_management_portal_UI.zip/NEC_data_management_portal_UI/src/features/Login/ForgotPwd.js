import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  Button,
  CssBaseline,
  TextField,
  Grid,
  Box,
  Typography,
  Container,
  SvgIcon,
  IconButton,
  Dialog,
  DialogContent,
  DialogTitle,
  Paper,
  OutlinedInput,
  FormControl,
} from "@mui/material";
import {
  CheckCircleOutline as CheckCircleOutlineIcon,
  Close as CloseIcon,
  ErrorOutline as ErrorOutlineIcon
} from '@mui/icons-material';
import { initForgotPassword, resetUserRegisterData } from "../../redux/users/slice";
import { ReactComponent as Logo } from "../../assets/logo.svg";
import alertIcon from '../../assets/img/alerticon.svg';
import tickIcon from '../../assets/img/tickIcon.svg';

const styles = {
  logo: {
    height: "auto",
    width: "300px",
  },
  dialogContent: {
    display: "flex",
    width: "100%",
    justifyContent: "center",
    margin: 4,
  },
};

export default function ForgotPwd() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState(false);

  const userResponseStatus = useSelector((state) => state.users.userResponseStatus) || "error";
  const userResponseMessage = useSelector((state) => state.users.userResponseMessage);

  const handleOpen = () => setOpen(true);
  const handleClose = () => {
    setOpen(false);
    dispatch(resetUserRegisterData());
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email) {
      setEmailError(!email);
      return;
    }
    const data = new FormData(event.currentTarget);
    const userData = {
      email: data.get("email")
    };

    dispatch(
      initForgotPassword({ email: userData.email })
    );
  };

  useEffect(() => {
    return () => {
      dispatch(resetUserRegisterData());
    };
  }, [dispatch]);

  useEffect(() => {
    if (userResponseMessage && userResponseStatus) {
      handleOpen();
    } else {
      handleClose();
    }
  }, [userResponseMessage, userResponseStatus]);

  return (
    <Box className='LoginContainer'>
      <Box className='LogoContainer'>
          {/* <CssBaseline /> */}
          <SvgIcon
            sx={styles.logo}
            component={Logo}
            onClick={() => navigate("/")}
            inheritViewBox
          />
        </Box>
        <Paper elevation={0} className='LoginBox'>
          <Box>
            <Box className='mainheading'>
              <Typography variant="h2" gutterBottom>
                  Forgot Password
              </Typography>
            </Box>
            <Box
              component="form"
              noValidate
              onSubmit={handleSubmit}
              sx={{ mt: 1 }}
            >
            <FormControl variant="outlined" className='formGroup'>
              <OutlinedInput
                  className="inputField"
                  placeholder="Enter Email Address"
                  margin="normal"
                  required
                  fullWidth
                  id="email"
                  label=""
                  name="email"
                  autoComplete="email"
                  autoFocus
                  value={email}
                  error={emailError}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setEmailError(false);
                  }}
                  onBlur={() => {
                    const emailRegex = /^\S+@\S+\.\S+$/;
                    if (!email.match(emailRegex)) {
                      setEmailError(true);
                    }
                  }}
                  helperText={emailError ? "Please enter a valid email" : ""}
                />
            </FormControl>
              <Box className='d-flex'>
                <Button
                  type="submit"
                  variant="contained"
                  sx={{justifyContent: "center" }}
                  className="btn-primary"
                >
                  Submit
                </Button>
              </Box>
              <Box className='d-flex justify-content-center' sx={{mt:2}}>
                <Typography className="FontInter">
                  Already have an account?   
                    <Link to="/login" className="link-text">
                      {`Sign In`}
                    </Link>
                </Typography>
              </Box>
            </Box>
          </Box>
        </Paper>
        <Dialog 
          onClose={handleClose} 
          aria-labelledby="customized-dialog-title" 
          open={open} 
          className="customDialog"
        >
          <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title" />
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
            className='dialogClose'
          >
            <CloseIcon />
          </IconButton>
          <DialogContent sx={{p:4}}>
            <div style={styles.dialogContent}>
              {userResponseStatus === "error" ? (
                // <ErrorOutlineIcon color="error" fontSize="large" />
                <img src={alertIcon} className="dialogIcon" />
              ) : (
                // <CheckCircleOutlineIcon color="success" fontSize="large" />
                <img src={tickIcon} className="dialogIcon" />
              )}
            </div>
            <Typography className="msgText">
              {userResponseMessage}
            </Typography>
            <Box className='dialogButtons' sx={{mt:2, display: 'flex', justifyContent: 'center'}}>
              <Button 
                variant='outlined' 
                className='btn-outline large' 
                onClick={handleClose}
              >
                Close
              </Button>
            </Box>
          </DialogContent>
        </Dialog>
    </Box>
  );
}
