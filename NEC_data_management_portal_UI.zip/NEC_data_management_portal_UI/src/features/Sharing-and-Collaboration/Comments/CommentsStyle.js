import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({

  titleMainContainer:{
    height: 60,
    display: 'flex',
    alignItems: 'center',
    padding:'5px 30px',
    alignItems: 'center',
    borderBottom: '1px solid #E3EAF1'
  },
})

export{ useStyles };