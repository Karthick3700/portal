import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({

    userText:{
        fontSize:'16px !important', 
        fontWeight: 400,
        color:'#999 !important',
        marginLeft:'5px !important',
        textTransform:'capitalize',
        lineHeight: 'normal !important'
    },
    commentContainer:{
        display:'flex', 
        alignItems:'center',
        backgroundColor: '#fff',
        borderRadius: 10,
    },
    commentMainContainer:{
        display:'flex',
        justifyContent:'space-between'
    },
    timerText:{
     fontSize:'12px !important',
     color:'#B2B2B2 !important'
    }

});

export { useStyles };