import React from 'react';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import { useStyles } from './CommentCardStyle';
import { ReactComponent as CommentIcon } from '../../../../assets/comment.svg';
import { Box, Link } from '@mui/material';

const CommentCard = ({
  msg,
  minimumWidth,
  username
}) => {
  const classes = useStyles();
  const getFilename = (path) => {
    return path.split('\\').pop().split('/').pop();
  };
  const openAttachment = (attachedFile) => {
    
    const fullPath = attachedFile;
    const segments = fullPath.split('\\');
    const filename = segments.pop(); 
    const url = `http://localhost:3006/comment_files/${filename}`;
    window.open(url, '_blank');
    
  };
  return (
    <Card elevation={0}
      sx={{
        borderBottom: 'solid 1px #E3EAF1',
        minWidth: minimumWidth ? minimumWidth : '400px'
      }}
    >
      <CardHeader
        sx={{ mx: 2 }}
        avatar={
          <Avatar sx={{ bgcolor: red[500], textTransform: 'capitalize' }} aria-label="recipe">
            {username?.charAt(0) ?? msg?.user_id}
          </Avatar>
        }
        title={
          <Box className={classes.commentMainContainer}>
            <Box className={classes.commentContainer}>
              <Box sx={{ width: 30, height: 30, display: 'flex', alignItems: 'center' }}><CommentIcon /></Box>
              <Typography className={classes.userText}>
                <strong>{username ?? msg?.user_id}</strong>
              </Typography>
            </Box>
          </Box>
        }
      />
      <CardContent className='chatBox arrow-left-center' sx={{ ml: 3, mr: 1, mb: 2, p: 1 }}>
        <Typography variant="body2">
          {msg?.comment_data}
        </Typography>
        {msg?.attachedFile && ( // Only display if an attached file exists
           <Typography
           component="span"
           style={{ cursor: 'pointer', color: 'blue', textDecoration: 'underline' }}
           onClick={() => openAttachment(msg.attachedFile)}
         >
          {getFilename(msg.attachedFile)}
         </Typography>
        )}
      </CardContent>
    </Card>
  );
}

export default CommentCard;
