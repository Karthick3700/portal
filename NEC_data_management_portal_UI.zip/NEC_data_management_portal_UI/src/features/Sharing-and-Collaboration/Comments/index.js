import React, { useState, useEffect } from 'react';
import { Box, IconButton, InputAdornment, TextField, Typography } from '@mui/material';
import { Search, AttachFile, Send } from '@mui/icons-material';
import { useStyles } from './CommentsStyle';
import CommentCard from './components/CommentCard';
import io from 'socket.io-client';
import { ReactComponent as SendIcon } from '../../../assets/send.svg';
import { useSelector, useDispatch } from 'react-redux';
import {
    fetchSharingList
} from '../../../redux/sharinglist/sharingListSlice'


const socket = io('http://localhost:3006');
const Comments = ({ form_id, space_id, isSearch, isComment,commentTag, minimumWidth }) => {
    const classes = useStyles();
    const dispatch = useDispatch();
    const [messages, setMessages] = useState([]);
    const [allmessages, setAllMessages] = useState([]);
    const [input, setInput] = useState('');
    const userdata = sessionStorage.getItem("user");
    const userdetails = JSON.parse(userdata);
    const spaceListData = useSelector(state => state.sharingList);

    const currentSpaceId = space_id;
    const currentSpace = spaceListData.data.find(space => space.space_id === currentSpaceId);
    let userFirstNames;
    if (currentSpace && Array.isArray(currentSpace.spaceUser)) {
        userFirstNames = currentSpace.spaceUser.map(user => {
            return { usr_first_name: user.user_details.usr_first_name };
        });

    } else {
        console.log('Current space or its users are not available');
    }
    const emails = userFirstNames;
    const {
        usr_id_pk
    } = userdetails;
    const [emailSuggestions, setEmailSuggestions] = useState([]);
    // When component mounts, set up the socket event listeners

    useEffect(() => {
        dispatch(fetchSharingList());
    }, [dispatch]);

    useEffect(() => {
        if (space_id) {
            // Emit 'fetchAllComments' event when the component mounts
            socket.emit('fetchCommentsbySpaceId', space_id);

            socket.on('initialComments', (comments) => {
                const allComments = comments && comments?.length > 0
                    ? comments?.filter(com => com.space_id === space_id) : [];
                setMessages(allComments);
            });

            socket.on('commentsUpdated', (comments) => {
                const updatedComments = comments && comments?.length > 0
                    ? comments?.filter(com => com.space_id === space_id) : [];
                setMessages(updatedComments);
            });

            return () => {
                socket.off('initialComments');
                socket.off('commentsUpdated');
            };
        }

    }, [space_id]);

    useEffect(() => {
        if (messages && messages?.length > 0) {
            setAllMessages(messages);
        }
    }, [messages]);


    const handleSearch = (e) => {
        const { value } = e.target;
        const filteredMessages =
            value
                && value?.length > 0
                ? allmessages?.filter(inp => {
                    return inp?.comment_data.toLowerCase().match(value.trim().toLowerCase())
                }) : messages;
        setAllMessages(filteredMessages);
    }

    const allComments = allmessages
        && allmessages?.length > 0
        && allmessages?.map((msg, index) => {
            return (
                <CommentCard
                    key={index}
                    username={`${msg.usr_first_name} ${msg.usr_last_name}`}
                    minimumWidth={minimumWidth}
                    msg={msg}
                />
            );
        });
    const [selectedFile, setSelectedFile] = useState(null);
    const [selectedFileName, setSelectedFileName] = useState("");
    const handleFileChange = (event) => {
        // Assuming only one file is selected
        setSelectedFile(event.target.files[0]);
        setSelectedFileName(event.target.files[0].name);
    };
    const handleEmailInput = (e) => {
        const currentUserFirstName = userdetails && userdetails.usr_first_name;
        const { value } = e.target;
        setInput(value);
        if (value.includes('@')) {
            const inputAfterAt = value.split('@')[1];
            const suggestions = emails
                .filter(emailObj => {
                    return emailObj.usr_first_name !== currentUserFirstName &&
                       emailObj.usr_first_name.includes(inputAfterAt);
                })
                .map(emailObj => emailObj.usr_first_name);
            setEmailSuggestions(suggestions);
        } else {
            setEmailSuggestions([]);
        }
    };
    const handleSuggestionClick = (suggestion) => {
        setInput(input.split('@')[0] + '@' + suggestion);
        setEmailSuggestions([]);
    };
     
    const submitMessage = () => {
        const reader = new FileReader();

        reader.onload = (e) => {
            const base64File = e.target.result;

            const message = {
                user_id: usr_id_pk,
                space_id: space_id,
                comment_data: input,
                attachedFile: base64File
            };

            // Emit a new 'newComment' event with the new message
            socket.emit('newComment', message);

            setInput('');
            setSelectedFile(null);
            setSelectedFileName(""); // Clear the selected file name
        document.getElementById("contained-button-file").value = ""; // Clear the file input value
        };

        if (selectedFile) {
            reader.readAsDataURL(selectedFile);
        } else {
            // If no file is selected, emit the message without a file
            const message = {
                user_id: usr_id_pk,
                space_id: space_id,
                comment_data: input
            };

            socket.emit('newComment', message);

            setInput('');
            setSelectedFile(null);
        setSelectedFileName(""); // Clear the selected file name
        document.getElementById("contained-button-file").value = ""; 
        }
    };


    return (
        <Box width='100%'>
            <Box className={classes.titleMainContainer}>
                <Typography>
                    Comments
                </Typography>
            </Box>
            <Box height='625px' >
                {isSearch && <Box paddingTop={2} paddingX={3}>
                    <TextField
                        fullWidth
                        size="small"
                        onChange={handleSearch}
                        placeholder='Search'
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <Search />
                                </InputAdornment>
                            ),
                            style: {
                                background: '#FCFDFF',
                                border: '1px solid #E3EAF1',
                            }
                        }}
                    />
                </Box>}
                <Box sx={{ overflowY: 'scroll' }} height='550px'>
                    {allComments}
                </Box>
                {commentTag && (
                    <Box padding={2} position="relative">

                        {input.includes('@') && emailSuggestions.length > 0 && (
                            <Box sx={{ backgroundColor: '#fff'}}>
                                {emailSuggestions.map((suggestion, index) => (
                                    <div key={index} onClick={() => handleSuggestionClick(suggestion)}>
                                        {suggestion}
                                    </div>
                                ))}
                            </Box>
                        )}
                    </Box>
                )}

                <TextField
                    fullWidth
                    size="small"
                    placeholder='Type Comment here'
                    variant="standard"
                    className='input-filled search-box'
                    InputProps={{
                        endAdornment: (
                            <InputAdornment position="start">
                                <input
                                    accept="image/*, .pdf, .doc, .docx"
                                    style={{ display: 'none'}}
                                    id="contained-button-file"
                                    multiple
                                    type="file"
                                    onChange={handleFileChange}
                                />
                                 {selectedFileName && <Typography variant="body2">{selectedFileName}</Typography>}
                                <label htmlFor="contained-button-file">
                                    <IconButton component="span">
                                        <AttachFile fontSize='24px' className='smallicon'/>
                                    </IconButton>
                                </label>
                               
                                <IconButton onClick={submitMessage}>
                                    <SendIcon fontSize='30px' />
                                </IconButton>
                            </InputAdornment>
                        ),
                        style: {
                            background: '#fff',
                            padding: '0px',
                            border: '0px',
                            fontSize: '16px',
                            borderRadius: '0',
                            height: '45px'
                        },
                        disableUnderline: true
                    }}
                    value={input}
                    onChange={handleEmailInput}
                />
            </Box>
        </Box>
    );
};

export default Comments;
