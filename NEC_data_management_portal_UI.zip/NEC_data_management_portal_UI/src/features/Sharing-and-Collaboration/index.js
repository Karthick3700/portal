import React, { useEffect, useState } from "react";
import { useTranslation } from 'react-i18next';
import { Box, Button, Grid, IconButton, Paper, SvgIcon, Avatar, Breadcrumbs, Typography, Card } from "@mui/material";
import { ReactComponent as PlusIcon } from "../../assets/pluslarge.svg";
import { ReactComponent as PlusWithoutBorder } from "../../assets/pluswithoutcircle.svg";
import { ReactComponent as AssignIcon } from "../../assets/assign.svg";
import { ReactComponent as EditIcon } from "../../assets/edit.svg";
import { ReactComponent as DeleteIcon } from "../../assets/delete.svg";
import { ReactComponent as AvatarImage } from "../../assets/avatar.svg";
import AlertDialog from "../../app/component/AlertDialog";
import AddSpace from "./AddSpace";
import EditSpace from "./AddSpace/EditSpace";
import { useNavigate } from "react-router";

import { useSelector, useDispatch } from 'react-redux';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import TextField from '@mui/material/TextField';
import ClearIcon from '@mui/icons-material/Clear';

import SearchIcon from '@mui/icons-material/Search';

import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import {
  fetchSharingList, assignUsertoSpace
  , deleteSpace, resetSharingAlterInfo
} from '../../redux/sharinglist/sharingListSlice';
import { fetchAllUsers } from '../../redux/users/slice';
import { selectSaveNewSpaceMsg, selectSaveNewSpaceType } from "../../redux/sharing/sharingSelector";
import { clearSpaceMessage } from "../../redux/sharing/sharingSlice";
import MsgDialog from "../../app/component/MsgDialog";
import { ReactComponent as DeleteSpace } from "../../assets/delete_space.svg";
import { ReactComponent as BinIcon } from "../../assets/Bin.svg";
import AlertMessage from '../../app/common/AlertMessage';
import { Link } from "react-router-dom";
import HomeIcon from '@mui/icons-material/Home';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import CloseIcon from '@mui/icons-material/Close';
import deleteIcon from "../../assets/img/delete-icon.svg";
import successIcon from "../../assets/img/success.svg";
import { ReactComponent as PlusIconNew } from "../../assets/img/plus-new.svg";

const SharingList = () => {

  const [open, setOpen] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const [currentSpaceId, setCurrentSpaceId] = useState(null);
  const [currentSpaceName, setCurrentSpaceName] = useState(null);
  const [currentSpaceDesc, setCurrentSpaceDesc] = useState(null);
  const sharingAlterStatus = useSelector((state) => state.sharingList.sharingAlterStatus) || "error";
  const sharingAlterMessage = useSelector((state) => state.sharingList.sharingAlterMessage);
  const dispatch = useDispatch();
  const spaceListData = useSelector(state => state.sharingList);
  const usersData = useSelector(state => state.users.data);
  const dataSpaces = [...spaceListData.data]; // Replace with your actual data array
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [spaceToDelete, setSpaceToDelete] = React.useState(null);

  const [showAlert, setShowAlert] = useState(false);
  const [formId, setFormId] = useState(null);
  const [isAlertMessage, setIsAlertMessage] = useState(false);

  useEffect(() => {
    return () => {
      dispatch(resetSharingAlterInfo());
    };
  }, [dispatch]);

  useEffect(() => {
    if (sharingAlterMessage && sharingAlterStatus) {
      setIsAlertMessage(true);
    } else {
      setIsAlertMessage(false);
    }
  }, [sharingAlterMessage, sharingAlterStatus]);

  useEffect(() => {
    if (!isAlertMessage) {
      setTimeout(() => {
        dispatch(resetSharingAlterInfo());
      }, 400);
    }
  }, [dispatch, isAlertMessage]);

  const handleClickOpen = (item, spaceItem) => {

    if (spaceItem.length > 0) {
      setFormId(spaceItem[0].resource_id)
    }
    setCurrentSpaceId(item.space_id);
    setCurrentSpaceName(item.space_name);
    setCurrentSpaceDesc('desc');

    let dataSpacesmod = dataSpaces.filter((rec) => {
      return rec.space_id == item.space_id
    })

    let selectedUsersData = dataSpacesmod[0].spaceUser.map(obj => obj.user);
    setSelectedUsers(selectedUsersData)
    dispatch(fetchSharingList());
    setOpen(true);
  };

  const handleClose = () => {
    dispatch(fetchSharingList());
    setOpen(false);
  };

  const handleAssign = () => {

    const payload = {
      "workspace_name": currentSpaceName,
      "workspace_desc": currentSpaceDesc,
      "forms": [formId],
      "users": selectedUsers
    }
    dispatch(assignUsertoSpace(
      { payload, currentSpaceId }));

    dispatch(fetchSharingList());
    dispatch(fetchAllUsers(formId));
    setShowAlert(true);
  };

  const handleCheckboxChange = (userId) => {
    if (selectedUsers.includes(userId)) {
      setSelectedUsers(selectedUsers.filter(id => id !== userId));
    } else {
      setSelectedUsers([...selectedUsers, userId]);
    }
  };

  //
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  // Get language from Redux store
  const language = useSelector(state => state.language);
  const spaceSavedMsg = useSelector(selectSaveNewSpaceMsg);
  const spaceSavedType = useSelector(selectSaveNewSpaceType);
  const [openspace, setOpenSpace] = React.useState(false);
  const [openeditspace, setOpenEditSpace] = React.useState(false);
  const [editspaceid, setEditSpaceID] = React.useState('');
  const [openspacemessage, setSaveSpaceMessage] = React.useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);

  const handleDelete = (item) => {
    setSpaceToDelete(item);
    setOpenDeleteDialog(true);
    setCurrentSpaceId(item.space_id);
  };

  const handleCloseConfirm = () => {
    setShowAlert(false)
    setOpen(false);
    dispatch(fetchSharingList());
  };

  const handleDeleteConfirm = () => {
    // setCurrentSpaceId(item.space_id);
    // dispatch(deleteSpace());
    setOpenDeleteDialog(false);
  };

  useEffect(() => {
    // Change i18n language when `language` changes
    i18n.changeLanguage(language);
  }, [i18n, language]);

  useEffect(() => {
    if (spaceSavedMsg) {
      setSaveSpaceMessage(true);
    }
  }, [spaceSavedMsg]);

  const handleAddSpace = () => {
    setOpenSpace(true);
  }

  const handleAddSpaceClose = () => {
    setOpenSpace(false);
    dispatch(clearSpaceMessage());
  }

  const handleEditSpace = (e, id) => {
    setOpenEditSpace(true);
    setEditSpaceID(id);
  }

  const handleEditSpaceClose = () => {
    setOpenEditSpace(false);
  }

  const handleSpaceClick = (e, space_id) => {
    navigate(`/addsharing/${space_id}`);
  }

  useEffect(() => {
    // Change i18n language when `language` changes
    i18n.changeLanguage(language);
    dispatch(fetchSharingList());
    dispatch(fetchAllUsers(formId));
  }, [i18n, language, dispatch, formId]);

  const handleAddSpaceMessageClose = () => {
    if (dispatch(clearSpaceMessage())) {
      setSaveSpaceMessage(false);
    }
  }

  const handleConfirmedDelete = async () => {
    try {
      setOpenDeleteDialog(true);
      const request = {
        "workspace_status": "deleted"
      }
      let space_id = currentSpaceId
      dispatch(deleteSpace({ request, space_id }));
      dispatch(fetchSharingList());
      setOpenDeleteDialog(false);
      setSpaceToDelete(null);
    } catch (error) {
      console.error('Failed to delete space: ', error);
    }
  };

  return (
    <>
      <MsgDialog
        open={openspacemessage}
        handleClose={handleAddSpaceMessageClose}
        type={spaceSavedType}
        title={spaceSavedType === 'success'
          ? 'Your request has been sent.'
          : 'Your request has been cancelled.'}
        bodycontent={spaceSavedMsg}
      />
      <AlertDialog
        open={openspace}
        handleClose={handleAddSpaceClose}
        title={'Add New Space'}
        bodycontent={<AddSpace handleClose={handleAddSpaceClose} />}
      />
      <AlertDialog
        open={openeditspace}
        handleClose={handleEditSpaceClose}
        title={'Update Space'}
        bodycontent={<EditSpace space_id={editspaceid} handleClose={handleEditSpaceClose} />}
      />

      <Box sx={{ width: '100%' }}>
        <Box sx={{ p: 0, mb: 3 }}>
          <Box sx={{ pt: 4, px: 3 }}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link
                underline="none"
                to='/home'
                className='breadCrumb'
              >
                Home
              </Link>
              <Link underline="none" className='activeBreadCrumb'>
                {t('sharing.sharing_and_collaboration_title')}
              </Link>
            </Breadcrumbs>
          </Box>
          <Box sx={{ width: '100%', px: 3, py: 1 }} className='mainheading'>
            <Typography variant="h1" gutterBottom>
              {t('sharing.sharing_and_collaboration_title')}
            </Typography>
            <Box className="btn-right">
              <Button className="btn-primary ">
                <SvgIcon
                  sx={{
                    height: "12px",
                    width: "12px",
                    marginRight: "8px"
                  }}
                  component={PlusWithoutBorder}
                  inheritViewBox
                />
                {t('sharing.invite')}
              </Button>
            </Box>
          </Box>
        </Box>

        <Box sx={{ px: 3 }}>
          <Card className="boxRounded2">
            <Box className="blockHeading2 justify-content-between">
              <Typography variant="h3" gutterBottom>
                {t('sharing.sharing_and_collaboration_title')}
              </Typography>
            </Box>
            <Box className="w-100 sharelistingpage">
              <Box className="bottomcontent">
                <Box sx={{ flexGrow: 1, p: 3, pb: 4 }}>
                  <AlertMessage
                    type={sharingAlterStatus}
                    message={sharingAlterMessage}
                    open={isAlertMessage}
                    onClose={() => setIsAlertMessage(false)}
                  />
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={6} lg={4} xl={3}>
                      <Button
                        onClick={handleAddSpace}
                        className="addformcard cursor-pointer w-100 h-100"
                      >
                        <SvgIcon
                          sx={{
                            height: "45px",
                            width: "45px",
                            margin: '0 auto',
                          }}
                          component={PlusIconNew}
                          inheritViewBox
                        />
                        <span style={{ marginTop: 15, color: '#19223B' }}>
                          {t('sharing.add_new_space')}
                        </span>
                      </Button>
                    </Grid>

                    {dataSpaces.map((item, index) => (

                      <Grid item xs={12} md={6} lg={4} xl={3} key={index}>
                        <Box>
                          <Paper elevation={0} className="boxRounded2 whiteformbox sharebox h-100">
                            <Box sx={{ cursor: 'pointer' }} onClick={(_) => handleSpaceClick(_, item.space_id)}>
                              <Box className='blockHeading'>
                                <Typography variant="h3">
                                  Space Name: <strong>{item.space_name}</strong>
                                </Typography>
                              </Box>
                              <Box className='blocContent' sx={{ minHeight: 'auto', p: 0 }}>
                                <Typography variant="h6" className="frmDesc">
                                  Space Owner: <strong>{item.spaceOwner ? item.spaceOwner.usr_first_name : ''}</strong>
                                </Typography>
                                <Typography variant="h6" className="frmDesc">
                                  Space Items:
                                  <strong>
                                    {item.spaceItem.map((spaceItem, idx) => (
                                      <span key={idx}>{`${spaceItem.resource_type}(${item.spaceItem.length}) `}</span>
                                    ))}
                                  </strong>
                                </Typography>
                              </Box>
                            </Box>
                            {/* <Box>
                              <Typography className="text-dark mt-auto">
                                Space Members
                              </Typography>
                            </Box> */}
                            <Box sx={{mt:2}}>
                              <div className="d-flex justify-content-between">
                                {/* <ul className="memberslist">
                                  <li>
                                    <a href="#">
                                      <SvgIcon
                                        sx={{
                                          height: "40px",
                                          width: "40px",
                                        }}
                                        component={AvatarImage}
                                        inheritViewBox
                                      />
                                    </a>
                                  </li>
                                  <li>
                                    <a href="#">
                                      <SvgIcon
                                        sx={{
                                          height: "40px",
                                          width: "40px",
                                        }}
                                        component={AvatarImage}
                                        inheritViewBox
                                      />
                                    </a>
                                  </li>
                                  <li>
                                    <a href="#">
                                      <SvgIcon
                                        sx={{
                                          height: "40px",
                                          width: "40px",
                                        }}
                                        component={AvatarImage}
                                        inheritViewBox
                                      />
                                    </a>
                                  </li>
                                </ul> */}
                                <ul className="actionsicons">
                                  <li>
                                    <a href="#" className="">
                                      <SvgIcon
                                        sx={{
                                          width: "20px",
                                          height: "20px",
                                        }}
                                        component={AssignIcon}
                                        inheritViewBox
                                        onClick={() => handleClickOpen(item, item.spaceItem)}
                                      />
                                    </a>
                                  </li>
                                  <li>
                                    <a href="#" className="">
                                      <SvgIcon
                                        sx={{
                                          width: "16px",
                                          height: "16px",
                                        }}
                                        component={EditIcon}
                                        inheritViewBox
                                        onClick={(_) => handleEditSpace(_, item.space_id)}
                                      />
                                    </a>
                                  </li>
                                  <li>
                                    <a href="#" className="">
                                      <SvgIcon
                                        sx={{
                                          width: "19px",
                                          height: "20px",
                                        }}
                                        component={DeleteIcon}
                                        inheritViewBox
                                        onClick={() => handleDelete(item)}
                                      />
                                    </a>
                                  </li>
                                </ul>
                              </div>
                            </Box>
                          </Paper>
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              </Box>
            </Box>
          </Card>
        </Box>
      </Box>

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="customDialog medium"
      >
        <DialogTitle id="alert-dialog-title">{t('Assign')}</DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          className='dialogClose'
        >
          <CloseIcon />
        </IconButton>

        <DialogContent dividers className='modal-content'>
          <Box sx={{ width: '100%' }}>
            <TextField
              label=""
              variant="outlined"
              placeholder="Search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="input-filled w-100"
              sx={{ mb: 0, p: 0 }}
              InputProps={{
                endAdornment: (
                  <React.Fragment>
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                    <IconButton
                      edge="end"
                      onClick={() => setSearchInput('')}
                    >
                      <ClearIcon sx={{ mr: 1 }} />
                    </IconButton>
                  </React.Fragment>
                ),
              }}
            />
          </Box>
          <Box sx={{ width: '100%' }}>
            {usersData &&
              Object.values(usersData)
                .filter(
                  (item) =>
                    item &&
                    item.usr_first_name &&
                    typeof item.usr_first_name === 'string' &&
                    item.usr_first_name
                      .toLowerCase()
                      .includes(searchInput.toLowerCase())
                )
                .map((item) => {
                  const initials = item.usr_first_name.split(' ').map((n) => n[0]).join('');
                  return (
                    <>
                      <Box className='d-flex flex-row userListing'>
                        <FormControlLabel
                          sx={{ m: 0, width: '100%', paddingLeft: 2 }}
                          key={item.usr_id_pk}
                          control={
                            <>

                              <Checkbox
                                checked={selectedUsers.includes(item.usr_id_pk)}
                                onChange={() => handleCheckboxChange(item.usr_id_pk)}
                              />
                              {item.usr_image && (
                                <img
                                  src={item.usr_image}
                                  style={{ width: 30, height: 30, marginRight: 10 }}
                                />
                              )}
                              <Box style={{ marginRight: '16px' }}>
                                <Avatar style={{ backgroundColor: '#A7E29D', textTransform: 'uppercase' }}>{initials}</Avatar>
                              </Box>
                            </>
                          }
                          label={item.usr_first_name}
                        />
                      </Box>
                    </>
                  );
                })}
          </Box>
          <DialogContentText id="alert-dialog-description">

          </DialogContentText>

          <DialogActions className="dialogButtons">
            <Button
              onClick={handleClose}
              className='btn-outline large'
            >
              Close
            </Button>
            <Button
              onClick={handleAssign}
              variant="contained"
              className='btn-primary large'
            >
              Assign
            </Button>
          </DialogActions>

        </DialogContent>
      </Dialog>

      {/* Success dialog */}
      <Dialog
        open={showAlert}
        onClose={() => setShowAlert(false)}
        aria-labelledby="success-dialog-title"
        className='customDialog'
      >
        <IconButton
          aria-label="close"
          onClick={handleCloseConfirm}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
          className='dialogClose'
        >
          <CloseIcon />
        </IconButton>
        {/* <DialogTitle id="success-dialog-title">Assignment Successful</DialogTitle> */}
        <DialogContent sx={{ p: 3 }} dividers>
          <img src={successIcon} className='dialogIcon medium' />
          <Typography gutterBottom className='msgText text-black'>
            User added successfully.
          </Typography>
          <Box className='dialogButtons'>
            <Button
              onClick={handleCloseConfirm}
              variant='outlined'
              className='btn-outline large'
            >
              Close
            </Button>
          </Box>
        </DialogContent>
      </Dialog>

      {/* Delete storage space  */}

      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className='customDialog'
      >
        <IconButton
          aria-label="close"
          onClick={() => setOpenDeleteDialog(false)}
          className='dialogClose'
        >
          <CloseIcon />
        </IconButton>
        {/* 
        <DialogTitle id="alert-dialog-title" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <BinIcon />
        </DialogTitle> */}
        <DialogContent sx={{ p: 3 }} dividers>
          <Box className='d-flex flex-column'>
            <img src={deleteIcon} className='dialogIcon' />
            <DialogContentText id="alert-dialog-description" gutterBottom className='msgText'>
              Are you sure you want to Delete
            </DialogContentText>
          </Box>
          <Box className='dialogButtons'>
            <Button
              onClick={() => setOpenDeleteDialog(false)}
              variant='outlined'
              className='btn-outline large'
            >
              No
            </Button>
            <Button
              onClick={handleConfirmedDelete}
              autoFocus
              variant='outlined'
              className="btn-primary large"
            >
              Yes
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default SharingList