import React, { useEffect } from 'react';
import { 
    Backdrop,
    Box, 
    Button, 
    Checkbox, 
    CircularProgress, 
    FormControl, 
    FormControlLabel, 
    Grid,
    ListItemText,
    MenuItem,
    Radio, 
    RadioGroup, 
    Select, 
    TextField, 
    Typography 
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import Autocomplete from '@mui/material/Autocomplete';
import UserCard from './components/UserCard';
import { useStyles } from './AddSpaceStyles';
import { getFormListings } from '../../../redux/forms/formsSlice';
import { getAllFormsData } from '../../../redux/forms/formsSelector';
import { getUsersByFormId, getWorkspaceById, saveNewSpace, updateWorkspace } from '../../../redux/sharing/sharingSlice';
import { selectSpaceLoading, selectUserListingByFormId, selectUsersbyFormLoading, selectWorkspaceById } from '../../../redux/sharing/sharingSelector';

const EditSpace=({
    handleClose,
    space_id
})=>{
    const classes = useStyles();
    const dispatch = useDispatch();
    const usersData = useSelector(selectUserListingByFormId);
    const isSpaceLoading = useSelector(selectSpaceLoading);
    const forms = useSelector(getAllFormsData);
    const workspace = useSelector(selectWorkspaceById);
    const [filtersusers, setFilteredUsers] = React.useState(false);
    const [selectedusers, setSelectedUsers] = React.useState([]);
    const [workspaceData, setWorkspaceData] = React.useState([]);
    const [allUsers, setAllUsers] = React.useState([]);
    const [formnames, setFormNames] = React.useState('');
    const [spaceName, setSpaceName]=React.useState([]);

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
    PaperProps: {
        style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
        },
    },
    };

    useEffect(()=>{
        if(workspace) {
            setWorkspaceData(workspace);
        }
        if(usersData){
            setAllUsers(usersData);
        }
    },[workspace, usersData]);

    useEffect(()=>{
        dispatch(getFormListings());
    },[]);
    

    useEffect(()=>{
        if(formnames || workspaceData?.length > 0){
            const form_id = workspaceData?.spaceItem[0]?.resource_id ?? formnames; 
            dispatch(getUsersByFormId({ form_id}));
        }
    },[formnames, workspaceData]);



    useEffect(()=>{
        if(space_id){
            dispatch(getWorkspaceById({ space_id }));
        }
    },[space_id]);

    useEffect(()=>{
        if( workspaceData && Object.keys(workspaceData)?.length > 0 ){
            const usersAr = workspaceData.spaceUser.map(u=>u.user);
            const formsAr = workspaceData.spaceItem.map(spac=>spac.resource_id);
            const formIdsData = [];
            workspaceData.spaceItem.map(spac=>{
                formIdsData[spac.resource_id] = spac.resource_id
            });
            const selUsers = allUsers?.length > 0 ? allUsers?.filter(allu=>{
                return usersAr.includes(parseInt(allu?.usr_id_pk));
            }): [];
            const formid = formsAr[0] ?? '';
            setFormNames(formid);
            setSelectedUsers(selUsers);
            setSpaceName(workspaceData?.space_name);
        }
    },[workspaceData, forms, allUsers]);

    useEffect(()=>{
        if(allUsers && allUsers?.length > 0 ){
            setFilteredUsers(allUsers);
        }
    },[allUsers]);

    const handleChange = (event) => {
        setFormNames(
            event.target.value
        );
    };

    const updateSpaceHandler =()=>{
        const users = Object.keys(selectedusers).map((key)=>{
            return parseInt(selectedusers[key].usr_id_pk);
        });
        
        const spaceData = {
            workspace_name: spaceName,
            forms: [formnames],
            users
        }
        dispatch(updateWorkspace({space_id, spaceData}));
        handleClose();
    }

    const handleAccessChange=(e)=>{
        const data = [];
        data[e.target.name] = e.target.value;
    }

    return(
        <Grid bgcolor={'#FFF'} minWidth={'550px'} container>
            { isSpaceLoading ? 
            <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={true}
            >
                <Box display={'flex'} justifyContent={'center'} alignItems={'center'}>
                    <CircularProgress color="inherit" />
                </Box>
            </Backdrop> : 
            <Grid xs={12} item>
                <Box className='customDialog'>
                    <Box paddingBottom={1} display={'block'}>
                        <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{mb:1}}>Space Name </Typography>
                        <TextField
                            fullWidth
                            value={spaceName}
                            placeholder="Please enter space name"
                            onChange={(e)=>setSpaceName(e.target.value)}
                        />
                    </Box>
                    <Box paddingBottom={1} display={'block'}>
                        <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{mb:1}}>
                            Form 
                        </Typography>
                        <FormControl fullWidth>
                            <Select
                                placeholder='Select forms'
                                value={formnames}
                                onChange={handleChange}
                                MenuProps={MenuProps}
                            >
                                { forms && forms?.map((form) => (
                                    <MenuItem value={form.form_id}>
                                        <ListItemText primary={form?.form_name} />
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Box>
                    <Box width={'100%'} marginBottom={1}>
                        <Grid container spacing={3}>
                            <Grid item xs={12}>
                                <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{mb:1}}>Space Users</Typography>
                                <Autocomplete
                                    multiple
                                    value={selectedusers}
                                    options={filtersusers}
                                    disableCloseOnSelect
                                    getOptionSelected={(option, value) => value.usr_first_name === option.usr_first_name}
                                    onChange={(
                                        _, 
                                        value,
                                        // situation, // removeOption if (situation === "removeOption") {console.log("--->", e, value, situation, option); }
                                        // option
                                    ) =>setSelectedUsers(value)}
                                    getOptionLabel={(option) => option.usr_first_name}
                                    renderOption={(props, option, { selected }) => (
                                        <>
                                            <Box {...props} 
                                                sx={{ 
                                                    display: 'flex', 
                                                    position: 'relative',
                                                    flexDirection: 'column', 
                                                    border: '1px solid #ddd'
                                                }}
                                                >
                                                <UserCard 
                                                    selectedusers={selectedusers}
                                                    selected={selected} 
                                                    user={option} 
                                                />
                                                <Box 
                                                    sx={{ px:1}}
                                                    className='selectSpaceUser' 
                                                >
                                                    {option?.form_access ? <FormControl>
                                                        <Box>
                                                            <RadioGroup
                                                                row
                                                                defaultValue={option?.form_access}
                                                                name={option?.usr_id_pk}
                                                                onChange={handleAccessChange}
                                                            >
                                                                <FormControlLabel 
                                                                    value="R" 
                                                                    control={
                                                                        <Radio color="default" sx={{
                                                                            fontSize: 9,
                                                                            '& .MuiSvgIcon-root': {
                                                                              fontSize: 18,
                                                                            },
                                                                          }} />
                                                                    } 
                                                                    label="Read" 
                                                                    sx={{ fontSize: 10}}
                                                                />
                                                                <FormControlLabel 
                                                                    value="RW" 
                                                                    control={
                                                                        <Radio color="default" sx={{
                                                                            fontSize: 9,
                                                                            '& .MuiSvgIcon-root': {
                                                                              fontSize: 18,
                                                                            },
                                                                          }} />
                                                                    } 
                                                                    label="Read/Write" 
                                                                    sx={{ fontSize: 10}}
                                                                />
                                                            </RadioGroup>
                                                        </Box>
                                                    </FormControl>
                                                    : 
                                                    <Box 
                                                        sx={{px:0,}}
                                                        className="usernotAccess"
                                                    >
                                                            
                                                        <Typography  
                                                            color='error'
                                                            sx={{fontSize: '11px',}}
                                                        >
                                                            User does not have access!
                                                        </Typography>
                                                    </Box>
                                                    }
                                                </Box>
                                            </Box>
                                        </>
                                    )}
                                    
                                    renderInput={(params) => (
                                        <TextField {...params} placeholder="Select space users" />
                                    )}
                                />
                            </Grid>
                        </Grid>
                    </Box>
                    <Box width={'100%'} marginBottom={1}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={6}>
                                <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{mb:1}}>
                                    Dashboard 
                                </Typography>
                                <TextField
                                    disabled
                                    fullWidth
                                    placeholder="Please select dashboards"
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{mb:1}}>Reports </Typography>
                                <TextField
                                    disabled
                                    fullWidth
                                    placeholder="Please select reports"
                                />
                            </Grid>
                        </Grid>
                    </Box>
                </Box>
                <Box className={classes.btnContainer}  sx={{mt:3}}>
                    <Button 
                        size='large'
                        className='btn-primary large' 
                        onClick={updateSpaceHandler}
                    >
                        Update Space
                    </Button>
                </Box>
            </Grid> }
        </Grid>
    );
}

export default EditSpace;