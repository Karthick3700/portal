import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    cardContainer: {
        display: 'flex',
        width: '100%',
        padding: '0px',
        columnGap: 10,
    },
    subText:{
        color: '#797979',
        fontSize: '12px',
        fontStyle: 'normal',
        fontWeight: 500,
        lineHeight: '18px'
    }
});

export { useStyles };