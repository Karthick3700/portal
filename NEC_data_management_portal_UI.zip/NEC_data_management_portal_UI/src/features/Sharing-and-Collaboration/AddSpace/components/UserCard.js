import React from 'react';
import { useStyles } from './UserCardStyle';
import { Avatar, Box, Checkbox, FormControl, FormControlLabel, Radio, RadioGroup, Typography } from '@mui/material';
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const UserCard=({
    user,
    selectedusers,
    selected
})=>{
    const classes = useStyles();
    const initials = user 
        && user?.usr_first_name 
        ? user?.usr_first_name?.charAt(0)
        : 'A';

    return(
        <Box className={classes.cardContainer}>
            <Box sx={{ width: 20}}>
                <FormControlLabel control={
                    <Checkbox
                        icon={icon}
                        checkedIcon={checkedIcon}
                        checked={selected}
                        // defaultChecked={selected}
                        color='default'
                        sx={{mx:0, px:0}}
                    />
                }
                sx={{mx:0, px:0}}
                />
            </Box>
            <Box sx={{ width: 50}}>
                <Avatar sx={{ bgcolor: '#A7E29D', textTransform:'uppercase' }}>{ initials }</Avatar>
            </Box>
            <Box width='100%'>
                <Typography variant='subtitle-2' sx={{textTransform:'capitalize'}} gutterBottom>
                    {`${user?.usr_first_name} ${user?.usr_last_name}`}
                </Typography>
                <Typography className={classes.subText} variant='caption' display="block"> 
                    {user?.usr_email_id ?? ''}
                </Typography>
            </Box>
        </Box>
    )
}

export default UserCard;