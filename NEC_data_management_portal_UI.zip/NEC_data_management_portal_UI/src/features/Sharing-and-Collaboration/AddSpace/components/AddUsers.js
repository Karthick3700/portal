import React from 'react';
import UserCard from './UserCard';
import { Backdrop, Box, CircularProgress, Grid, TextField } from '@mui/material';

const AddUser=({ 
    allUsers,
    handleFilterUsers,
    isLoadingUsers,
    handleUserSelect,
    selecteduser
})=>{
    const userlisting = allUsers 
        && allUsers?.length > 0 
        ? allUsers?.map(user=>{
            return <UserCard 
                handleUserSelect={handleUserSelect} 
                user={user} 
            />
    }):'';


    return(
        <Grid container bgcolor={'#FFF'}>
            { isLoadingUsers 
            ? <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={true}
            >
                <CircularProgress color="inherit" />
            </Backdrop>: 
            <Grid item xs={12}>
                <Box paddingBottom={3}>
                    <TextField
                        fullWidth
                        onChange={handleFilterUsers}
                        placeholder="Search users"
                    />
                </Box>
                <Box>
                    { userlisting }
                </Box>
            </Grid> }
        </Grid>
    )
}

export default AddUser;