import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    btnAddSpace:{
        minWidth: '120px',
        fontSize: '0.875rem',
        padding: '8px 20px',
        boxSizing: 'border-box',
        borderRadius: '10px !important',
        border: 'none !important',
        color: '#FFF !important',
        background: '#D34562 !important',
        '&:hover':{
            border: 'none !important',
            color: '#FFF !important',
            background: '#D34562 !important'
        }
    },
    btnContainer: {
        width: '100%',
        padding: '0',
        display:"flex",
        justifyContent:'center',
        alignItems:'center'
    }
});

export { useStyles };