import React, { useEffect } from 'react';
import {
    Backdrop,
    Box,
    Button,
    Checkbox,
    CircularProgress,
    FormControl,
    FormControlLabel,
    Grid,
    InputLabel,
    ListItemText,
    MenuItem,
    OutlinedInput,
    Radio,
    RadioGroup,
    Select,
    TextField,
    Typography
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { getAllUsers } from '../../../redux/users/slice';
import { useSelector } from 'react-redux';
import { getAllUsersLists } from '../../../redux/users/userSelector';
import Autocomplete from '@mui/material/Autocomplete';
import UserCard from './components/UserCard';
import { useStyles } from './AddSpaceStyles';
import { getFormListings } from '../../../redux/forms/formsSlice';
import { getAllFormsData } from '../../../redux/forms/formsSelector';
import { getUsersByFormId, saveNewSpace } from '../../../redux/sharing/sharingSlice';
import { selectSaveNewSpaceMsg, selectUserListingByFormId, selectUsersbyFormLoading } from '../../../redux/sharing/sharingSelector';

const AddSpace = ({ handleClose }) => {
    const classes = useStyles();
    const dispatch = useDispatch();
    const allUsers = useSelector(selectUserListingByFormId);
    const isUsersLoading = useSelector(selectUsersbyFormLoading);
    const forms = useSelector(getAllFormsData);
    const [filtersusers, setFilteredUsers] = React.useState([]);
    const [selectedusers, setSelectedUsers] = React.useState([]);
    const [formids, setFormIds] = React.useState([]);
    const [formnames, setFormNames] = React.useState('');
    const [spaceName, setSpaceName] = React.useState([]);

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };

    const handleChange = (event) => {
        setFormNames(
            event.target.value
        );
        //   dispatch(getUsersByFormId({ form_id: event.target.value }));
    };

    const textChangeHandler = (e) => {
        setSpaceName(e.target.value);
    }

    const handleCheck = (e) => {
        const data = { ...formids };
        if (e.target.checked) {
            data[e.target.id] = e.target.id;
        }
        if (!e.target.checked) {
            delete data[e.target.id];
        }
        setFormIds(data);
    }

    useEffect(() => {
        dispatch(getFormListings());
    }, []);

    useEffect(() => {
        if (formnames) {
            dispatch(getUsersByFormId({ form_id: formnames }));
        }
    }, [formnames]);

    useEffect(() => {
        if (allUsers && allUsers?.length > 0) {
            // const usersWithAccess = allUsers?.filter(el=>el.form_access) ?? []; // R or RW Admin
            setFilteredUsers(allUsers);
        }
    }, [allUsers]);

    const addSpaceHandler = () => {
        const users = Object.keys(selectedusers).map((key) => {
            return parseInt(selectedusers[key].usr_id_pk);
        })
        const forms_ids = formnames;
        const spaceObj = {
            workspace_name: spaceName,
            forms: [forms_ids],
            users
        }
        dispatch(saveNewSpace(spaceObj))
        handleClose();
    }

    const handleAccessChange = (e) => {
        const data = [];
        data[e.target.name] = e.target.value;
    }

    return (
        <Box className='customDialog'>
            <Grid container>
                <Grid xs={12} item>
                    <Box paddingBottom={1} display={'block'}>
                        <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{ mb: 1 }}>Space Name </Typography>
                        <TextField
                            fullWidth
                            placeholder="Please enter space name"
                            onChange={(e) => textChangeHandler(e)}
                        />
                    </Box>
                    <Box paddingBottom={1} display={'block'}>
                        <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{ mb: 1 }}>
                            Form
                        </Typography>
                        <FormControl fullWidth>
                            <Select
                                placeholder='Please select form'
                                value={formnames}
                                onChange={handleChange}
                                MenuProps={MenuProps}
                            >
                                {forms && forms?.map((form) => (
                                    <MenuItem value={form.form_id} >
                                        <ListItemText primary={form?.form_name} />
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Box>
                    <Box width={'100%'} marginBottom={1}>
                        <Grid container spacing={3}>
                            <Grid item xs={12}>
                                <Typography fontWeight={'500'} sx={{ mb: 1 }}>
                                    Space Users
                                </Typography>
                                {isUsersLoading ? <Box display={'flex'} justifyContent={'center'} alignItems={'center'}>
                                    <CircularProgress color="inherit" />
                                </Box> :
                                    <Autocomplete
                                        multiple
                                        options={filtersusers}
                                        disableCloseOnSelect
                                        onChange={(e, value) => setSelectedUsers(prevState => ({
                                            ...prevState,
                                            ...value
                                        }))}
                                        getOptionLabel={(option) => option.usr_first_name}
                                        renderOption={(props, option, { selected }) => (
                                            <Box 
                                                sx={{ 
                                                    display: 'flex', 
                                                    flexDirection: 'column',
                                                    border: '1px solid #ddd'
                                                }}
                                                >
                                                <Box {...props} sx={{p:0}}>
                                                    <UserCard
                                                        selected={selected}
                                                        user={option}
                                                    />
                                                </Box>
                                                <Box className="readWriteAccess">
                                                    {option?.form_access ? <FormControl>
                                                        <RadioGroup
                                                            row
                                                            defaultValue={option?.form_access}
                                                            name={option?.usr_id_pk}
                                                            onChange={handleAccessChange}
                                                        >
                                                            <FormControlLabel
                                                                value="R"
                                                                control={
                                                                    <Radio color="default" sx={{
                                                                        fontSize: 9,
                                                                        '& .MuiSvgIcon-root': {
                                                                          fontSize: 18,
                                                                        },
                                                                      }} />
                                                                }
                                                                label="Read"
                                                                sx={{ fontSize:'10px'}}
                                                            />
                                                            <FormControlLabel
                                                                value="RW"
                                                                control={
                                                                    <Radio color="default" sx={{
                                                                        fontSize: 9,
                                                                        '& .MuiSvgIcon-root': {
                                                                          fontSize: 18,
                                                                        },
                                                                      }} />
                                                                }
                                                                label="Read/Write"
                                                                sx={{ fontSize:'10px'}}
                                                            />
                                                        </RadioGroup>
                                                    </FormControl> 
                                                    : 
                                                    <Typography 
                                                        color='error'
                                                        sx={{ 
                                                            fontSize: '11px'
                                                        }}
                                                        className='usernotAccess pl15'
                                                    >
                                                        User does not have access!
                                                    </Typography>
                                                }
                                                </Box>
                                            </Box>
                                        )}
                                        renderInput={(params) => (
                                            <TextField {...params} placeholder="Select space users" />
                                        )}

                                       className='autoCompleteBox'
                                    />
                                    }
                            </Grid>
                        </Grid>
                    </Box>
                    <Box width={'100%'} marginBottom={1}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={6}>
                                <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{ mb: 1 }}>
                                    Dashboard
                                </Typography>
                                <TextField
                                    disabled
                                    fullWidth
                                    placeholder="Please enter space name"
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <Typography fontWeight={'500'} color={'#1F1F1F'} sx={{ mb: 1 }}>Reports </Typography>
                                <TextField
                                    disabled
                                    fullWidth
                                    placeholder="Please enter space users"
                                />
                            </Grid>
                        </Grid>
                    </Box>
                    <Box className={classes.btnContainer} sx={{ mt: 3 }}>
                        <Button size='large' onClick={addSpaceHandler} className='btn-primary'>
                            Add Space
                        </Button>
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
}

export default AddSpace;