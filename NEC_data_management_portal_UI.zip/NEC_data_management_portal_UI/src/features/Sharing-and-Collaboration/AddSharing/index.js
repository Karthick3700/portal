import {
    Avatar,
    AvatarGroup,
    Box,
    Breadcrumbs,
    Button,
    Fab,
    Grid,
    IconButton,
    InputAdornment,
    Stack,
    TextField,
    Typography
} from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useStyles } from './AddSharingStyles';
import { ReactComponent as DeleteIcon } from '../../../assets/delete.svg';
import { ReactComponent as EditIcon } from '../../../assets/edit.svg';
import { ReactComponent as UserIcon } from '../../../assets/pluswithcircle.svg';
import { ReactComponent as CommentIcon } from '../../../assets/comment.svg';
import { ReactComponent as SendIcon } from '../../../assets/send.svg';
import { ReactComponent as ManAvatar } from '../../../assets/manavatar.svg';
import Comments from '../Comments';
import io from 'socket.io-client';
import { useParams } from 'react-router';
import { clearSpaceMessage, getWorkspaceById } from '../../../redux/sharing/sharingSlice';
import { useSelector } from 'react-redux';
import { selectSaveNewSpaceMsg, selectSaveNewSpaceType, selectWorkspaceById } from '../../../redux/sharing/sharingSelector';
// import { getAllUsersLists } from '../../../redux/users/userSelector';
import { useDispatch } from 'react-redux';
import { getAllUsers } from '../../../redux/users/slice';
import EditSpace from '../AddSpace/EditSpace';
import AlertDialog from '../../../app/component/AlertDialog';
import MsgDialog from '../../../app/component/MsgDialog';
import { Link } from 'react-router-dom';
import plusIcon from '../../../assets/img/plus.svg';
import editIcon2 from '../../../assets/img/edit-2.svg';
import trashIcon from '../../../assets/img/trash.svg';

const socket = io('http://localhost:3006');

const AddSharing = () => {
    const classes = useStyles();
    const dispatch = useDispatch();
    const [messages, setMessages] = useState([]);
    const [openeditspace, setOpenEditSpace] = React.useState(false);
    const spaceSavedMsg = useSelector(selectSaveNewSpaceMsg);
    const spaceSavedType = useSelector(selectSaveNewSpaceType);
    const workspaceData = useSelector(selectWorkspaceById);
    const [editspaceid, setEditSpaceID] = React.useState('');
    const [openspacemessage, setSaveSpaceMessage] = React.useState(false);
    // const allUsers = useSelector(getAllUsersLists);
    const [input, setInput] = useState('');
    const { id } = useParams();
    const userdata = sessionStorage.getItem("user");
    const userdetails = JSON.parse(userdata);
    const {
        usr_id_pk
    } = userdetails;

    useEffect(() => {
        if (spaceSavedMsg) {
            setSaveSpaceMessage(true);
        }
    }, [spaceSavedMsg]);

    // When component mounts, set up the socket event listeners
    useEffect(() => {
        if (workspaceData) {
            // Emit 'fetchAllComments' event when the component mounts
            socket.emit('fetchCommentsbySpaceId', workspaceData?.space_id);

            socket.on('initialComments', (comments) => {
                setMessages(comments);
            });

            socket.on('commentsUpdated', (comments) => {
                setMessages(comments);
            });

            return () => {
                socket.off('initialComments');
                socket.off('commentsUpdated');
            };
        }

    }, [workspaceData]);

    useEffect(() => {
        if (id) {
            dispatch(getWorkspaceById({ space_id: id }));
            dispatch(getAllUsers());
        }
    }, [id, editspaceid]);

    const handleEditSpaceClose = () => {
        setOpenEditSpace(false);
        dispatch(clearSpaceMessage());
    }

    const handleEditSpace = (e, id) => {
        setOpenEditSpace(true);
        setEditSpaceID(id);
    }

    const submitMessage = () => {
        const message = {
            user_id: usr_id_pk,
            space_id: workspaceData?.space_id,
            comment_data: input
        };
        // Emit a new 'newComment' event with the new message
        socket.emit('newComment', message);
        setInput('');
    };

    const spaceMembers = workspaceData?.spaceUser?.map(member => {
        return (
            <Avatar color='red' src={member?.user_details?.usr_image ?? ''} />
        );
    });
    const handleAddSpaceMessageClose = () => {
        dispatch(clearSpaceMessage());
        setSaveSpaceMessage(false);
    }

    const latestMessage = messages && messages[messages?.length - 1] && messages[messages?.length - 1];

    return (
        <Box className={classes.spaceItemsMainContainer}>
            <MsgDialog
                open={openspacemessage}
                handleClose={handleAddSpaceMessageClose}
                type={spaceSavedType}
                title={spaceSavedType === 'success' ? 'Your request has been sent.' : 'Your request has been cancelled.'}
                bodycontent={spaceSavedMsg}
            />
            <AlertDialog
                open={openeditspace}
                handleClose={handleEditSpaceClose}
                title={'Update Space'}
                bodycontent={<EditSpace space_id={workspaceData?.space_id} handleClose={handleEditSpaceClose} />}
            />
            <Box sx={{ width: '100%' }}>
                <Box sx={{ p: 0, mb: 0 }}>
                    <Box sx={{ pt: 4, px: 3 }}>
                        <Breadcrumbs aria-label="breadcrumb">
                            <Link
                                underline="none"
                                to='/home'
                                className='breadCrumb'
                            >
                                Home
                            </Link>
                            <Link underline="none" className={classes.activeBreadCrumb}>
                                Space
                            </Link>
                        </Breadcrumbs>
                    </Box>
                    <Box sx={{ width: '100%', px: 3, py: 1 }} className='mainheading'>
                        <Typography variant="h1" gutterBottom>
                            Space
                        </Typography>
                    </Box>
                </Box>
                <Box sx={{ p: 3 }}>
                    <Grid container spacing={3} >
                        <Grid item xs={12} lg={8} xl={9}>
                            <Box className={classes.spaceContainer}>
                                <Box className={classes.spaceNameMainContainer}>
                                    <Box className={classes.spaceNameContainer}>
                                        <Typography classes={classes.spaceText}>
                                            Space Name: <strong>{workspaceData?.space_name ?? ''}</strong>
                                        </Typography>
                                    </Box>
                                    <Box className={classes.deleteMainContainer}>
                                        <Stack direction="row" className='pr-0'>
                                            <Button variant="text"
                                                startIcon={<img src={editIcon2} className='smallicon' />}
                                                onClick={(_) => handleEditSpace(_, workspaceData?.space_id)}
                                                className='btn-text'
                                                sx={{ color: '#1F1F1F' }}
                                            >
                                                Edit
                                            </Button>
                                            <Button variant="text"
                                                startIcon={<img src={trashIcon} className='smallicon' />}
                                                className='btn-text'
                                                sx={{ color: '#1F1F1F' }}
                                            >
                                                Delete
                                            </Button>
                                        </Stack>
                                        {/* <Box className={classes.editIconContainer}>
                                        <Fab className={classes.peopleIcon} variant="extended" size="medium" aria-label="add">
                                            <UserIcon />
                                        </Fab>
                                    </Box> */}
                                        {/* <Box className={classes.editIconContainer}>
                                        <Fab onClick={(_) => handleEditSpace(_, workspaceData?.space_id)} variant="extended" size="medium" className={classes.peopleIcon} aria-label="add">
                                            <EditIcon />
                                        </Fab>
                                    </Box>
                                    <Box>
                                        <Fab variant="extended" size="medium" className={classes.peopleIcon} aria-label="add">
                                            <DeleteIcon />
                                        </Fab>
                                    </Box> */}
                                    </Box>
                                </Box>
                                <Box className='bottomcontent' sx={{ p: 3 }}>
                                    <Typography classes={classes.spaceText}>Space Owner:
                                        <strong> {`${workspaceData?.spaceOwner?.usr_first_name ?? ""} ${workspaceData?.spaceOwner?.usr_last_name ?? ""}`}</strong>
                                    </Typography>
                                    <Typography classes={classes.spaceText}>
                                        Space Items:
                                        {
                                            workspaceData?.spaceItem?.length ?
                                                <>
                                                    <strong>
                                                        <Link to={`/formbuilder/editform/${workspaceData?.spaceItem[0]?.resource_id}`}>
                                                            Form ({workspaceData?.spaceItem?.length})
                                                        </Link>
                                                    </strong>
                                                    {
                                                        userdetails?.qlik_professional_access_id && workspaceData?.formDetails?.dashboard_id &&
                                                        <strong>
                                                            ,{' '}
                                                            <a
                                                                href={`http://172.20.60.71/sense/app/${workspaceData?.formDetails?.dashboard_id} /overview`}
                                                                target='_blank'
                                                                rel="noreferrer"
                                                            >
                                                                Dashboard ({workspaceData?.formDetails?.dashboard_name || workspaceData?.formDetails?.dashboard_id})
                                                            </a>
                                                        </strong>
                                                    }
                                                </>
                                                : null
                                        }
                                    </Typography>
                                </Box>
                                <Box className={classes.postCommentContainer}>
                                    <Box className={classes.commentContainer}>
                                        <CommentIcon />
                                        <Box className={classes.userName}>
                                            <Typography className={classes.spaceText}>
                                                {`${latestMessage?.usr_first_name ?? ''} ${latestMessage?.usr_last_name ?? ''}`}
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <Box className={classes.messageTextContainer}>
                                        <span className={classes.arrowLeft}></span>
                                        <Typography className={classes.messageText}>
                                            {latestMessage?.comment_data ?? ''}
                                        </Typography>
                                    </Box>
                                    <Box className={classes.postContainer} >
                                        <Box>
                                            <Avatar>
                                                <ManAvatar />
                                            </Avatar>
                                        </Box>
                                        <Box className={classes.post}>
                                            <TextField
                                                fullWidth
                                                size="small"
                                                variant="standard"
                                                className={classes.txtPost}
                                                InputProps={{
                                                    endAdornment: (
                                                        <InputAdornment position="start">
                                                            <IconButton onClick={submitMessage}>
                                                                <SendIcon />
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                    style: {
                                                        background: '#F1F5FF',
                                                        border: '0px'
                                                    },
                                                    disableUnderline: true
                                                }}
                                                value={input}
                                                onChange={(e) => setInput(e.target.value)}
                                            />
                                        </Box>
                                    </Box>
                                </Box>
                                <Box sx={{ p: 3 }}>
                                    <Box className='boxRounded2' sx={{ p: 0 }}>
                                        <Box className='blockHeading' sx={{ m: 0 }}>
                                            <Typography variant='body2' component='h3'>Space Members</Typography>
                                        </Box>
                                        <Box display={'flex'} alignItems={'initial'} justifyContent={'left'} sx={{ py: 3, px: 2 }}>
                                            {workspaceData?.spaceUser?.length > 0 && <AvatarGroup total={workspaceData?.spaceUser?.length}>
                                                {spaceMembers}
                                            </AvatarGroup>}
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                        </Grid>
                        <Grid item xs={12} lg={4} xl={3}>
                            <Box className={classes.commentContainer}>
                                <Comments
                                    isComment={false}
                                    space_id={workspaceData?.space_id}
                                    isSearch={true}
                                    minimumWidth='auto'
                                    commentTag={true}
                                />
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Box>
    )
}

export default AddSharing;