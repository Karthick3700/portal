import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    btnInvite: {
        minWidth: '100px !important',
        border: '0px !important',
        background:'#E51448  !important',
        color: '#FFF !important',
        '&:hover':{
            border: '0px !important',
            background:'#E51448 !important'
        }
    },
    sharingText:{
        color:'#FFF',
        fontSize:'24px',
        fontFamily:'Montserrat',
        opacity:1
    },
    sharingMainContainer:{
        display:'flex',
        justifyContent:'space-between',
        alignItems:'center'
       
    },
    spaceItemsMainContainer:{
        width:'100%',
        opacity:1,
    },
    spaceContainer:{
        background:'#FFF',
        borderRadius:'10px',
        height: '100%',
    },
    commentContainer:{
        height: '620px',
        background:'#FFF !important',
        borderRadius:'10px'
    },
    spaceNameMainContainer:{
      display:'flex',
      justifyContent:'space-between',
      padding:'5px 30px',
      alignItems: 'center',
      borderBottom: '1px solid #E3EAF1'
    },
    spaceText:{
        fontSize:'18px !important',
        textTransform: 'capitalize'
    },
    spaceNameContainer:{
      fontSize:'18px',
    },
    deleteMainContainer:{
        display:'flex',
        padding :'10px'
    },
    userText:{
        fontSize:'14px !important',
        color:'#3C3C3C !important',
        fontWeight:'bold !important'
    },
    editIconContainer:{
        marginRight:'10px!important'
    },
    peopleIcon:{
       borderRadius:'4px !important',
       background:'#E51448 !important',
       padding:'10px !important'
    },
    deleteIcon:{
       borderRadius:'4px !important',
       background:'#E51448 !important',
       padding:'10px !important',
       marginRight:'10px important'
    },
    editIcon:{
        borderRadius:'4px !important',
        background:'#E51448 !important',
        padding:'10px !important',
       marginRight:'10px !important'
    },
    postCommentContainer:{
        borderRadius:'10px',
        border: '1px solid #B2B2B2B0',
        margin:'30px 30px 0 !important',
        padding:'24px'
    },
    commentContainer:{
        display:'flex',
        alignItems:'center',
        backgroundColor: '#fff',
        borderRadius: 10,
    },
    userName:{
        paddingLeft:'5px',
    },
    messageTextContainer:{
        marginTop:'15px',
        padding: 8,
        marginLeft: 20,
        display: 'inline-block',
        position: 'relative',
        borderRadius: 6,
        border: '1px solid #E3EAF1',
    },
    arrowLeft:{
        content: '',
        display: 'block',
        borderWidth: '10px 15px 10px',
        borderStyle: 'solid',
        borderColor: '#E3EAF1 transparent transparent',
        borderLeftColor: 'transparent',
        borderLeftWidth: 0,
        borderTopColor: 'transparent',
        borderRightColor: '#E3EAF1',
        position: 'absolute',
        left: '-15px',
        top: '50%',
        bottom: 'auto',
        right: 'auto',
        margin: '-10px 0 0',
    },
    messageText:{
        fontSize:'14px !important'
    },
    postContainer:{
      display:'flex !important',
      alignItems:'center',
      marginTop:'24px'
    },
    post:{
      marginLeft:'15px',
      width:'100%',
      height:'45px !important',
      '& .MuiInputBase-input':{
        height: 40,
        paddingLeft: '15px',
        background: '#FCFDFF',
        border: '1px solid #E3EAF1',
      }
    },
    txtPost:{
        height: '32px !important',
        padding: '0px !important',
        '&.MuiInputBase-root input':{
            padding:'0px !important'
        }
    },
    txtComment: {
        letterSpacing: '0px',
        color: '#3C3C3C',
        fontWeight:'600'
    },
    breadCrumb:{
        textDecoration:"none",
        color:'#19223B !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textTransform: 'uppercase',
    },
    activeBreadCrumb:{
        color:'#9196A7 !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textDecoration: 'none',
        textTransform: 'uppercase',
    },
})

export { useStyles };



