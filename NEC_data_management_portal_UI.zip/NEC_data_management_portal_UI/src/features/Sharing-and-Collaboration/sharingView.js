import React from "react";
import { Box, Grid, Paper, SvgIcon, Typography } from "@mui/material";
import { styled } from "@mui/material/styles";

import { ReactComponent as SearchBlack } from "../../assets/search.svg";
import { ReactComponent as PlusIcon } from "../../assets/pluslarge.svg";
import { ReactComponent as PlusWithoutBorder } from "../../assets/pluswithoutcircle.svg";
import { ReactComponent as DashboardIcon } from "../../assets/createdashboard.svg";
import { ReactComponent as ExcelIcon } from "../../assets/exportinexcel.svg";
import { ReactComponent as AssignIcon } from "../../assets/assign.svg";
import { ReactComponent as PluswithCircle } from "../../assets/pluswithcircle.svg";
import { ReactComponent as EditIcon } from "../../assets/edit.svg";
import { ReactComponent as EyeIcon } from "../../assets/eye.svg";
import { ReactComponent as DeleteIcon } from "../../assets/delete.svg";
import { ReactComponent as AvatarImage } from "../../assets/avatar.svg";
import { ReactComponent as CommentIcon } from "../../assets/comment.svg";
import { ReactComponent as SendIcon } from "../../assets/send.svg";


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));
const sharingView = () => {
  return (
    <>
      <div className="headerwithoutbg d-flex w-100">
        <h4>Sharing and Collaboration</h4>

        <div className="btn-right">
          <button className=" btn-primary cursor-pointer">
            <SvgIcon
              sx={{
                height: "19px",
                width: "19px",
                marginRight: "8px",
              }}
              component={PlusWithoutBorder}
              inheritViewBox
            />
            Invite
          </button>
        </div>
      </div>
      <div className="listingpage w-100 shareviewpage">
        <div className="bottomcontent ">
          <Grid container spacing={3} columns={12}>
            <Grid item xs={9} m={0}>
              <div className="commentsleftbox h-100">
                <div className="whiteformbox sharebox h-100">
                  <div className="d-flex">
                  <div className="ltside">
                    <h6 className="mb-2">
                      Space Name: <strong>General</strong>
                    </h6>
                    <h6 className="mb-2">
                      Space Owner: <strong>Mesut Ozil</strong>
                    </h6>
                    <h6 className="mb-2">
                      Space Items:
                      <strong className="">
                        Form (3), Dashboard (2), Report (2)
                      </strong>
                    </h6>
                  </div>
                  <ul className="actionsicons mt-0">
                      <li>
                        <a href="#" className="">
                          <SvgIcon
                            sx={{
                              width: "23px",
                              height: "15px",
                            }}
                            component={AssignIcon}
                            inheritViewBox
                          />
                        </a>
                      </li>

                      <li>
                        <a href="#" className="">
                          <SvgIcon
                            sx={{
                              width: "23px",
                              height: "15px",
                            }}
                            component={EditIcon}
                            inheritViewBox
                          />
                        </a>
                      </li>

                      <li>
                        <a href="#" className="">
                          <SvgIcon
                            sx={{
                              width: "19px",
                              height: "20px",
                            }}
                            component={DeleteIcon}
                            inheritViewBox
                          />
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div className="commentbox mt-auto">
                    <div className="d-flex">   
                      <h6>
                          <SvgIcon
                                  sx={{
                                    width: "14px",
                                    height: "14px",
                                  }}
                                  component={CommentIcon}
                                  inheritViewBox
                                />
                          
                          <span> Mesut Ozil</span>
                      </h6>

                     <span className="text-grey">10 min. ago</span></div>


                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                      
                    <div className="chatbox">
                            <div className="avatar">
                            <SvgIcon
                                sx={{
                                  height: "40px",
                                  width: "40px",
                                }}
                                component={AvatarImage}
                                inheritViewBox
                              />
                            </div>

                          <div className="form-group">
                            <input type="text" className="form-control" />
                            <button className="send-button">
                            <SvgIcon
                                sx={{
                                  height: "20px",
                                  width: "20px",
                                }}
                                component={SendIcon}
                                inheritViewBox
                              />
                            </button>
                          </div>
                    </div>
                      
                  </div>

                  <p className="text-dark mt-0"><strong>Space Members</strong></p>
                  <div className="d-flex">
                    <ul className="memberslist">
                      <li>
                        <a href="#">
                          <SvgIcon
                            sx={{
                              height: "40px",
                              width: "40px",
                            }}
                            component={AvatarImage}
                            inheritViewBox
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <SvgIcon
                            sx={{
                              height: "40px",
                              width: "40px",
                            }}
                            component={AvatarImage}
                            inheritViewBox
                          />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <SvgIcon
                            sx={{
                              height: "40px",
                              width: "40px",
                            }}
                            component={AvatarImage}
                            inheritViewBox
                          />
                        </a>
                      </li>
                    </ul>

                    
                  </div>
                </div>
              </div>
            </Grid>
            <Grid item xs={3}>
              <div className="commentsrightbox">
                    <h6 className="toptitle">Comments</h6>

                    <div className="searchbox">
                            <div className="form-group">
                            <input type="text" className="form-control " placeholder="Search" />
                        <div className="searchicon">
                          <SvgIcon
                            sx={{
                              height: "13px",
                              width: "13px",
                            }}
                            component={SearchBlack}
                            inheritViewBox
                          />
                        </div>
                            </div>
                    </div>

                    <div className="commentbox border-0"  >
                      <div className="d-flex ">   
                        <h6>
                            <SvgIcon
                                    sx={{
                                      width: "14px",
                                      height: "14px",
                                    }}
                                    component={CommentIcon}
                                    inheritViewBox
                                  />
                            
                            <span> Mesut Ozil</span>
                        </h6>

                      <span className="text-grey fs-14">10 min. ago</span></div>


                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    
                        
                    </div>
                    <div className="commentbox border-0"  >
                      <div className="d-flex ">   
                        <h6>
                            <SvgIcon
                                    sx={{
                                      width: "14px",
                                      height: "14px",
                                    }}
                                    component={CommentIcon}
                                    inheritViewBox
                                  />
                            
                            <span> Mesut Ozil</span>
                        </h6>

                      <span className="text-grey fs-14">10 min. ago</span></div>


                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    
                        
                    </div>
                    <div className="commentbox border-0"  >
                      <div className="d-flex ">   
                        <h6>
                            <SvgIcon
                                    sx={{
                                      width: "14px",
                                      height: "14px",
                                    }}
                                    component={CommentIcon}
                                    inheritViewBox
                                  />
                            
                            <span> Mesut Ozil</span>
                        </h6>

                      <span className="text-grey fs-14">10 min. ago</span></div>


                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    
                        
                    </div>
                    <div className="commentbox border-0"  >
                      <div className="d-flex ">   
                        <h6>
                            <SvgIcon
                                    sx={{
                                      width: "14px",
                                      height: "14px",
                                    }}
                                    component={CommentIcon}
                                    inheritViewBox
                                  />
                            
                            <span> Mesut Ozil</span>
                        </h6>

                      <span className="text-grey fs-14">10 min. ago</span></div>


                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    
                        
                    </div>
                    <div className="commentbox border-0"  >
                      <div className="d-flex ">   
                        <h6>
                            <SvgIcon
                                    sx={{
                                      width: "14px",
                                      height: "14px",
                                    }}
                                    component={CommentIcon}
                                    inheritViewBox
                                  />
                            
                            <span> Mesut Ozil</span>
                        </h6>

                      <span className="text-grey fs-14">10 min. ago</span></div>


                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    
                        
                    </div>
                    


              </div>
            </Grid>
          </Grid>
        </div>
      </div>
    </>
  );
};

export default sharingView;
