import React from "react";
import {
  Checkbox,
  FormControl,
  FormControlLabel,
  MenuItem,
  Select,
  TableCell,
  TextField,
} from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

const EditRow = ({ handleRowTextChange, currentFormdata, newRowFormData }) => {
  console.log("");
  return (
    currentFormdata &&
    currentFormdata?.map((arr, i) => {
      const options =
        arr && arr?.field_type === "dropdown"
          ? arr?.dropdownValues.map((el) => {
              return <MenuItem value={el.value_id}>{el.value_text}</MenuItem>;
            })
          : "";
      switch (arr.field_type) {
        case "text":
          return (
            <TableCell align="center">
              <TextField
                type="text"
                value={newRowFormData[arr.field_id]?.field_response}
                onChange={(e) => handleRowTextChange(e, arr)}
                id={arr.field_id}
                placeholder="Please enter here"
                size="small"
                variant="standard"
                InputProps={{
                  disableUnderline: true, // <== added this
                }}
              />
            </TableCell>
          );
        case "checkbox":
          return (
            <TableCell align="center">
              <FormControlLabel
                value={newRowFormData[arr.field_id]?.field_response}
                label={arr.field_label}
                id={arr.field_id}
                defaultChecked={arr?.value}
                control={
                  <Checkbox
                    defaultChecked={arr?.value}
                    name={arr.field_label}
                    onChange={(e) => handleRowTextChange(e, arr)}
                  />
                }
              />
            </TableCell>
          );
        case "date":
          return (
            <TableCell align="center">
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DesktopDatePicker
                  value={dayjs(newRowFormData[arr.field_id]?.field_response)}
                  id={arr.field_id}
                  displayEmpty
                  format="DD/MM/YYYY"
                  sx={{
                    input: {
                      // background: "#3E4174",
                      svg: { background: "red" },
                      borderRadius: "6px",
                      //color: "#fff",
                    },
                  }}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      variant: "standard",
                      InputProps: { disableUnderline: true },
                    },
                  }}
                  onChange={(e) => handleRowTextChange(e, arr)}
                  renderInput={(params) => <TextField {...params} />}
                />
              </LocalizationProvider>
            </TableCell>
          );
        case "number":
          return (
            <TableCell align="center">
              <TextField
                type="number"
                fullWidth
                value={newRowFormData[arr.field_id]?.field_response}
                onChange={(e) => handleRowTextChange(e, arr)}
                id={arr?.field_id}
                placeholder="Please enter here"
                size="small"
                variant="standard"
                InputProps={{
                  disableUnderline: true,
                }}
              />
            </TableCell>
          );
        case "dropdown":
          return (
            <TableCell align="center">
              <FormControl variant="standard" fullWidth>
                <Select
                  fullWidth
                  label={arr.field_label}
                  id={arr.field_id}
                  displayEmpty
                  disableUnderline
                  value={newRowFormData[arr.field_id]?.field_response}
                  onChange={(e) => handleRowTextChange(e, arr)}
                >
                  <MenuItem value="">Please select</MenuItem>
                  {options}
                </Select>
              </FormControl>
            </TableCell>
          );
      }
    })
  );
};

export default EditRow;
