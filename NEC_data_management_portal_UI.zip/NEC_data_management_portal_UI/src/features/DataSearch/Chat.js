import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:3006');

function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

// When component mounts, set up the socket event listeners
useEffect(() => {
  // Emit 'fetchAllComments' event when the component mounts
  //socket.emit('fetchAllComments');
  socket.emit('fetchCommentsbySpaceId', 2);


  socket.on('initialComments', (comments) => {
    setMessages(comments);
  });

  socket.on('commentsUpdated', (comments) => {
    setMessages(comments);
  });

  return () => {
    // Cleanup - remove the event listeners when the component unmounts
    socket.off('initialComments');
    socket.off('commentsUpdated');
  };
}, []);

const submitMessage = () => {
  const message = {
    user_id: '2',
    space_id: 1,
    comment_data: input
  };

  // Emit a new 'newComment' event with the new message
  socket.emit('newComment', message);

  setInput('');
};

  return (
    <div>
      <ul>
        {messages.map((message, index) => (
          <li key={index}>
            <strong>{message.user_id}:</strong> {message.comment_data}
          </li>
        ))}
      </ul>
      <input value={input} onChange={(e) => setInput(e.target.value)} />
      <button onClick={submitMessage}>Send</button>
    </div>
  );
}

export default Chat;
