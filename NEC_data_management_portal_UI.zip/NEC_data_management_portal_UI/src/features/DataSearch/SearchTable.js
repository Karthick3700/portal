import React from "react";
import {
  Box,
  Button,
  IconButton,
  SvgIcon,
  Pagination,
  Typography,
  ListItem,
  ListItemText,
} from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { useStyles } from "./DataSearchStyles";
import { ReactComponent as DeleteIcon } from "../../assets/deleteblack.svg";
import { ReactComponent as EditIcon } from "../../assets/editblack.svg";
import { ReactComponent as UpdateIcon } from "../../assets/checkcircle.svg";
import NewRow from "./NewRow";
import EditRow from "./EditRow";
import CircularProgress from "@mui/material/CircularProgress";
import { useTranslation } from "react-i18next";
import Backdrop from "@mui/material/Backdrop";
import dayjs from "dayjs";
import FilterListIcon from "@mui/icons-material/FilterList";
import FilterDataModal from "./components/FilterDataModal";
import editIcon from "../../assets/img/edit-2.svg";
import CloseIcon from "@mui/icons-material/Close";
import DoneAllIcon from "@mui/icons-material/DoneAll";

const SearchTable = ({
  currentFormdata,
  enableAddNewRow,
  handleNewRowClick,
  handleRowTextChange,
  handleNewDelete,
  newRowFormData,
  saveNewRowData,
  formDataListing,
  handleDeleteFormData,
  handleUpdateFormData,
  selectedFormData,
  enableEditRow,
  updateNewRowData,
  formDataLoading,
  limit,
  paginationObj,
  handlePageChange,
  handleFilterClickOpen,
  openFilter,
  handleFilterClose,
  columnFilteredData,
  filteredColumnValueCheck,
  handleFilterColumn,
  handleFilterSearch,
  colSearchValue,
  resetFilter,
  handleAddnewRowClose,
}) => {
  const classes = useStyles();
  const columns = [];
  const { t } = useTranslation();
  // Get language from Redux store

  const tableHeader = currentFormdata?.formFields?.map((arr, i) => {
    columns.push({
      field_label: arr?.field_label,
      type: arr.field_type,
      field_id: arr.field_id,
    });
    return (
      <TableCell key={arr?.field_id} align="center">
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>{arr?.field_label}</Box>
          <Box sx={{ p: 0 }}>
            <IconButton
              onClick={(e) => handleFilterClickOpen(e, arr?.field_label)}
            >
              <FilterListIcon sx={{ color: "#d7d7d7" }} />
            </IconButton>
          </Box>
        </Box>
      </TableCell>
    );
  });

  return (
    <TableContainer component={Box}>
      <FilterDataModal
        handleFilterColumn={handleFilterColumn}
        handleFilterClickOpen={handleFilterClickOpen}
        handleFilterClose={handleFilterClose}
        openFilter={openFilter}
        columnFilteredData={columnFilteredData}
        filteredColumnValueCheck={filteredColumnValueCheck}
        handleFilterSearch={handleFilterSearch}
        colSearchValue={colSearchValue}
        resetFilter={resetFilter}
      />
      <Table
        sx={{ minWidth: 700 }}
        aria-label="customized table"
        className={classes.borderedCell}
      >
        <TableHead className={classes.tableHeading}>
          <TableRow sticky>
            {tableHeader}
            <TableCell variant="head" align="center" sx={{ width: 100 }}>
              Action
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {formDataLoading ? (
            <TableRow>
              <TableCell colSpan={columns.length + 2} align="center">
                <Backdrop
                  sx={{
                    color: "#fff",
                    zIndex: (theme) => theme.zIndex.drawer + 1,
                  }}
                  open={true}
                >
                  <CircularProgress color="inherit" />
                </Backdrop>
              </TableCell>
            </TableRow>
          ) : (
            enableAddNewRow &&
            !enableEditRow && (
              <TableRow>
                <NewRow
                  handleRowTextChange={handleRowTextChange}
                  currentFormdata={currentFormdata.formFields}
                  newRowFormData={newRowFormData}
                />
                <TableCell align="center" sx={{ width: 100 }}>
                  <IconButton onClick={(e) => saveNewRowData(e)}>
                    <DoneAllIcon />
                  </IconButton>
                  <IconButton onClick={handleAddnewRowClose}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            )
          )}
          {enableEditRow && !enableAddNewRow && (
            <TableRow>
              <EditRow
                handleRowTextChange={handleRowTextChange}
                currentFormdata={selectedFormData}
                newRowFormData={newRowFormData}
              />
              <TableCell align="center" sx={{ minWidth: 80 }}>
                <IconButton onClick={(e) => updateNewRowData(e)}>
                  <DoneAllIcon />
                </IconButton>
                <IconButton onClick={(e) => handleNewDelete(e)}>
                  <DeleteIcon />
                </IconButton>
              </TableCell>
            </TableRow>
          )}
          {formDataLoading ? (
            <Backdrop
              sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
              open={true}
            >
              <CircularProgress color="inherit" />
            </Backdrop>
          ) : (
            formDataListing &&
            formDataListing?.length > 0 &&
            formDataListing.map((row) => {
              if (row.form_response_id === enableEditRow) return false;
              return (
                <TableRow key={row.form_response_id}>
                  {columns?.map((colname) => {
                    return (
                      <TableCell align="center">
                        {colname?.type === "date" &&
                        row[colname?.field_label] ? (
                          dayjs(row[colname?.field_label]).format("DD/MM/YYYY")
                        ) : colname?.type === "checkbox" ? (
                          <Box>
                            <ListItem>
                              <ListItemText
                                primary={`value: ${
                                  row[colname?.field_label]?.value
                                    ? JSON.parse(
                                        row[colname?.field_label]?.value
                                      )
                                    : "False"
                                }`}
                              />
                              <ListItemText
                                primary={`Is Required: ${
                                  row[colname?.field_label]?.is_required
                                    ? JSON.parse(
                                        row[colname?.field_label]?.is_required
                                      )
                                    : "False"
                                }`}
                              />
                            </ListItem>
                          </Box>
                        ) : (
                          row[colname?.field_label]
                        )}
                      </TableCell>
                    );
                  })}
                  <TableCell align="center" sx={{ minWidth: 80 }}>
                    <IconButton
                      onClick={(e) => handleUpdateFormData(e, row, columns)}
                    >
                      <img src={editIcon} />
                    </IconButton>
                    <IconButton onClick={(e) => handleDeleteFormData(e, row)}>
                      <SvgIcon
                        sx={{
                          width: "20px",
                          height: "20px",
                        }}
                        component={DeleteIcon}
                        inheritViewBox
                      />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>
      {/* <Box
        padding={1}
        alignItems="center"
        justifyContent="center"
        display="flex"
        width="100%"
      >
        <Button
          onClick={handleNewRowClick}
          size="small"
          variant="outlined"
          className={classes.btn}
          sx={{ mt:2}}
        >
          {t("data_search.add_new_row")}
        </Button>
      </Box> */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          my: 3,
          px: 3,
        }}
      >
        <Typography variant="body2">
          {formDataListing && formDataListing.length
            ? `Showing ${paginationObj?.offset + 1 || ""}-${
                paginationObj?.offset + formDataListing?.length || ""
              } of
            ${paginationObj?.totalCount || ""} records`
            : "No records to display"}
        </Typography>
        <Pagination
          count={Math.ceil(paginationObj?.totalCount / limit)}
          page={Math.ceil((paginationObj?.offset + 1) / limit)}
          onChange={handlePageChange}
          shape="rounded"
        />
      </Box>
    </TableContainer>
  );
};

export default SearchTable;
