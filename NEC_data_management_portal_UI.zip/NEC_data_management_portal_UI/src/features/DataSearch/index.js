import React, { useState, useEffect, useDeferredValue } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import dayjs from "dayjs";
import {
  Box,
  Grid,
  Paper,
  IconButton,
  InputBase,
  Typography,
  Button,
  Backdrop,
  CircularProgress,
  Card,
  Stack,
  Alert,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import {
  getAllFormsData,
  getFormdetails,
} from "../../redux/forms/formsSelector";
import {
  isformDataLoading,
  isformsLoading,
  selectSaveFormDataMsg,
  selectSaveFormDataType,
  selectSearchedColumnValues,
} from "../../redux/datasearch/dataSearchSelector";
import {
  selectSaveNewSpaceMsg,
  selectSaveNewSpaceType,
} from "../../redux/sharing/sharingSelector";
import { getFormListings, getFormdataById } from "../../redux/forms/formsSlice";
import { clearSpaceMessage } from "../../redux/sharing/sharingSlice";
import {
  clearFormDataMessage,
  deleteNewFormData,
  downloadTemplate,
  exportFormDatatoExcel,
  formDatabyApplyFilter,
  getDataByFormId,
  getFormDatabySearchFilter,
  saveNewFormData,
  updateNewFormData,
  uploadFormdata,
  resetformDataAlterInfo,
  createDashboard,
  getDashboardId,
  getDomainDataListing,
} from "../../redux/datasearch/dataSearchSlice";
import SearchTable from "./SearchTable";
import ImportDataModal from "./components/ImportDataModal";
import CommentsModal from "./components/CommentsModal";
import AddSpace from "../Sharing-and-Collaboration/AddSpace";
import AlertDialog from "../../app/component/AlertDialog";
import MsgDialog from "../../app/component/MsgDialog";
import { useStyles } from "./DataSearchStyles";
import AlertMessage from "../../app/common/AlertMessage";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import { Link } from "react-router-dom";
import plusIcon from "../../assets/img/plus.svg";
import exportIcon from "../../assets/img/export.svg";
import createSpIcon from "../../assets/img/createspace.svg";
import commentsIcon from "../../assets/img/comment.svg";
import createDashIcon from "../../assets/img/comment.svg";
import filterIcon from "../../assets/img/filter.svg";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import alertIcon from "../../assets/img/alerticon.svg";

const DataSearch = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const formdata = useSelector(getAllFormsData);
  const formDataListing = useSelector((state) => state.datasearch.formdata);
  const createDashboardData = useSelector(
    (state) => state.datasearch.createDashboard
  );
  const paginationObj = useSelector(
    (state) => state.datasearch.formdata?.pagination
  );
  const formDataAlterStatus =
    useSelector((state) => state.datasearch.formDataAlterStatus) || "error";
  const formDataAlterMessage = useSelector(
    (state) => state.datasearch.formDataAlterMessage
  );
  const formDataLoading = useSelector(isformDataLoading);
  const formLoading = useSelector(isformsLoading);
  const spaceSavedMsg = useSelector(selectSaveNewSpaceMsg);
  const spaceSavedType = useSelector(selectSaveNewSpaceType);
  const formDataMsg = useSelector(selectSaveFormDataMsg);
  const formDataType = useSelector(selectSaveFormDataType);
  const selectSearchedValues = useSelector(selectSearchedColumnValues);
  const id = formdata && formdata[0]?.form_id;
  const space_id = formdata && formdata[0]?.space_id;
  const [newRowFormData, setNewRowFormData] = useState([]);
  const [enableAddNewRow, setEnableAddNewRow] = useState(false);
  const [enableEditRow, setEnableEditRow] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedForm, setSelectedForm] = useState({ id: "", space_id: "" });
  const deferredSearch = useDeferredValue(searchTerm);

  const [colsearchtext, setColSearchText] = useState("");
  const colSearchValue = useDeferredValue(colsearchtext);

  const currentFormdata = useSelector(getFormdetails);
  const [openImport, setOpenImport] = useState(false);
  const [selectedFormData, setSelectedFormData] = useState([]);
  const [searchFormData, setSearchFormData] = useState([]);
  const [filteredFormListing, setFilteredFormListing] = useState([]);
  const [filteredColumns, setFilteredColumns] = useState([]);
  const [opencommentmodal, setOpenCommentModal] = useState(false);
  const [openspace, setOpenSpace] = React.useState(false);
  const [openspacemessage, setSaveSpaceMessage] = React.useState(false);
  const [openMessage, setOpenMessage] = React.useState(false);
  const [openFilter, setOpenFilter] = React.useState(false);
  const [columnFilteredData, setColumnFilteredData] = React.useState({});
  const [selectedColumnValue, setSelectedColumnValue] = React.useState("");
  const [limit] = useState(10);
  const [search, setSearch] = useState("");
  const [isAlertMessage, setIsAlertMessage] = useState(false);
  const [saveNewRowDataAlert, setSaveNewRowDataAlert] = useState(false);

  const userdata = sessionStorage.getItem("user");
  const user = JSON.parse(userdata);

  const { t, i18n } = useTranslation();
  // Get language from Redux store
  const language = useSelector((state) => state.language);

  useEffect(() => {
    dispatch(getFormListings());
  }, []);

  useEffect(() => {
    if (selectSearchedValues) {
      setColumnFilteredData(selectSearchedValues);
    }
  }, [selectSearchedValues]);

  useEffect(() => {
    return () => {
      dispatch(resetformDataAlterInfo());
    };
  }, [dispatch]);

  useEffect(() => {
    if (createDashboardData && createDashboardData.appId !== undefined) {
      window.open(
        "http://172.20.60.71/sense/app/" +
          createDashboardData.appId +
          "/overview",
        "_blank"
      );
    }
  }, [createDashboardData]);

  useEffect(() => {
    if (formDataAlterMessage && formDataAlterStatus) {
      setIsAlertMessage(true);
    } else {
      setIsAlertMessage(false);
    }
  }, [formDataAlterMessage, formDataAlterStatus]);

  useEffect(() => {
    if (!isAlertMessage) {
      setTimeout(() => {
        dispatch(resetformDataAlterInfo());
      }, 400);
    }
  }, [dispatch, isAlertMessage]);

  useEffect(() => {
    if (id) {
      setSelectedForm({ id, space_id });
    }
  }, [dispatch, id, space_id]);

  useEffect(() => {
    if (selectedForm.id) {
      dispatch(getFormdataById({ id: selectedForm.id }));
      dispatch(
        getDataByFormId({ id: selectedForm.id, offset: 0, limit, search })
      );
    }
  }, [selectedForm.id, limit, search, dispatch]);

  const handlePageChange = (event, newPage) => {
    dispatch(getFormdataById({ id: selectedForm.id }));
    dispatch(
      getDataByFormId({
        id: selectedForm.id,
        offset: (newPage - 1) * limit,
        limit,
        search,
      })
    );
  };

  useEffect(() => {
    if (formDataMsg) {
      setOpenMessage(true);
    }
  }, [formDataMsg]);

  useEffect(() => {
    if (spaceSavedMsg) {
      setSaveSpaceMessage(true);
    }
  }, [spaceSavedMsg]);

  useEffect(() => {
    if (formDataListing) {
      if (formDataListing.data.length > 0) {
        const columnsdata = formDataListing?.data
          ? Object?.keys(formDataListing?.data[0])
          : [];
        setFilteredColumns(columnsdata);
      }
      const listing = formDataListing?.data ?? [];
      setFilteredFormListing(listing);
    }
  }, [formDataListing]);

  // function to change language
  useEffect(() => {
    i18n.changeLanguage(language);
  }, [i18n, language]);

  const handleMessageClose = () => {
    setOpenMessage(false);
    dispatch(clearFormDataMessage());
  };

  const handleFormlistingById = (e, form_id, space_id) => {
    if (selectedForm.id !== form_id) {
      setNewRowFormData([]);
      setEnableAddNewRow(false);
      setEnableEditRow(false);
      setSelectedForm({ id: form_id, space_id });
    }
  };

  const importData = (e) => {
    e.preventDefault();
    setOpenImport(true);
  };

  const closeImportData = () => {
    setOpenImport(false);
  };

  const addManually = () => {
    setOpenImport(false);
    setEnableAddNewRow(true);
  };

  const handleNewRowClick = () => {
    setEnableAddNewRow(true);
  };

  const downloadExcelTemplate = (e, form_id) => {
    dispatch(downloadTemplate({ id: form_id }));
  };

  const handleDeleteFormData = (e, rowdata) => {
    const { form_id } = currentFormdata;
    dispatch(
      deleteNewFormData({
        id: rowdata.form_response_id,
        form_id,
        offset: 0,
        limit,
        search,
      })
    );
  };

  const handleExportData = (e, form_id) => {
    dispatch(exportFormDatatoExcel({ id: form_id }));
  };

  const updateNewRowData = () => {
    const { form_id } = currentFormdata;
    const data = Object.keys(newRowFormData).map((key, i) => {
      return newRowFormData[key];
    });
    const editRowData = {
      form_id,
      form_response_id: enableEditRow,
      fields: [...data],
      offset: 0,
      limit,
      search,
    };
    setEnableEditRow("");
    setEnableAddNewRow(false);
    dispatch(updateNewFormData(editRowData));
  };

  const handleUpdateFormData = (e, rowdata, colarr) => {
    const data = [];
    const selectedFormDataList = currentFormdata?.formFields?.map((ar) => {
      const selFields = colarr.find(
        (col) => col.field_label === ar.field_label
      );
      let resp = "";
      if (selFields.type === "date") {
        resp = dayjs(new Date(rowdata[ar.field_label])).format("YYYY/MM/DD");
      } else {
        resp = filterFieldResponse(selFields.type, rowdata[ar.field_label]);
      }
      data[selFields.field_id] = {
        field_id: selFields?.field_id,
        field_response: resp,
      };
      return {
        ...ar,
        value: rowdata[ar.field_label],
      };
    });
    setEnableEditRow(rowdata?.form_response_id);
    setSelectedFormData(selectedFormDataList);
    setNewRowFormData(data);
  };

  const filterFieldResponse = (type, value) => {
    switch (type) {
      case "date":
        return dayjs(value);
      case "number":
        return parseInt(value);
      default:
        return value;
    }
  };

  const handleRowTextChange = (e, fields) => {
    const data = [];
    if (fields.field_type === "date") {
      data[fields.field_id] = {
        field_id: fields.field_id,
        field_response: dayjs(e).format("YYYY/MM/DD"),
      };
    } else if (fields.field_type === "number") {
      data[fields.field_id] = {
        field_id: fields.field_id,
        field_response: parseInt(e.target.value),
      };
    } else if (fields.field_type === "checkbox") {
      data[fields.field_id] = {
        field_id: fields.field_id,
        field_response: e.target.checked,
      };
    } else {
      data[fields.field_id] = {
        field_id: fields.field_id,
        field_response: e.target.value,
      };
    }
    setNewRowFormData((prevState) => ({
      ...prevState,
      ...data,
    }));
  };

  const handleCreateSpace = () => {
    setOpenSpace(true);
  };

  const handleComments = () => {
    setOpenCommentModal(true);
  };

  const handleCommentsClose = () => {
    setOpenCommentModal(false);
  };

  const handleAddSpaceClose = () => {
    setOpenSpace(false);
    dispatch(clearSpaceMessage());
  };

  const handleAddSpaceMessageClose = () => {
    if (dispatch(clearSpaceMessage())) {
      setSaveSpaceMessage(false);
    }
  };

  const handleImportData = (e) => {
    const { form_id } = currentFormdata;
    dispatch(
      uploadFormdata({
        formdata: e.target.files[0],
        formId: form_id,
        offset: 0,
        limit,
        search,
      })
    );
    setOpenImport(false);
  };

  const handleFilterClickOpen = (e, label) => {
    const data = [];
    formDataListing &&
      formDataListing.data?.length > 0 &&
      formDataListing.data.map((row) => {
        data[row[label]] = columnFilteredData[row[label]]
          ? columnFilteredData[row[label]]
          : Object.keys(columnFilteredData)?.length === 0
          ? true
          : false;
      });
    setSelectedColumnValue(label);
    setColumnFilteredData(data);
    setOpenFilter(true);
  };

  const handleFilterClose = () => {
    setOpenFilter(false);
  };

  const filteredColumnValueCheck = (e, label) => {
    const data = structuredClone(columnFilteredData);
    data[label] = e.target.checked;
    setColumnFilteredData((prevState) => ({
      ...prevState,
      ...data,
    }));
  };

  const handleFilterColumn = () => {
    const { form_id } = currentFormdata;
    const colValues = Object.keys(columnFilteredData).filter(
      (key) => columnFilteredData[key] === true
    );
    const responseIds = formDataListing.data
      .filter((el) => colValues.includes(el[selectedColumnValue]))
      .map((res) => parseInt(res.form_response_id));
    const { offset } = formDataListing.pagination;
    const payload = {
      form_response_ids: responseIds,
      form_id,
      offset,
      limit,
    };
    dispatch(formDatabyApplyFilter(payload));
    setOpenFilter(false);
  };

  const saveNewRowData = () => {
    if (newRowFormData && newRowFormData?.length === 0) {
      setSaveNewRowDataAlert(true);
      return;
    }
    const { form_id } = currentFormdata;
    const data = Object.keys(newRowFormData).map((key, i) => {
      return newRowFormData[key];
    });
    const newRowData = {
      form_id,
      fields: [...data],
      offset: 0,
      limit,
      search,
    };
    dispatch(saveNewFormData(newRowData));
    setEnableAddNewRow(false);
  };

  const handleFilterSearch = (e) => {
    if (e.target.value?.length >= 3) {
      const { offset, limit } = formDataListing.pagination;
      dispatch(
        getFormDatabySearchFilter({
          search: e.target.value,
          id: selectedForm.id,
          field_label: selectedColumnValue,
          offset,
          limit,
        })
      );
    }
    setColSearchText(e.target.value);
  };

  const resetFilter = () => {
    dispatch(
      getDataByFormId({ id: selectedForm.id, offset: 0, limit, search })
    );
    setOpenFilter(false);
  };
  // create_dashboard
  const [openConfirmation, setOpenConfirmation] = useState(false);

  const handleCreateDashboard = (dashboardId) => {
    // Perform the necessary actions for creating a dashboard
    if (dashboardId) {
      window.open(
        `http://172.20.60.71/sense/app/${dashboardId}/overview`,
        "_blank"
      );
    } else {
      setOpenConfirmation(true);
    }
  };

  const handleConfirmationClose = () => {
    setOpenConfirmation(false);
  };

  const handleConfirmationConfirm = () => {
    // Perform the necessary actions for creating a dashboard
    dispatch(
      createDashboard({
        form_id: selectedForm.id,
        app_name: "MyApp-dashboard-form-id-" + selectedForm.id,
      })
    );
    //  getDataByFormId({ id: selectedForm.id, offset: 0, limit, search })
    setOpenConfirmation(false);
  };

  const handleAddnewRowClose = () => {
    setEnableAddNewRow(false);
  };

  const formListing =
    formdata &&
    formdata?.length > 0 &&
    formdata
      ?.filter(({ form_name }) => {
        return (
          deferredSearch.length === 0 || form_name.includes(deferredSearch)
        );
      })
      ?.map((form) => {
        return (
          <Box className={classes.formListContainer}>
            <Box
              className={
                selectedForm?.id && selectedForm.id === form?.form_id
                  ? classes.formListActiveElements
                  : classes.formListElements
              }
              onClick={(e) =>
                handleFormlistingById(e, form?.form_id, form?.space_id)
              }
            >
              <Typography>
                {form?.form_name}: {form?.form_desc}
              </Typography>
            </Box>
          </Box>
        );
      });

  return (
    <Box sx={{ flexGrow: 1 }}>
      <MsgDialog
        open={openMessage}
        handleClose={handleMessageClose}
        type={formDataType}
        title={
          formDataType === "success"
            ? "Your request has been sent."
            : "Your request has been cancelled."
        }
        bodycontent={formDataMsg}
      />
      <MsgDialog
        open={openspacemessage}
        handleClose={handleAddSpaceMessageClose}
        type={spaceSavedType}
        btnText={"Go To Space"}
        url={"/Sharingandcollaboration"}
        showGotoSpaceButton={true}
        title={
          spaceSavedType === "success"
            ? "Your request has been sent."
            : "Your request has been cancelled."
        }
        bodycontent={spaceSavedMsg}
      />
      <AlertDialog
        open={openspace}
        handleClose={handleAddSpaceClose}
        title={"Add New Space"}
        bodycontent={<AddSpace handleClose={handleAddSpaceClose} />}
      />
      <CommentsModal
        handleCommentsClose={handleCommentsClose}
        opencommentmodal={opencommentmodal}
        selectedFormData={selectedFormData}
        selectedForm={selectedForm}
      />
      <ImportDataModal
        downloadExcelTemplate={downloadExcelTemplate}
        openImport={openImport}
        addManually={addManually}
        handleImportData={handleImportData}
        form_id={currentFormdata?.form_id}
        closeImportData={closeImportData}
      />
      <Box sx={{ width: "100%" }}>
        <Box sx={{ p: 0, mb: 3 }}>
          <Box sx={{ pt: 4, px: 3 }}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link underline="none" to="/home" className="breadCrumb">
                Home
              </Link>
              <Link underline="none" className="activeBreadCrumb">
                Data Search
              </Link>
            </Breadcrumbs>
          </Box>
          <Box className="d-flex flex-row align-items-cener justify-content-between">
            <Box sx={{ px: 3, py: 1 }} className="mainheading">
              <Typography variant="h1" gutterBottom>
                Data Search
              </Typography>
            </Box>
            <Box sx={{ px: 3 }}>
              <Box className={classes.dataSearchContainer}>
                {/* <Typography className={classes.dataSearchText}>
                    {t("search")}
                  </Typography> */}
                <Button
                  onClick={handleCreateSpace}
                  size="small"
                  className="btn-text text-black"
                  variant="text"
                  startIcon={<img src={createSpIcon} className="smallicon" />}
                >
                  {t("data_search.create_space")}{" "}
                </Button>
                <Button
                  size="small"
                  onClick={handleComments}
                  className="btn-text text-black"
                  variant="text"
                  startIcon={<img src={commentsIcon} className="smallicon" />}
                >
                  {" "}
                  {t("data_search.comments")}
                </Button>
                {user?.qlik_professional_access_id && (
                  <Button
                    size="small"
                    className="btn-text text-black"
                    variant="text"
                    startIcon={
                      <img src={createDashIcon} className="smallicon" />
                    }
                    onClick={() =>
                      handleCreateDashboard(currentFormdata?.dashboard_id)
                    }
                  >
                    {" "}
                    {currentFormdata?.dashboard_id
                      ? `Dashboard (${
                          currentFormdata.dashboard_name ||
                          currentFormdata.dashboard_id
                        })`
                      : t("data_search.create_dashbord")}
                  </Button>
                )}
                <Button
                  size="small"
                  className="btn-text btn-filter"
                  variant="text"
                  startIcon={<img src={filterIcon} className="smallicon" />}
                >
                  {" "}
                  {t("data_search.FILTER")}
                </Button>
              </Box>
            </Box>
          </Box>
        </Box>
        <Box sx={{ px: 3 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} lg={9}>
              <Card className="boxRounded" sx={{ p: 0 }}>
                <Box className="customDialogHeader">
                  <Box className="customDialogHeaderLeft">
                    <Typography variant="span" className="subtitle">
                      Data Search
                    </Typography>
                    <Box className="dialogSearch">
                      <Paper component="form" elevation={0} sx={{ p: 0 }}>
                        <InputBase
                          sx={{ ml: 0, flex: 1 }}
                          placeholder={t("search")}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="input-box-filled"
                        />
                        <IconButton
                          type="button"
                          sx={{ p: "3px" }}
                          aria-label={t("search")}
                        >
                          <SearchIcon className="search-icon" />
                        </IconButton>
                      </Paper>
                    </Box>
                  </Box>
                  <Stack direction="row" className="pr-0">
                    <Button
                      variant="text"
                      startIcon={<img src={plusIcon} className="smallicon" />}
                      className="btn-text"
                      sx={{ color: "#1F1F1F" }}
                      onClick={(e) => importData(e)}
                    >
                      {" "}
                      {t("data_search.add_data")}
                    </Button>
                    <Button
                      variant="text"
                      startIcon={<img src={plusIcon} className="smallicon" />}
                      className="btn-text"
                      sx={{ color: "#1F1F1F" }}
                      onClick={handleNewRowClick}
                    >
                      {t("data_search.add_new_row")}
                    </Button>
                    <Button
                      variant="text"
                      startIcon={<img src={exportIcon} className="smallicon" />}
                      className="btn-text"
                      sx={{ color: "#1F1F1F" }}
                      onClick={(e) =>
                        handleExportData(e, currentFormdata?.form_id)
                      }
                    >
                      {t("data_search.export")}
                    </Button>
                  </Stack>
                </Box>
                <Box>
                  <Box className={classes.searchTableContainer}>
                    <AlertMessage
                      type={formDataAlterStatus}
                      message={formDataAlterMessage}
                      open={isAlertMessage}
                      onClose={() => setIsAlertMessage(false)}
                    />
                    {saveNewRowDataAlert && (
                      <Alert
                        severity="error"
                        action={
                          <IconButton
                            aria-label="close"
                            color="inherit"
                            size="small"
                            onClick={() => {
                              setSaveNewRowDataAlert(false);
                            }}
                          >
                            <CloseIcon fontSize="inherit" />
                          </IconButton>
                        }
                        sx={{ mb: 2 }}
                      >
                        Error! Empty records cannot be saved. Please enter some
                        records to save.
                      </Alert>
                    )}
                    <SearchTable
                      formDataListing={filteredFormListing}
                      currentFormdata={currentFormdata}
                      enableAddNewRow={enableAddNewRow}
                      handleNewRowClick={handleNewRowClick}
                      handleRowTextChange={handleRowTextChange}
                      newRowFormData={newRowFormData}
                      saveNewRowData={saveNewRowData}
                      handleDeleteFormData={handleDeleteFormData}
                      handleUpdateFormData={handleUpdateFormData}
                      selectedFormData={selectedFormData}
                      enableEditRow={enableEditRow}
                      updateNewRowData={updateNewRowData}
                      deferredSearchFormData={searchFormData}
                      formDataLoading={formDataLoading}
                      handleFilterClickOpen={handleFilterClickOpen}
                      handleFilterClose={handleFilterClose}
                      openFilter={openFilter}
                      columnFilteredData={columnFilteredData}
                      filteredColumnValueCheck={filteredColumnValueCheck}
                      handleFilterColumn={handleFilterColumn}
                      limit={limit}
                      paginationObj={paginationObj}
                      handlePageChange={handlePageChange}
                      handleFilterSearch={handleFilterSearch}
                      colSearchValue={colSearchValue}
                      resetFilter={resetFilter}
                      handleAddnewRowClose={handleAddnewRowClose}
                    />
                  </Box>
                </Box>
              </Card>
            </Grid>
            <Grid item xs={12} lg={3}>
              <Card className="boxRounded2">
                <Box className="blockHeading2" sx={{ mb: 0 }}>
                  <Typography variant="h3" gutterBottom>
                    {t("data_search.existing_form")}
                  </Typography>
                </Box>
                <Box sx={{ margin: "0 -20px" }}>
                  <Box
                    sx={{ overflowY: "scroll", height: "400px" }}
                    paddingBottom={5}
                  >
                    {formLoading ? (
                      <Backdrop
                        sx={{
                          color: "#fff",
                          zIndex: (theme) => theme.zIndex.drawer + 1,
                        }}
                        open={true}
                      >
                        <CircularProgress color="inherit" />
                      </Backdrop>
                    ) : (
                      formListing
                    )}
                  </Box>
                </Box>
              </Card>
            </Grid>
          </Grid>

          {/* <Chat /> */}
          {/* <Box className={classes.exportMainContainer}>
            <Box className={classes.dataSearchContainer} sx={{ height: 'auto'}}>
              <Box>
                <Paper
                  component="form"
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    width: 200,
                    border: "solid 1px #B2B2B2 ",
                    height: 34,
                  }}
                  className={classes.searchBox}
                >
                  <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder={t("search")}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className={classes.searchInput}
                  />
                  <IconButton
                    type="button"
                    sx={{ p: "10px" }}
                    aria-label={t("search")}
                  >
                    <SearchIcon />
                  </IconButton>
                </Paper>
              </Box>
              <Box>
                <Button size="small" variant="outlined" className={classes.btn}>
                  {" "}
                  {t("data_search.FILTER")}
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  className={classes.btn}
                  onClick={handleCreateDashboard}
                  
                >
                  {t("data_search.create_dashbord")}
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  className={classes.btn}
                  onClick={(e) => importData(e)}
                >
                  {" "}
                  {t("data_search.add_data")}
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  className={classes.btn}
                  onClick={(e) => handleExportData(e, currentFormdata?.form_id)}
                >
                  {t("data_search.export")}
                </Button>
              </Box>
            </Box>
          </Box> */}
        </Box>
      </Box>
      <Dialog
        open={openConfirmation}
        onClose={handleConfirmationClose}
        className="customDialog alertPop"
      >
        {/* <DialogTitle>Create Dashboard Confirmation</DialogTitle> */}
        <IconButton
          aria-label="close"
          onClick={handleConfirmationClose}
          className="dialogClose"
        >
          <CloseIcon />
        </IconButton>
        <DialogContent className="modal-content">
          <img src={alertIcon} className="dialogIcon medium" />
          <Typography gutterBottom className="msgText text-black">
            Are you sure you want to create a dashboard for this form #{" "}
            {selectedForm.id}?
          </Typography>
          <Box className="dialogButtons">
            <Button
              onClick={handleConfirmationClose}
              variant="outlined"
              className="btn-outline large"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmationConfirm}
              autoFocus
              variant="outlined"
              className="btn-primary large"
            >
              Confirm
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};
export default DataSearch;
