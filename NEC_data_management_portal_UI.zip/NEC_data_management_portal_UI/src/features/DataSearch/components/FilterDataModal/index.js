import React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import { ReactComponent as FilterSearchIcon } from "../../../../assets/filter-search.svg";
import { ReactComponent as VectorIcon } from "../../../../assets/Vector.svg";
import {
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  InputAdornment,
  TextField,
} from "@mui/material";
import { useStyles } from "./FilterDataModalStyle";

const FilterDataModal = ({
  handleFilterClose,
  openFilter,
  columnFilteredData,
  filteredColumnValueCheck,
  handleFilterColumn,
  handleFilterSearch,
  colSearchValue,
  resetFilter,
}) => {
  const classes = useStyles();
  const filteredColumns = Object?.keys(columnFilteredData).map((key) => {
    return (
      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              onChange={(e) => filteredColumnValueCheck(e, key)}
              checked={columnFilteredData[key]}
              color="default"
            />
          }
          label={key}
        />
      </FormGroup>
    );
  });

  return (
    <React.Fragment>
      <Dialog onClose={handleFilterClose} open={openFilter} className="customDialog medium">
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          <Box sx={{ display: 'flex', alignItems: 'center'}}>
            <FilterSearchIcon sx={{ height: "20px", width: "20px" }} />
            <Box className={classes.filterName}>
              <Typography variant="h2">Filters</Typography>
            </Box>
          </Box>
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleFilterClose}
          className="dialogClose"
        >
          <CloseIcon />
        </IconButton>
        <DialogContent dividers>
          <Box className={classes.mainContainer}>
            <Box className={classes.searchContainer}>
              <Typography className={classes.searchTxt}>Search</Typography>
            </Box>
            <Box>
              <TextField
                fullWidth
                onChange={handleFilterSearch}
                value={colSearchValue}
                size="small"
                placeholder="Search"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end" sx={{ mr:1}}>
                      <VectorIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
            <Box className={classes.filtersMainContainer}>
              {filteredColumns}
            </Box>
          </Box>
            <Box className={classes.btnMainContainer}>
              <Button
                variant="outlined"
                className='btn-outline large'
                onClick={resetFilter}
              >
                Reset
              </Button>
              <Button 
                variant="outlined"
                className="btn-primary large" 
                onClick={handleFilterColumn}
              >
                Apply
              </Button>
            </Box>
          </DialogContent>
      </Dialog>
    </React.Fragment>
  );
};

export default FilterDataModal;
