import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    mainContainer:{
        width: '100%',
        height: '400px',
        overflowY: 'auto'
    },
    filtersMainContainer:{
       padding:'16px',
       borderRadius: '0px 0px 3px 3px',
       border: '1px solid #DCDCDC',
       marginTop:'2px'
    },
    searchTxt:{
        color: '#757575',
        fontFamily: 'Inter',
        fontSize: '14px',
        fontWeight: 600,
        textAlign: 'left'
    },
    filterName:{
        marginLeft:'3px'
    },
    searchContainer:{
        marginBottom:'7px'
    },
    btnMainContainer:{
        margin: '20px 0 0',
        gap: 20,
        display:'flex',
        justifyContent:'center',
        alignItems:'center',
        width:'100%'
    }
})

export { useStyles };