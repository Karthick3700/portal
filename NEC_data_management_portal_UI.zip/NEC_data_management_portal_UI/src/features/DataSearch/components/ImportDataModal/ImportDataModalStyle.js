import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    mainContainer:{
        width : '536px',
        // height: '337px',
        borderRadius:'10px',
        background:'FFFF'
    },
    headerContainer:{
        display: 'flex',
        justifyContent:'space-between',
        borderBottom:'1px solid #DBDBDB'
    },
    addDataText:{
        color:'#3C3C3C',
        fontSize:'0.875rem !important',
        padding:'16px',
        lineHeight: '1.6 !important' ,
        fontWeight: '500 !important',
        color: '#1F1F1F',
    },
    importContainer:{
        height:'84px',
        borderRadius:'8px',
        border:'1px dashed #E51448 ',
    },
    manualContainer:{
        height:'84px',
        borderRadius:'8px',
        border:'1px dashed #E51448 ',
        marginTop:'15px'
       
    },
    excelMainContainer:{
        padding:'3rem'
    },
    imageContainer:{
        background:'#E51448',
        width:'70px'
    },
    excelIcon:{
        height: '35px !important',
        width: '30px !important',
        padding: '20px'
    },
    excelText:{
        display: 'flex',
        justifyContent:'space-between',
        padding: '30px 0px 0px 15px',
        fontFamily:'Montserrat',
        fontSize:'14px',
        color:'#3C3C3C',
        opacity:1
    },
    btnClose: {
        padding: '16px !important'
    },
    btnUpload: {
        padding:'30px 201px 30px 0 !important',
        color: '#000 !important',
        '&:hover':{
            background:'transparent !important'
        }
    },
    excelImportContainer:{
        display: 'flex',
        width: '100%',
        justifyContent:'space-between'
    },
    btnUploadExcel: {
        padding:'30px 150px 30px 0 !important',
        color: '#000 !important',
        '&:hover':{
            background:'transparent !important'
        }
    }

})

export { useStyles };