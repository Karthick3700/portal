import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { Box, Button, IconButton, SvgIcon, Typography } from '@mui/material';
import { useStyles } from './ImportDataModalStyle';
import { ReactComponent as ExcelIcon } from "../../../../assets/excel.svg";
import { ReactComponent as AddManuallyIcon } from "../../../../assets/addmannualy.svg";
import { ReactComponent as CloseIcon } from "../../../../assets/crossicon.svg";
import DownloadIcon from '@mui/icons-material/Download';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { useState,useEffect } from "react";
import { Link } from 'react-router-dom';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import ImportExportOutlinedIcon from '@mui/icons-material/ImportExportOutlined';
import TouchAppOutlinedIcon from '@mui/icons-material/TouchAppOutlined';

const ImportDataModal=({
  openImport, 
  closeImportData, 
  addManually, 
  downloadExcelTemplate,
  form_id,
  handleImportData
})=> {
  const classes = useStyles();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  const { t, i18n } = useTranslation();
  // Get language from Redux store
  const language = useSelector(state => state.language);

  // function to change language
  useEffect(() => {
    i18n.changeLanguage(language);
  }, [i18n, language]);

  return (
    <div>
      <Dialog
        fullScreen={fullScreen}
        open={openImport}
        onClose={closeImportData}
        disableBackdropClick={true} 
        disableEscapeKeyDown 
        aria-labelledby="responsive-dialog-title"
      >
        <Box className={classes.mainContainer}>
            <Box className={classes.headerContainer}>
              <Typography variant='h2' className={classes.addDataText}>
                {t('data_import_upload.add_data')}
              </Typography>
              <IconButton 
                className={classes.btnClose}
                color="success"
                onClick={closeImportData}
              >
                <CloseIcon />
              </IconButton>
            </Box>
            <Box className={classes.excelMainContainer}>
              <Box className="fileDropBox">
                  <Button 
                    type='text' 
                    className='downloadLink btn-text' 
                    onClick={(e)=>downloadExcelTemplate(e,form_id)} 
                    sx={{mb:0}}
                  >
                      Download Sample File <CloudDownloadIcon className='mediumicon' /> 
                  </Button>
              </Box>
              <Box className="fileDropBox" sx={{ mt:2}}>
                  <Button 
                    component="label"
                    type='text' 
                    className='downloadLink btn-text' 
                    onChange={handleImportData} 
                    sx={{mb:0}}
                  >
                    <input type='file' hidden />
                    {t('data_import_upload.import_excel')}
                    <ImportExportOutlinedIcon className='mediumicon' /> 
                  </Button>
              </Box>
              <Box className="fileDropBox" sx={{ mt:2}}>
                  <Button 
                    component="label"
                    type='text' 
                    className='downloadLink btn-text' 
                    onClick={addManually}
                    sx={{mb:0}}
                  >
                    {t('data_import_upload.add_manually')}
                    <TouchAppOutlinedIcon className='mediumicon' /> 
                  </Button>
              </Box>
              {/* <Box display='flex' className={classes.importContainer}>
                <Box className={classes.imageContainer}>
                  <SvgIcon className={classes.excelIcon}
                    component={ExcelIcon}
                    inheritViewBox
                  />
                </Box>
                <Box className={classes.excelImportContainer}>
                  <Button fullWidth className={classes.btnUploadExcel} onChange={handleImportData} variant='text' component="label">
                    <input type='file' hidden />
                    {t('data_import_upload.import_excel')}
                  </Button>
                  <IconButton onClick={(e)=>downloadExcelTemplate(e,form_id)} sx={{color: '#e51448'}}>
                        <DownloadIcon />
                  </IconButton>
                </Box>
              </Box> */}
              {/* <Box display='flex' className={classes.manualContainer}>
                <Box className={classes.imageContainer}>
                  <SvgIcon className={classes.excelIcon}
                    component={AddManuallyIcon}
                    inheritViewBox
                  />
                </Box>
                <Box width='100%'>
                  <Button fullWidth onClick={addManually} className={classes.btnUpload} variant='text' component="label">                    
                  {t('data_import_upload.add_manually')}
                  </Button>
                </Box>
              </Box> */}
            </Box>
        </Box>
      </Dialog>
    </div>
  );
}

export default ImportDataModal;