import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    topScrollPaper: {
        alignItems: "flex-end !important",
        justifyContent:'end !important'
    },
    topPaperScrollBody: {
        verticalAlign: "right !important"
    }
});

export { useStyles };