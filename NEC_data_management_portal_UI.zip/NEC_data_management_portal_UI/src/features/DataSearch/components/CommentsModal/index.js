import React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import { useStyles } from './CommentModalStyle';
import Comments from '../../../Sharing-and-Collaboration/Comments';

const CommentsModal=({ 
  opencommentmodal,
  handleCommentsClose,
  selectedForm 
})=>{
  const classes = useStyles();
  const { space_id, id } = selectedForm;
  return (
    <React.Fragment>
      <Dialog
        scroll="paper"
        classes={{
          scrollPaper: classes.topScrollPaper,
          paperScrollBody: classes.topPaperScrollBody
        }}
        open={opencommentmodal}
        onClose={handleCommentsClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent sx={{padding:'0' , maxWidth: 420, overflowX: 'hidden'}}>
          <Comments space_id={space_id} form_id={id} isComment={true} commentTag={true}/>
        </DialogContent>
      </Dialog>
    </React.Fragment>
  );
}

export default CommentsModal;
