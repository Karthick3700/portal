import { Box, Breadcrumbs, Paper, Tab, Typography } from "@mui/material";
import { TabPanel, TabContext, TabList } from "@mui/lab";
import { styled } from "@mui/material/styles";
import { useState, useEffect, React } from "react";
import { ReactComponent as DashboardIcon } from "../../assets/createdashboard.svg";
import { ReactComponent as ReportIcon } from "../../assets/reportwhite.svg";
import { Link } from "react-router-dom";
import CardTiles from "../../app/component/Dashboard/CardTiles";
import { height } from "@mui/system";
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import { fetchdashboardList, fetchdashboardStreamsList, resetStreamData , fetchreportList, fetchItemsPerReportList }
  from '../../redux/dashboard/dashboardSlice';
import { useDispatch } from 'react-redux';
import { useParams, useLocation } from "react-router-dom";
import HomeIcon from '@mui/icons-material/Home';
import ReportCardTiles from "../../app/component/Report/ReportCardTiles";

const ToggleTabs = styled(TabList)({
  background: "#3E4174 0% 0% no-repeat padding-box",
  borderRadius: "10px 10px 0px 0px",
  maxHeight: "50px",
  maxWidth: "30vw",
  color: "#ffffff",
  opacity: "1",
  "& .MuiTabs-indicator": {
    backgroundColor: "#E51448",
  },
});

const CustomPanel = styled(TabPanel)({
  background: "#fff",
  color: "#fff",
  //height: "55vh",
  border: "1px solid #FFFFFF80",
  borderRadius: "0px 10px 10px 10px",
});

const CustomTab = styled((props) => <Tab disableRipple {...props} />)(
  ({ theme }) => ({
    display: "flex",
    flexDirection: "row",
    textTransform: "none",
    width: "50%",
    padding: "5px 8px",
    minHeight: "55px",
    color: "#fff",
    "& svg": {
      width: "20px",
      height: "20px",
      paddingRight: "5px",
    },
    "&:hover": {
      background: "#E51448",
      color: "#ffffff",
      opacity: 1,
    },
    "&.Mui-selected": {
      background: "#E51448",
      color: "#fff",
    },
    "&.Mui-focusVisible": {
      backgroundColor: "#d1eaff",
    },
  })
);

const Dashboard = () => {
  const { stream_id } = useParams();
  const { businessDomainId } = useParams();
  const { reportId } = useParams();
  const [value, setValue] = useState("1");
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  const location = useLocation();
  // Get language from Redux store
  const language = useSelector(state => state.language);
  const [IdValue , setIdValue] = useState(0)
  //const dashboardListData = useSelector(state => state.dashboardList);
  // const { data, fetchStatus, streamData } = useSelector(state => state.dashboardList);

    // function to change language
    useEffect(() => {
      i18n.changeLanguage(language);
      dispatch(fetchdashboardList());
      dispatch(fetchreportList());
    
    }, [i18n, language, dispatch]);

 

  // let dashboardListData = data

  const dashboardStreamListData = useSelector(state => state.dashboardList.streamData);
  
  //const reportsData = useSelector(state => state.dashboardList.reportsData);

   // Fetch the status and data from the state
   const { data, fetchStatus, fetchStreamStatus, streamData , reportsData , itemsPerReportData } =
   useSelector(state => state.dashboardList);

  
  useEffect(() => {
    if (location.pathname.includes('/reports/')) {
      let num = location.pathname.split('/').pop();
      setIdValue(num);
    }
  }, [location.pathname, reportId]);
  
  useEffect(() => {
    // Here you can dispatch the action to fetch items based on the updated IdValue
    if (IdValue) {
      dispatch(fetchItemsPerReportList({ business_domain: IdValue }));
    }
  }, [IdValue, dispatch]);


  const [prevStreamId, setPrevStreamId] = useState(null);
  


  useEffect(() => {
    // Only dispatch action if stream_id has changed
    if (stream_id !== prevStreamId) {
      dispatch(fetchdashboardStreamsList({ stream_id: stream_id }));
      setPrevStreamId(stream_id);  // Update previous stream_id
    }

    return () => {
      dispatch(resetStreamData());
    };
  }, [dispatch, stream_id, prevStreamId]);

  useEffect(() => {
    // Update the selected tab based on the route
    if (location.pathname.startsWith("/dashboard")) {
      setValue("1");
    } else if (location.pathname.startsWith("/report")) {
      setValue("2");
    }
  }, [location.pathname]);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const sampleReportArray = reportsData

  return (
    <>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ p: 0, mb: 3 }}>
          <Box sx={{ pt: 4, px: 3 }}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link
                underline="none"
                to='/home'
                className='breadCrumb'
              >
                Home
              </Link>
              <Link underline="none" className='activeBreadCrumb'>
                {value === "1" ? t('dashboard.dashboard_title') : t('dashboard.report')}
              </Link>
            </Breadcrumbs>
          </Box>
          <Box sx={{ width: '100%', px: 3, py: 1 }} className='mainheading'>
            <Typography variant="h1" gutterBottom>
              {value === "1" ? t('dashboard.dashboard_title') : t('dashboard.report')}
            </Typography>
          </Box>
        </Box>
        {fetchStatus.isLoading ? (
          <Typography sx={{ px: 3 }}>Loading {value === "1" ? t('dashboard.dashboard_title') : t('dashboard.report')} list...</Typography>
        ) : fetchStatus.errors ? (
          <Typography sx={{ px: 3 }}>Error: {fetchStatus.errors}</Typography>
        ) : fetchStatus.status === true ? (
          <Box sx={{ px: 3 }}>
            <Box sx={{ width: "100%", height: "100%" }}>
              <TabContext value={value}>
                <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                  <ToggleTabs onChange={handleChange} aria-label="lab API tabs example">
                    <CustomTab label={t('dashboard.dashboard_title')} icon={<DashboardIcon />} value="1" component={Link} to="/dashboard" />
                    <CustomTab label={t('dashboard.report')} icon={<ReportIcon />} value="2" component={Link} to="/report" />
                  </ToggleTabs>
                </Box>
                <CustomPanel value="1" sx={{ boxShadow: '0px 23px 40px -18px rgba(0, 0, 0, 0.06) !important' }}>
                  <Box>
                    <Typography variant="h3" sx={{ color: "#000", fontSize: '1.25rem', marginBottom: 2 }}>
                      {t('dashboard.dashboard_title')}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography sx={{ color: "#000", fontSize: "14px" }}>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor.
                    </Typography>
                  </Box>
                  {stream_id && streamData && <CardTiles items={streamData.output} showLink={false} />}
                  {!stream_id && data && <CardTiles items={data.output} />}
                </CustomPanel>
                <CustomPanel value="2" sx={{ boxShadow: '0px 23px 40px -18px rgba(0, 0, 0, 0.06) !important' }}>
                  <Box>
                    <Typography variant="h3" sx={{ color: "#000", fontSize: '1.25rem', marginBottom: 2 }}>
                      {t('dashboard.report')}
                    </Typography>
                  </Box>
                  <Box>
                    <Typography sx={{ color: "#000", fontSize: "14px" }}>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor.
                    </Typography>
                  </Box>
                  {location.pathname.includes('/report') && !location.pathname.includes('/reports') ? <ReportCardTiles items={sampleReportArray}  /> : null} 
                  {location.pathname.includes('/reports/') && itemsPerReportData ? <ReportCardTiles items={itemsPerReportData} showLink={false} /> : null} 

                </CustomPanel>
              </TabContext>
            </Box>
          </Box>
        ) : null}
      </Box>
    </>
  );
};

export default Dashboard;