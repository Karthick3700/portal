import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, Link } from 'react-router-dom';
import dayjs from 'dayjs';
import {
  Box,
  Card,
  Grid,
  Breadcrumbs,
  Typography,
  Paper,
  List,
  ListItem,
  Divider,
  ListItemText,
  ListItemAvatar,
} from '@mui/material';
import {
  Markunread as MarkunreadIcon,
  MarkEmailRead as MarkEmailReadIcon
} from '@mui/icons-material';
import { getNotifications } from '../../redux/notifications/notificationSelector';
import { initReadNotification } from '../../redux/notifications/notificationSlice';
import { useStyles } from './styles';

const PushNotifications = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const classes = useStyles();
  const notifications = useSelector(getNotifications);

  const markReadNotification = (notificationId, notificationUrl) => {
    dispatch(initReadNotification({ notificationId }));
    navigate(notificationUrl);
  };

  return (
    <>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ p: 0, mb: 3 }}>
          <Box sx={{ pt: 4, px: 3 }}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link
                underline="none"
                to='/home'
                className={classes.breadCrumb}
              >
                Home
              </Link>
              <Link underline="none" to='/' className={classes.activeBreadCrumb}>Notifications</Link>
            </Breadcrumbs>
          </Box>
          <Box sx={{ width: '100%', px: 3, py: 1 }} className={classes.mainheading}>
            <Typography variant="h1" gutterBottom>
              Notifications
            </Typography>
          </Box>
        </Box>
        <Box sx={{ px: 3 }}>
          <Box sx={{ flexGrow: 1 }}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Card className='boxRounded' sx={{ p: 0 }}>
                  <Paper elevation={0} sx={{ p: 3 }}>
                    <List sx={{ width: '100%', p: 0 }} >
                      {notifications.map((notification, index) => (
                        <React.Fragment key={`Notification-deatil-${notification.notification_id}`}>
                          <ListItem
                            alignItems="flex-start"
                            sx={{ p: 0, cursor: 'pointer' }}
                            className={`notification ${notification.relatedUsers?.isRead ? '' : 'unread'}`}
                            onClick={() => markReadNotification(notification.notification_id, notification.relatedUsers?.redirectUrl)}
                          >
                            <ListItemAvatar sx={{ minWidth: '40px' }}>
                              {notification.relatedUsers?.isRead ?
                                <MarkEmailReadIcon sx={{ width: '24px', height: '24px', color: '#666' }} /> :
                                <MarkunreadIcon sx={{ width: '24px', height: '24px', color: '#666' }} />}
                            </ListItemAvatar>
                            <ListItemText>
                              <Box className='d-flex flex-row justify-content-between'>
                                <Typography
                                  variant="h6"
                                  gutterBottom
                                  className='heading-small'
                                >
                                  {notification.title}
                                </Typography>
                              </Box>
                              <Typography
                                sx={{ display: 'inline', fontSize: '14px' }}
                                component="span"
                                variant="body2"
                              >
                                {notification.message}
                              </Typography>
                              <p className='notification-date text-left'> {dayjs(notification.createdAt).format('llll')}</p>
                            </ListItemText>
                          </ListItem>
                          {index < notifications.length - 1 && (
                            <Divider component="li" sx={{ my: 1 }} />
                          )}
                        </React.Fragment>
                      ))}
                    </List>
                  </Paper>
                </Card>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default PushNotifications;
