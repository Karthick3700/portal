import React, { useEffect } from "react";
import { Box, Button, Grid, Paper, SvgIcon, Typography, Container, Card } from "@mui/material";
import { ReactComponent as SearchWhite } from "../../assets/searchwhite.svg";
import { ReactComponent as PlusIcon } from "../../assets/pluslarge.svg";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAllFormsData, isFormListLoading, selectSaveFormMsg, selectSaveFormType } from "../../redux/forms/formsSelector";
import { clearFormMessage, deleteFormById, getFormListings } from "../../redux/forms/formsSlice";
import FormListing from "./components/FormListing";
import DeleteModal from "./components/DeleteModal";
import { useTranslation } from "react-i18next";
import { useStyles } from "./FormBuilderStyle";
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import MsgDialog from "../../app/component/MsgDialog";
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import { ReactComponent as PlusIconNew } from "../../assets/img/plus-new.svg";

const FormBuilder = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const classes = useStyles();
  const { t } = useTranslation();
  const formdata = useSelector(getAllFormsData);
  const formSavedMsg = useSelector(selectSaveFormMsg);
  const formSavedType = useSelector(selectSaveFormType);
  const isListLoading = useSelector(isFormListLoading);
  const [confirmdelete, setConfirmDelete] = React.useState(false);
  const [openMessage, setOpenMessage] = React.useState(false);
  const [deleteform, setDeleteform] = React.useState({form_id:''})

  useEffect(() => {
    dispatch(getFormListings());
  }, []);

  useEffect(() => {
    if(formSavedMsg){
      setOpenMessage(true);
    }
  }, [formSavedMsg]);

  const addForm = () => {
    navigate("/addform");
  };

  const handleMessageClose=()=>{
    setOpenMessage(false);
    dispatch(clearFormMessage());
  }

  const handleCloseDelete=()=>{
    setConfirmDelete(false);
  }

  const handleDeleteClick=(e,form_id)=>{
    setDeleteform({form_id});
    dispatch(getFormListings());
    setConfirmDelete(true);
  }

  const handleDeleteForm=()=>{
    setConfirmDelete(false);
    const { form_id } = deleteform;
    dispatch(deleteFormById({form_id}));
  }

  const formlistings =
  !isListLoading && formdata &&
    formdata?.length > 0 ?
    formdata?.map((form) => {
      if (form?.form_status === "active") {
        return (
          <FormListing
            handleDeleteClick={handleDeleteClick}
            form_id={form?.form_id}
            form_status={form?.form_status}
            formname={form?.form_name}
            description={form?.form_desc}
          />
        );
      }
    }): '';

  return (
    <>
    <MsgDialog
      open={openMessage}
      handleClose={handleMessageClose} 
      type={formSavedType}
      title={formSavedType ==='success' 
        ? 'Your request has been sent.'
        : 'Your request has been cancelled.'}
      bodycontent={formSavedMsg}
    />
    <DeleteModal 
      confirmdelete={confirmdelete} 
      handleCloseDelete={handleCloseDelete} 
      handleDeleteForm={handleDeleteForm}
    />
      <Box sx={{ width: '100%'}}>
          <Box sx={{ p: 0, mb:3}}>
            <Box sx={{pt:4, px:3}}>
                <Breadcrumbs aria-label="breadcrumb">
                    <Link
                        underline="none"
                        to='/home'
                        className='breadCrumb'
                    >
                       {t('form_builder.add_new_form_home.home')}
                    </Link>
                    <Link underline="none" className={classes.activeBreadCrumb} >{t('form_builder.add_new_form_home.form_builder')}</Link>
                </Breadcrumbs>
            </Box>
            <Box sx={{ width: '100%', px:3,  py:1 }} className='mainheading'>
              <Typography variant="h1" gutterBottom>
                 {t('form_builder.add_new_form_home.form_builder')}
              </Typography>
            </Box>
          </Box>
        <Box sx={{ px:3 }}>
          <Card className="boxRounded2">
              <Box className="blockHeading2 justify-content-between">
                <Typography variant="h3" gutterBottom>
                  {t('form_builder.form_builder_title')}
                </Typography>
                <div className="form-group">
                  <input type="text" className="form-control " placeholder={t('form_builder.form_builder_title')}  />
                  <div className="searchicon">
                    <SvgIcon
                      sx={{
                        height: "13px",
                        width: "13px",
                      }}
                      component={SearchWhite}
                      inheritViewBox
                    />
                  </div>
                </div>
              </Box>
              <Box className="bottomcontent">
                <Box sx={{ flexGrow: 1, pt:3, pb:4, px:3 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6} lg={4} xl={3}>
                      <Button 
                        variant="outlined"
                        onClick={addForm}
                        className="addformcard cursor-pointer w-100 h-100">
                        <SvgIcon
                          onClick={addForm}
                          sx={{
                            height: "45px",
                            width: "45px",
                            margin: '0 auto'
                          }}
                          component={PlusIconNew}
                          inheritViewBox
                        />
                        <span style={{ marginTop: 15, color: '#19223B'}}>
                          {t('form_builder.add_new_form')}
                        </span>
                      </Button>
                    </Grid>
                    {isListLoading ? <Backdrop
                        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                        open={true}
                      >
                      <CircularProgress color="inherit" />
                    </Backdrop>: formlistings }
                  </Grid>
                </Box>
              </Box>
          </Card>
        </Box>
      </Box>
    </>
  );
};

export default FormBuilder;
