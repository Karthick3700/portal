import React, { useCallback, useEffect, useMemo } from "react";
import { Box, Breadcrumbs, Button, Grid, Paper, Typography } from "@mui/material";
import { useStyles } from "./AddFormStyles";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  getDraggedElementByType,
  getDroppedElementByType,
} from "../../app/common/utils";
import {
  defaultInputElement,
  DRAGGED,
  DROPPED,
} from "../../app/common/constants";
import { useDispatch } from "react-redux";
import {
  getFormdataById,
  saveUpdateForm,
} from "../../redux/forms/formsSlice";
import { useSelector } from "react-redux";
import { getFormdetails } from "../../redux/forms/formsSelector";
import { getformdetailsDroppedElements } from "../../app/common/functionutils";
import { getViewDroppedElementByType } from "../../app/common/viewformutils";

const EditForm = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { id } = useParams();
  const navigate = useNavigate();
  const formdetails = useSelector(getFormdetails);

  const [formName, setFormName] = React.useState({
    fName: "",
    description: "",
  });

  const [datevalue, setDateValue] = React.useState(null);
  const [inputs, setInputs] = React.useState(defaultInputElement);
  const [selectenable, setSelectEnable] = React.useState({ id: "", type: "" });
  const [optionsInput, setOptionsInput] = React.useState([]);
  const [tempCheckboxInput, setTempCheckboxInput] = React.useState([]);

  const getFormdetailsDropped = async () => {
    if (formdetails?.formFields && formdetails?.formFields?.length > 0) {
      const formElement = await getformdetailsDroppedElements(
        formdetails?.formFields
      );
      const data = defaultInputElement.concat(formElement);
      setInputs(data);
    }
  };

  useEffect(() => {
    if (id) {
      dispatch(getFormdataById({ id }));
    }
  }, [id]);

  useEffect(() => {
    if (formdetails?.formFields && formdetails?.formFields?.length > 0) {
      getFormdetailsDropped();
    }
  }, [formdetails?.formFields]);

  const onDragStart = (ev, id) => {
    ev.dataTransfer.setData("id", id);
  };

  const onDragOver = (ev) => {
    ev.preventDefault();
  };

  const onDrop = (ev, cat) => {
    if (ev.target.id === DRAGGED) return false;
    let id = ev.dataTransfer.getData("id");
    const tasks = [...inputs];
    const count = tasks.length + 1;
    const currentTaskArr = tasks.find((ar) => ar.id === parseInt(id));
    const currentTask = [
      {
        id: count,
        name: currentTaskArr.name,
        category: cat,
        type: currentTaskArr?.type,
        options: currentTaskArr?.options,
        field_label: currentTaskArr?.label,
        settings: currentTaskArr?.settings,
        field_info: currentTaskArr?.field_info,
        field_text: currentTaskArr?.field_text,
        field_is_req: currentTaskArr?.field_is_req,
        field_is_read_only: currentTaskArr?.field_is_read_only,
        field_is_hidden: currentTaskArr?.field_is_hidden,
        field_is_multi_sel: currentTaskArr?.field_is_multi_sel,
      },
    ];
    const updatedval = tasks.concat(currentTask);
    setInputs(updatedval);
  };

  const textBoxChangeHandler = (e, id) => {
    const currentVal = inputs.find((ar) => ar.id === parseInt(id));
    currentVal.value = e.target.value;
    setInputs(inputs);
  };

  const handleLableClick = (e, id) => {
    const currentLabel = inputs.find((ar) => ar.id === parseInt(id));
    currentLabel.label = e.target.innerText;
    setInputs(inputs);
  };

  const enableCustomeInputHandler = (id, type) => {
    const data = { id: parseInt(id), type };
    setSelectEnable(data);
  };

  const handleDateChange = (newValue) => {
    setDateValue(newValue);
  };

  const checkBoxChangeHandler = (e, id, type) => {
    let currentInput = inputs.find((ar) => ar.id === parseInt(id));
    const currentSettings = e?.target?.name;
    currentInput[currentSettings] =
      e.target.value === "on" ? true : e.target.value;
    setTempCheckboxInput(currentInput);
  };

  const addCheckboxOptions = () => {
    inputs.splice(
      inputs.findIndex((el) => el.id === tempCheckboxInput?.id),
      1
    );
    const updatedInputs = inputs?.concat(tempCheckboxInput);
    setInputs(updatedInputs);
  };

  const onSelectInputChange = (e, elements) => {
    const newOptions = elements.options.concat({
      value_text: e.target.value,
      value_id: e.target.value,
    });
    const newElement = [{ ...elements, options: newOptions }];
    setOptionsInput(newElement);
  };

  const deleteElement = (e) => {
    const id = parseInt(e.target.id);
    const allInputs = [...inputs];
    const index = allInputs.findIndex((a) => a.id === id);
    if (index === -1) return;
    allInputs.splice(index, 1);
    setInputs(allInputs);
  };

  const handleFormLabel = (e) => {
    const data = [];
    data[e.target.id] = e.target.innerText;
    setFormName((prevState) => ({
      ...prevState,
      ...data,
    }));
  };

  const btnSubmitHandler = () => {
    const inputData = [];
    const filteredElements = inputs?.filter((el) => el?.category === DROPPED);
    filteredElements?.map((ar) => {
      let inpElement;
      if (ar.type === "dropdown") {
        inpElement = {
          field_type: ar.type,
          field_label: ar.label,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
          dropdown_values: ar?.options,
        };
      } else if (ar.type === "checkbox") {
        inpElement = {
          field_type: ar.type,
          field_label: ar?.label,
          field_info: ar?.field_info,
          field_text: ar?.field_text,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
        };
      } else {
        inpElement = {
          field_type: ar.type,
          field_label: ar?.label,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
        };
      }

      inputData.push(inpElement);
    });

    const formData = {
      form_name: formName?.fName ? formName?.fName : formdetails?.form_name,
      form_desc: formName?.description ? formName?.description : formdetails?.form_desc,
      form_fields: [...inputData],
    };
    dispatch(saveUpdateForm({ id, formData }));
    navigate("/formbuilder");
    navigate(0);
  };

  const btnCancel=()=>{
    navigate("/formbuilder");
    navigate(0);
  }

  const addDropdownOptions = () => {
    inputs.splice(
      inputs.findIndex((el) => el.id === optionsInput?.id),
      1
    );
    const updatedInputs = inputs?.concat(optionsInput);
    setInputs(updatedInputs);
    setSelectEnable({ id: "", type: "" });
  };

  const allInputs = {
    draggedElements: [],
    droppedElements: [],
  };

  inputs?.forEach((el) => {
    const droppedElement = el?.name && getDraggedElementByType(el?.name);
    const draggedElement =
      el?.name &&
      getViewDroppedElementByType(
        el,
        handleLableClick,
        datevalue,
        handleDateChange,
        deleteElement,
        onSelectInputChange,
        enableCustomeInputHandler,
        selectenable,
        addDropdownOptions,
        checkBoxChangeHandler,
        addCheckboxOptions,
        textBoxChangeHandler
      );
    allInputs[el.category].push(
      <Box
        key={el.name}
        onDragStart={(e) => onDragStart(e, el.id, el.category)}
        draggable={el.category !== DROPPED}
        className={el.category}
        id={el.category}
      >
        {el.category === DROPPED ? (
          <Box className={classes.droppableInputElements} marginBottom={2}>
            {draggedElement}
          </Box>
        ) : (
          <Box draggable className={classes.dragInputElements}>
            {droppedElement}
          </Box>
        )}{" "}
      </Box>
    );
  });

  return (
    <>
      <Box sx={{ width: '100%'}}>
        <Box sx={{ p: 0, mb:3}}>
          <Box sx={{pt:4, px:3}}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link underline="none" to='/home' className={classes.breadCrumb} >
                  Home
              </Link>
              <Link underline="none" to='/formbuilder' className={classes.breadCrumb}>
                  Form Builder
              </Link>
              <Link underline="none" className={classes.activeBreadCrumb}>
                  View Form
              </Link>
            </Breadcrumbs>
          </Box>
          <Box sx={{ width: '100%', px:3,  py:1 }} className='mainheading'>
            <Typography variant="h1" gutterBottom>
                View Form
            </Typography>
          </Box>
        </Box>
        <Box sx={{mx:3}}>
          <Box className={classes.btnSavecontainer}>
            <Box display="flex" sx={{gap: 2, width: '65.666667%'}}>
              <Typography
                sx={{ 
                  width: '50%',
                  backgroundColor: '#fff', 
                  padding: '8.5px 16px', 
                  outline: 'none',
                  border: '1px solid rgba(0, 0, 0, 0.15)' 
                }}
                color="#000"
                id="fName"
                contenteditable="true"
                onBlur={handleFormLabel}
              >
                {formdetails && formdetails?.form_name
                  ? formdetails?.form_name
                  : "Form name"}
              </Typography>
              <Typography
                color="#000"
                id="description"
                contenteditable="true"
                onBlur={handleFormLabel}
                sx={{ 
                  width: '50%',
                  backgroundColor: '#fff', 
                  padding: '8.5px 16px', 
                  outline: 'none',
                  border: '1px solid rgba(0, 0, 0, 0.15)' 
                }}
              >
                {formdetails && formdetails?.form_desc
                  ? formdetails?.form_desc
                  : "Form name"}
              </Typography>
            </Box>
            <Button
              onClick={btnCancel}
              variant="contained"
              className='btn-primary'
              size="small"
            >
              {" "}
              Cancel{" "}
            </Button>
          </Box>
          <Grid container className={classes.formContainer}>
            <Grid
              onDragOver={(e) => onDragOver(e)}
              onDrop={(e) => onDrop(e, DROPPED)}
              item
              xs={8}
              className={classes.droppedElements}
              id="droppedElements"
            >
              <Paper elevation={0} className='boxRounded2' sx={{ height: '100%'}}>
                  <Box className="blockHeading2">
                    <Typography variant="h3" gutterBottom>
                      New Form
                    </Typography>
                  </Box>
                {allInputs.droppedElements}
              </Paper>
            </Grid>
            {/* <Grid
              item
              bgcolor="#3E4174"
              xs={4}
              className={classes.inputSidebarContainer}
            >
              <Box padding={3} className={classes.formElementContainer}>
                <Typography className={classes.formElementText}>
                  {" "}
                  Form Elements{" "}
                </Typography>
              </Box>
              <Box
                padding={3}
                className="draggedElements"
                id="draggedElements"
                onDragOver={(e) => onDragOver(e)}
                onDrop={(e) => {
                  onDrop(e, DRAGGED);
                }}
              >
                {allInputs.draggedElements}
              </Box>
            </Grid> */}
          </Grid>
        </Box>
      </Box>
    </>
  );
};

export default EditForm;
