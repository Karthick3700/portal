import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Grid,
  List,
  ListItem,
  ListItemText,
  Paper,
  TextField,
  Typography,
  Container,
  Alert,
  IconButton,
} from "@mui/material";
import { useStyles } from "./AddFormStyles";
import { Link, useNavigate } from "react-router-dom";
import {
  getDraggedElementByType,
  getDroppedElementByType,
} from "../../app/common/utils";
import {
  defaultInputElement,
  DRAGGED,
  DROPPED,
} from "../../app/common/constants";
import { useDispatch } from "react-redux";
import { saveAddForm } from "../../redux/forms/formsSlice";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import MsgDialog from "../../app/component/MsgDialog";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import HomeIcon from "@mui/icons-material/Home";
import CloseIcon from "@mui/icons-material/Close";
import AlertDialog from "../../app/component/AlertDialog";
import DomainValues from "./components/DomainValues";
import DomainColValues from "./components/DomainValuesMockData.json";
import { getDomainDataListing, getDomainDataByDomainId } from "../../redux/datasearch/dataSearchSlice";

const AddForm = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const domainDataListing = useSelector(
    (state) => state.datasearch.domainDataListing
  );
  const domainDataByDomainId = useSelector(
    (state) => state.datasearch.domainDataByDomainId
  );
  const [formName, setFormName] = React.useState({
    fName: "",
    description: "",
  });
  const [datevalue, setDateValue] = React.useState(null);
  const [inputs, setInputs] = React.useState(defaultInputElement);
  const [selectenable, setSelectEnable] = React.useState({ id: "", type: "" });
  const [optionsInput, setOptionsInput] = React.useState([]);
  const [tempCheckboxInput, setTempCheckboxInput] = React.useState([]);
  const [erroropen, setErrorOpen] = React.useState(false);
  const [erroritems, setErrorItems] = React.useState([]);
  const [chkdoneerror, setChkDoneError] = React.useState(false);
  const [chkoptionDone, setChkOptionDone] = React.useState(false);
  const [openDomainValues, setOpenDomainValues] = React.useState(false);
  const [domainDataListingLength, setDomainDataListingLength] = useState(0);
  const [selectedDomain, setSelectedDomain] = useState({});
  const [domainEnableData, setDomainEnableData] = useState({ id: "", type: "", elements: {} });
  const [selectedDomainDataByDomainId, setSelectedDomainDataByDomainId] = useState([]);

  const { t, i18n } = useTranslation();
  // Get language from Redux store
  const language = useSelector((state) => state.language);

  useEffect(() => {
    // Change i18n language when `language` changes
    i18n.changeLanguage(language);
  }, [i18n, language]);

  useEffect(() => {
    dispatch(getDomainDataListing({ offset: 0, limit: 100 }));
  }, []);

  useEffect(() => {
    if (domainDataListing?.length) {
      setDomainDataListingLength(domainDataListing?.length)
    }
  }, [domainDataListing]);

  useEffect(() => {
    if (domainDataByDomainId) {
      setSelectedDomainDataByDomainId(domainDataByDomainId)
    }
  }, [domainDataByDomainId]);

  const onDragStart = (ev, id) => {
    ev.dataTransfer.setData("id", id);
  };

  const onDragOver = (ev) => {
    ev.preventDefault();
  };

  const onDrop = (ev, cat) => {
    if (ev.target.id === DRAGGED) return false;
    let id = ev.dataTransfer.getData("id");
    const tasks = [...inputs];
    const count = tasks.length + 1;
    const currentTaskArr = tasks.find((ar) => ar.id === parseInt(id));
    const currentTask = [
      {
        id: count,
        name: currentTaskArr.name,
        category: cat,
        error: true,
        type: currentTaskArr?.type,
        options: currentTaskArr?.options,
        label: currentTaskArr?.label,
        settings: currentTaskArr?.settings,
        field_text: "",
        field_info: "",
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false,
      },
    ];
    const updatedval = tasks.concat(currentTask);
    setInputs(updatedval);
  };

  const textBoxChangeHandler = (e, id) => {
    const currentVal = inputs.find((ar) => ar.id === parseInt(id));
    currentVal.value = e.target.value;
    setInputs(inputs);
  };

  const handleLableClick = (e, id) => {
    const currentLabel = inputs.find((ar) => ar.id === parseInt(id));
    currentLabel.label = e.target.innerText;
    setInputs(inputs);
  };

  const enableCustomeInputHandler = (id, type) => {
    const data = { id: parseInt(id), type };
    setSelectEnable(data);
  };

  const enableDomainInputHandler = (id, type, elements) => {
    setDomainEnableData({
      id: id,
      type: type,
      elements: elements
    });

    setOpenDomainValues(true);
  };

  const addDomainValues = (e, label) => {
    const uniqueValuesSet = new Set();
    const selectColData = selectedDomainDataByDomainId?.map((el) => {
      const value = el[label];
      if (!uniqueValuesSet.has(value)) {
        uniqueValuesSet.add(value);
        return {
          value_text: value,
          value_id: value,
        };
      }
      return null;
    }).filter(Boolean);

    const newOptions = domainEnableData.elements.options.concat(selectColData);
    const newElement = { ...domainEnableData.elements, options: newOptions };
    if (newElement && newElement?.options?.length > 0) {
      inputs.splice(
        inputs.findIndex((el) => el.id === newElement?.id),
        1
      );
      const updatedInputs = inputs?.concat(newElement);
      updatedInputs.sort((a, b) => a.id - b.id);
      setInputs(updatedInputs);
      setSelectEnable({ id: "", type: "" });
    }

    setOpenDomainValues(false);
  };

  const handleAddDomainClose = () => {
    setOpenDomainValues(false);
  };

  const handleDomainChange = (domain) => {
    if (domain) {
      dispatch(getDomainDataByDomainId({ form_id: domain.form_id, offset: 0, limit: 100 }));
    }
    setSelectedDomain(domain);
  }

  const handleDateChange = (newValue) => {
    setDateValue(newValue);
  };

  const checkBoxChangeHandler = (e, id, type) => {
    let currentInput = inputs.find((ar) => ar.id === parseInt(id));
    const currentSettings = e?.target?.name;
    currentInput[currentSettings] =
      e.target.value === "on" ? true : e.target.value;
    setTempCheckboxInput(currentInput);
  };

  const addCheckboxOptions = () => {
    if (!tempCheckboxInput?.id) {
      setChkDoneError(true);
      return;
    }
    inputs.splice(
      inputs.findIndex((el) => el.id === tempCheckboxInput?.id),
      1
    );
    const updatedInputs = inputs?.concat(tempCheckboxInput);
    setInputs(updatedInputs);
    setChkOptionDone(true);
    setTempCheckboxInput([]);
  };

  const allInputs = {
    draggedElements: [],
    droppedElements: [],
  };

  const onSelectInputChange = (e, elements) => {
    const newOptions = elements.options.concat({
      value_text: e.target.value,
      value_id: e.target.value,
    });
    const newElement = { ...elements, options: newOptions };
    setOptionsInput(newElement);
  };

  const deleteElement = (e) => {
    const id = parseInt(e.target.id);
    const allInputs = [...inputs];
    const index = allInputs.findIndex((a) => a.id === id);
    if (index === -1) return;
    allInputs.splice(index, 1);
    setInputs(allInputs);
    setOptionsInput([]);
    setTempCheckboxInput([]);
    setChkOptionDone(false);
  };

  const handleFormLabel = (e) => {
    const data = [];
    data[e.target.id] = e.target.value;
    setFormName((prevState) => ({
      ...prevState,
      ...data,
    }));
  };

  const handleOpenError = () => {
    setErrorOpen(true);
  };

  const handleErrorClose = () => {
    setErrorOpen(false);
  };

  const btnSubmitHandler = () => {
    const inputData = [];
    const filteredElements = inputs?.filter((el) => el?.category === DROPPED);
    filteredElements?.map((ar) => {
      let inpElement;
      if (ar.type === "dropdown") {
        inpElement = {
          field_type: ar.type,
          field_label: ar.label,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
          dropdown_values: ar?.options,
        };
      } else if (ar.type === "checkbox") {
        inpElement = {
          field_type: ar.type,
          field_label: ar?.label,
          // field_infoLabel: ar?.infoLabel,
          // field_infoText: ar?.infoText,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
        };
      } else {
        inpElement = {
          field_type: ar.type,
          field_label: ar?.label,
          field_is_req: ar?.field_is_req,
          field_is_read_only: ar?.field_is_read_only,
          field_is_hidden: ar?.field_is_hidden,
          field_is_multi_sel: ar?.field_is_multi_sel,
        };
      }

      inputData.push(inpElement);
    });

    const formData = {
      form_name: formName?.fName ?? "",
      form_desc: formName?.description ?? "",
      form_fields: [...inputData],
    };
    let erroritems = formData.form_fields.map((el) => {
      if (el.field_label.length === 0)
        return (
          <ListItem>
            <ListItemText
              primary={
                <Typography variant="subtitle2" sx={{ color: "red" }}>
                  {el.field_type} label is empty
                </Typography>
              }
            />
          </ListItem>
        );
    });
    const formnameerror =
      formData && formData?.form_name?.length < 1 ? (
        <ListItem>
          <ListItemText
            primary={
              <Typography variant="subtitle2" sx={{ color: "red" }}>
                Formname is empty
              </Typography>
            }
          />
        </ListItem>
      ) : (
        ""
      );
    const errorElements = (
      <Paper elevation={0}>
        <List dense={true}>
          {formnameerror}
          {erroritems}
        </List>
      </Paper>
    );
    erroritems = erroritems && erroritems?.filter((el) => el !== undefined);
    if (erroritems?.length > 0 || formData?.form_name?.length < 1) {
      setErrorItems(errorElements);
      handleOpenError();
    } else {
      dispatch(saveAddForm(formData));
      navigate("/formbuilder");
    }
  };

  const addDropdownOptions = () => {
    if (optionsInput && optionsInput?.options?.length > 0) {
      inputs.splice(
        inputs.findIndex((el) => el.id === optionsInput?.id),
        1
      );
      const updatedInputs = inputs?.concat(optionsInput);
      updatedInputs.sort((a, b) => a.id - b.id);
      setInputs(updatedInputs);
      setSelectEnable({ id: "", type: "" });
    }
  };

  inputs?.forEach((el) => {
    const droppedElement = el?.name && getDraggedElementByType(el?.name);
    const draggedElement =
      el?.name &&
      getDroppedElementByType(
        el,
        handleLableClick,
        datevalue,
        handleDateChange,
        deleteElement,
        onSelectInputChange,
        enableCustomeInputHandler,
        selectenable,
        addDropdownOptions,
        checkBoxChangeHandler,
        addCheckboxOptions,
        textBoxChangeHandler,
        tempCheckboxInput,
        chkoptionDone,
        enableDomainInputHandler,
        domainDataListingLength
      );
    allInputs[el.category].push(
      <Box
        key={el.name}
        onDragStart={(e) => onDragStart(e, el.id, el.category)}
        draggable={el.category !== DROPPED}
        className={el.category}
        id={el.category}
      >
        {el.category === DROPPED ? (
          <Box className={classes.droppableInputElements} marginBottom={2}>
            {draggedElement}
          </Box>
        ) : (
          <Box draggable className={classes.dragInputElements}>
            {droppedElement}
          </Box>
        )}{" "}
      </Box>
    );
  });

  return (
    <>
      <MsgDialog
        open={erroropen}
        handleClose={handleErrorClose}
        type={"error"}
        title={"Below fields are mandatory!"}
        bodycontent={erroritems}
      />
      <AlertDialog
        open={openDomainValues}
        handleClose={handleAddDomainClose}
        title={"Add Domain Values"}
        bodycontent={
          <DomainValues
            domainDataListing={domainDataListing}
            addDomainValues={addDomainValues}
            handleDomainChange={handleDomainChange}
            selectedDomain={selectedDomain}
            selectedDomainDataByDomainId={selectedDomainDataByDomainId}
          />
        }
      />
      <Box sx={{ width: "100%" }}>
        <Box sx={{ p: 0, mb: 3 }}>
          <Box sx={{ pt: 4, px: 3 }}>
            <Breadcrumbs aria-label="breadcrumb">
              <Link underline="none" to="/home" className={classes.breadCrumb}>
                {t("form_builder.add_new_form_home.home")}
              </Link>
              <Link
                underline="none"
                to="/formbuilder"
                className={classes.breadCrumb}
              >
                {t("form_builder.add_new_form_home.form_builder")}
              </Link>
              <Link underline="none" className={classes.activeBreadCrumb}>
                {t("form_builder.add_new_form_home.new_form")}
              </Link>
            </Breadcrumbs>
          </Box>
          <Box sx={{ width: "100%", px: 3, py: 1 }} className="mainheading">
            <Typography variant="h1" gutterBottom>
              Add Form
            </Typography>
          </Box>
        </Box>
        <Box sx={{ mx: 3 }}>
          <Box className={classes.btnSavecontainer}>
            <Box display="flex">
              <Paper elevation={0} sx={{ width: "300px" }}>
                <TextField
                  className="w-100"
                  id="fName"
                  size="small"
                  placeholder="Enter Formname"
                  onChange={(e) => handleFormLabel(e)}
                />
              </Paper>
              <Paper sx={{ marginLeft: "16px", width: "300px" }} elevation={0}>
                <TextField
                  className="w-100"
                  size="small"
                  placeholder="Enter form description"
                  id="description"
                  onChange={(e) => handleFormLabel(e)}
                />
              </Paper>
            </Box>
            <Button
              onClick={btnSubmitHandler}
              variant="contained"
              sx={{ minWidth: "100px" }}
              size="small"
              className="btn-primary"
            >
              {t("save")}
            </Button>
          </Box>
          <Grid container className={classes.formContainer} spacing={3}>
            <Grid
              onDragOver={(e) => onDragOver(e)}
              onDrop={(e) => onDrop(e, DROPPED)}
              item
              xs={8}
              className={classes.droppedElements}
              id="droppedElements"
            >
              <Paper
                elevation={0}
                className="boxRounded2"
                sx={{ height: "100%" }}
              >
                <Box className="blockHeading2">
                  <Typography variant="h3" gutterBottom>
                    Create Form
                  </Typography>
                </Box>
                {chkdoneerror && (
                  <Alert
                    severity="error"
                    action={
                      <IconButton
                        aria-label="close"
                        color="inherit"
                        size="small"
                        onClick={() => {
                          setChkDoneError(false);
                        }}
                      >
                        <CloseIcon fontSize="inherit" />
                      </IconButton>
                    }
                    sx={{ mb: 2 }}
                  >
                    Error! Please enter checkbox label and its attributes before
                    marking it done!
                  </Alert>
                )}
                {chkoptionDone && (
                  <Alert
                    severity="success"
                    action={
                      <IconButton
                        aria-label="close"
                        color="inherit"
                        size="small"
                        onClick={() => {
                          setChkOptionDone(false);
                        }}
                      >
                        <CloseIcon fontSize="inherit" />
                      </IconButton>
                    }
                    sx={{ mb: 2 }}
                  >
                    Success! Checkbox options added successfully!
                  </Alert>
                )}
                {allInputs.droppedElements}
              </Paper>
            </Grid>
            <Grid item xs={4} className={classes.inputSidebarContainer}>
              <Paper
                elevation={0}
                sx={{ height: "100%" }}
                className="boxRounded2"
              >
                <Box className="blockHeading2">
                  <Typography variant="h3" gutterBottom>
                    {t("form_builder.add_new_form_home.form_elements")}
                  </Typography>
                </Box>
                <Box sx={{ height: "100%" }}>
                  {/* <Box padding={3} className={classes.formElementContainer}>
                      <Typography className={classes.formElementText}>
                        {t('form_builder.add_new_form_home.form_elements')}
                      </Typography>
                    </Box> */}
                  <Box
                    className="draggedElements"
                    id="draggedElements"
                    onDragOver={(e) => onDragOver(e)}
                    onDrop={(e) => {
                      onDrop(e, DRAGGED);
                    }}
                  >
                    {allInputs.draggedElements}
                  </Box>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
};

export default AddForm;
