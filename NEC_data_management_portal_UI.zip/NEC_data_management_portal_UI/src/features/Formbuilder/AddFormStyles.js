import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    dragInputElements: {
        display:'flex', 
        justifyContent: 'space-between', 
        height:'50px', 
        background: 'transparent',
        alignItems: 'center',
        cursor: 'pointer',
        width: '100%',

        '& p':{
            fontSize: '16px',
            fontFamily: 'Roboto',
        }
    },
    formContainer: {
        border: 'solid 0px #FFFFFF80',
        borderRadius: '6px'
    },
    droppableElementContainer: {
        padding: '32px'
    },
    droppableInputElements:{
        position: 'relative',
        background:'#F6F6F7',
        padding:'20px',
        border: '0px solid #E3EAF1',
        borderRadius: 15,
        background: "linear-gradient(264deg, #F6F6F7 40.34%, #FCEEF1 104.2%)",
        '& .MuiFormControl-root':{
            width: '80%'
        },
        '& input':{
            border: '1px solid #E3EAF1',
            background: '#FCFDFF !important',
            color: '#000 !important',
            height: '40px',
            padding: '7px 16px',
            boxSizing: 'border-box',
            width: '100%'
        }
    },
    inputSidebarContainer: {
        borderTopRightRadius: '6px',
        borderBottomRightRadius: '6px',
        borderLeft: 'solid 1px #FFFFFF80',
    },
    formElementContainer:{
        textAlign:'center',
        padding: '16px',
        borderBottom: 'solid 1px #FFFFFF80'
    },
    formElementText:{
        fontSize:'16px',
    },
    btnSavecontainer:{
        display:'flex',
        justifyContent:'space-between',
        paddingBottom:'16px',
        alignItems:'center',

        '& input':{
            border: '0px solid rgba(0, 0, 0, 0.05)',
            background: 'transparent',
            color: '#000 !important',
            height: '40px',
            padding: '8.5px 16px',
            boxSizing: 'border-box'
        },
    },
    breadCrumb:{
        textDecoration:"none",
        color:'#19223B !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textTransform: 'uppercase',
    },
    activeBreadCrumb:{
        color:'#9196A7 !important',
        fontSize:'0.75rem !important',
        cursor: 'pointer',
        textDecoration: 'none',
        textTransform: 'uppercase',
    },
    droppedElements: {
        padding:'0px',

        '& label':{
            marginBottom: 0,
            color: '#19223B',
            padding: 0,
        },
        '& p':{
            fontFamily: 'Inter',
            fontSize: 14,
            lineHeight: 'normal',
            boxSizing: 'border-box',
            marginTop:'0',
            marginBottom:'0',
        }
    },
    btnSave: {
        minWidth: '100px !important',
        border: '0px !important',
        background:'#D2334C !important',
        color: '#FFF !important',
        '&:hover':{
            border: '0px !important',
            background:'#D2334C !important'
        }
    }
});

export { useStyles };