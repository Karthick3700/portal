import {
  Box,
  IconButton,
  InputLabel,
  ListItem,
  ListItemText,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  FormControl,
  MenuItem,
} from "@mui/material";
import React from "react";
import { useStyles } from "./DomainValuesStyle";
import dayjs from "dayjs";
import NoteAddIcon from "@mui/icons-material/NoteAdd";
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';

const DomainValues = ({
  addDomainValues,
  domainDataListing,
  handleDomainChange,
  selectedDomain,
  selectedDomainDataByDomainId
}) => {
  const classes = useStyles();
  const columns = [];

  const tableHeader = selectedDomain?.formFields?.map((arr, i) => {
    columns.push({
      field_label: arr?.field_label,
      type: arr.field_type,
      field_id: arr.field_id,
    });
    return (
      <Box key={arr?.field_id} align="center" className='domainSelect'>
        <Box display="flex" alignItems="center">
          <Box>{arr?.field_label}</Box>
          <Box>
            <IconButton onClick={(e) => addDomainValues(e, arr?.field_label)} sx={{ padding: '0 0 0 10px'}}>
              <AddCircleOutlineIcon />
            </IconButton>
          </Box>
        </Box>
      </Box>
    );
  });

  const menuItems =
    domainDataListing &&
    domainDataListing?.length > 0 &&
    domainDataListing?.map((domainV) => {
      return <MenuItem value={domainV?.form_id} onClick={() => handleDomainChange(domainV)}>{domainV?.form_name}</MenuItem>;
    });

  const tablerows =
    selectedDomainDataByDomainId &&
    selectedDomainDataByDomainId?.length > 0 &&
    selectedDomainDataByDomainId.map((row) => {
      return (
        <TableCell key={row.form_response_id}>
          {columns?.map((colname) => {
            return (
              <TableCell align="center">
                {colname?.type === "date" && row[colname?.field_label] ? (
                  dayjs(row[colname?.field_label]).format("DD/MM/YYYY")
                ) : colname?.type === "checkbox" &&
                  row[colname?.field_label] ? (
                  <Box>
                    <ListItem>
                      <ListItemText
                        primary={`value: ${row[colname?.field_label]?.value}`}
                      />
                      <ListItemText
                        primary={`Is Required: ${row[colname?.field_label]?.is_required}`}
                      />
                    </ListItem>
                  </Box>
                ) : (
                  row[colname?.field_label]
                )}
              </TableCell>
            );
          })}
        </TableCell>
      );
    });

  return (
    <>
      <Box sx={{p:2}}>
        <Box>
          <FormControl fullWidth size="small">
            {/* <InputLabel>Domain Values</InputLabel> */}
            <Select
              value={selectedDomain?.form_id || ""}
            // onChange={handleDomainChange}
            >
              {!selectedDomain?.form_id &&
                <MenuItem value="">
                  <em>Please select domain value</em>
                </MenuItem>
              }
              {menuItems}
            </Select>
          </FormControl>
        </Box>
        <TableContainer component={Box}>
          <Table
            // sx={{ minWidth: 700 }}
            aria-label="customized table"
            className={classes.borderedCell}
          >
            <TableHead className={classes.tableHeading}>
              <TableRow sticky>{tableHeader}</TableRow>
            </TableHead>
            <TableBody>{tablerows}</TableBody>
          </Table>
        </TableContainer>
      </Box>
    </>
  );
};

export default DomainValues;
