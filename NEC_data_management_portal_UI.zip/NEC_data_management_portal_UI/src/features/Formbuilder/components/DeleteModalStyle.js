import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    btnConfirm: {
        border: '0px !important',
        background:'#D2334C !important',
        color: '#FFF !important',
        '&:hover':{
            border: '0px !important',
            background:'#D2334C !important'
        }
    },
    btnCancel: {
        border:'solid 1px #3C3C3C !important',
        color: '#3C3C3C !important',
        '&:hover':{
            border: 'solid 1px #3C3C3C !important',
            background:'transparent !important'
        }
    },
    dialogTitle: {
        fontSize: '18px !important',
        padding: '8px !important'
    },
    dialogContainer: {
        padding: '3rem',
        minHeight: '100px'
    }
});

export { useStyles };