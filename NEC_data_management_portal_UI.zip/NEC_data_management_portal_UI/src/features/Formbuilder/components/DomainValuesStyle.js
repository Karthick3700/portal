import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
   gridItem: {
    background : '#FFFFFF',
    minHeight:'100vh',
    borderRadius:'10px'
   },
   existingFormContainer: {
     display:'flex',
     alignItems: 'center',
     background:'#E51448',
     height:'60px',
     paddingLeft:'28px',
     borderTopLeftRadius:'10px',
   },
   existingFormText: {
     color:'#ffffff',
     fontSize:'18px',
     fontFamily:'Roboto'
   },
   formListContainer:{
    padding: '0px',
    background:'#F7FAFC',
    borderBottom:'1px solid #E3EAF1',
    '&:nth-child(odd)':{
      background:'#fff',
    }
   },
   formListElements: {
    color: '#1F1F1F',
    background:'transparent',
    padding:'16px',
    cursor: 'pointer',
    textAlign: 'left',
    '& p':{
      fontSize: '0.875rem',
    },
   },
   formListActiveElements: {
    color: '#1F1F1F',
    background:'transparent',
    padding:'16px',
    cursor: 'pointer',
    textAlign: 'left',
    '& p':{
      fontSize: '0.875rem',
    },
   },
   dataSearchText: {
    color:'#FFFFFF',
    fontSize:'18px',
    fontFamily:'Roboto',
    textTransform: 'capitalize'
   },
   dataSearchContainer: {
    display:'flex',
    flexDirection: 'row',
    gap: '8px',
   },
   exportMainContainer: {
    padding:'16px', 
    background:'#FFFF',
    marginTop:'16px',
    marginLeft:'16px',
    borderRadius:'8px',
    boxShadow: '0 0 10px #c9c9c9',
   },
   searchTableContainer: {
    padding: '0',
   },
   btn: {
      background:'#e51448 !important' , 
      color: '#fff !important',
      border:'0px !important',
      cursor:'pointer !important',
      marginLeft: '16px !important',
      fontSize: '0.75rem !important',
      padding: '8px 20px !important',
      borderRadius: '6px !important',
      boxSizing: 'border-box',
      '&:hover': {
        background: '#e51448 !important',
        color: '#fff !important',
      },
   },
   divider:{
    borderBottom:'solid 1px #DBDBDB',
    marginBottom:'16px',
    padding:'16px'
  },
  borderedCell: {
    '&.MuiTable-root .MuiTableCell-root': {
      fontFamily: 'Inter',
      fontSize:'0.875rem',
      padding: '0px 20px',
      borderBottom: '1px solid #E3EAF1',
      textTransform: 'capitalize',
      textAlign: 'left',
    },
    '&.MuiTable-root td':{
      color:'#1F1F1F',
      fontSize:'0.875rem',
      padding: '13px 20px',
      fontFamily: 'Inter',
      height: '60px'
    }
  },
  tableHeading: {
    '&.MuiTableHead-root':{
      background:'#F7FAFC',
      fontSize:'0.875rem',
      padding: '13px 20px',
      fontFamily: 'Inter',
      border: '1px solid #e3eaf1'
    },
    '&.MuiTableHead-root th':{
      color:'#1F1F1F',
      fontSize:'0.875rem',
      padding: '13px 20px',
      fontFamily: 'Inter',
    },
  },
  searchBox: {
    backgroundColor: '#FCFDFF',
    border: '1px solid #cbcbcb',
    borderRadius: '10px !important',
    boxShadow: '0 0 10px #c9c9c9 !important'
  },
  searchInput: {
    fontSize:'14px',
  },
  breadCrumb:{
  textDecoration:"none",
  color:'#19223B !important',
  fontSize:'0.75rem !important',
  cursor: 'pointer',
  textTransform: 'uppercase',
},
activeBreadCrumb:{
  color:'#9196A7 !important',
  fontSize:'0.75rem !important',
  cursor: 'pointer',
  textDecoration: 'none',
  textTransform: 'uppercase',
}
});

export { useStyles };