import React from "react";
import { Box, Grid, Paper, SvgIcon, Typography } from "@mui/material";
import { ReactComponent as SearchWhite } from "../../../assets/searchwhite.svg";
import { ReactComponent as PlusIcon } from "../../../assets/pluslarge.svg";
import { ReactComponent as DashboardIcon } from "../../../assets/createdashboard.svg";
import { ReactComponent as ExcelIcon } from "../../../assets/exportinexcel.svg";
import { ReactComponent as AssignIcon } from "../../../assets/assign.svg";
import { ReactComponent as PluswithCircle } from "../../../assets/pluswithcircle.svg";
import { ReactComponent as EditIcon } from "../../../assets/edit.svg";
import { ReactComponent as EyeIcon } from "../../../assets/eye.svg";
import { ReactComponent as DeleteIcon } from "../../../assets/delete.svg";
import { Link, Navigate, useNavigate } from "react-router-dom";

const FormListing = ({ formname, description, form_id, handleDeleteClick }) => {
  const navigate = useNavigate();
  const handleEditClick = (form_id) => {
    navigate(`editform/${form_id}`);
    navigate(0);
  };

  const handleViewClick = (form_id) => {
    navigate(`viewform/${form_id}`);
    navigate(0);
  };

  return (
    <>
      <Grid item xs={12} md={6} lg={4} xl={3}>
        <Paper className='boxRounded2 formbuilder cursor-pointer' elevation={0}>
          <Box className='blockHeading'>
            <Typography variant="h3">
              {`${formname} `}
              {/* {`${formname} : description`} */}
            </Typography>
          </Box>
          <Box className='blocContent' sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: 'column' }}>
            <Typography sx={{ mb: 2 }} className="frmDesc">
              {`${description}`}
            </Typography>

            <Box className="whiteformbox"
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                alignItems: 'center',
                marginTop: '18px',
              }}
            >
              <ul className="actionsicons"
                style={{
                  alignSelf: 'flex-end',
                  display: 'flex'
                }}
              >
                {/* <li>
                  <a href="#" className="">
                    <SvgIcon
                      sx={{
                        height: "20px",
                        width: "20px",
                      }}
                      component={SearchWhite}
                      inheritViewBox
                    />
                  </a>
                </li>
                <li>
                  <a href="#" className="">
                    <SvgIcon
                      sx={{
                        height: "15px",
                        width: "23px",
                      }}
                      component={DashboardIcon}
                      inheritViewBox
                    />
                  </a>
                </li>
                <li>
                  <a href="#" className="">
                    <SvgIcon
                      sx={{
                        width: "17px",
                        height: "21px",
                      }}
                      component={ExcelIcon}
                      inheritViewBox
                    />
                  </a>
                </li>
                <li>
                  <a href="#" className="">
                    <SvgIcon
                      sx={{
                        width: "23px",
                        height: "15px",
                      }}
                      component={AssignIcon}
                      inheritViewBox
                    />
                  </a>
                </li> */}
                {/* <li>
                  <a href="#" className="">
                    <SvgIcon
                      sx={{
                        width: "20px",
                        height: "20px",
                      }}
                      component={PluswithCircle}
                      inheritViewBox
                    />
                  </a>
                </li> */}
                <li>
                  <Link onClick={() => handleEditClick(form_id)}>
                    <SvgIcon
                      sx={{
                        width: "23px",
                        height: "15px",
                      }}
                      component={EditIcon}
                      inheritViewBox
                    />
                  </Link>
                </li>
                <li>
                  <Link onClick={() => handleViewClick(form_id)}>
                    <SvgIcon
                      sx={{
                        width: "23px",
                        height: "15px",
                      }}
                      component={EyeIcon}
                      inheritViewBox
                    />
                  </Link>
                </li>
                <li>
                  <Link onClick={(e) => handleDeleteClick(e, form_id)} className="">
                    <SvgIcon
                      sx={{
                        width: "19px",
                        height: "20px",
                      }}
                      component={DeleteIcon}
                      inheritViewBox
                    />
                  </Link>
                </li>
              </ul>
            </Box>
          </Box>
        </Paper>
      </Grid>
    </>
  );
};

export default FormListing;
