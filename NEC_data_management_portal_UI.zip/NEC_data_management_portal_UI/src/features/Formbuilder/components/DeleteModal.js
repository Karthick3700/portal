import React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';
import { useStyles } from './DeleteModalStyle';
import { Box } from '@mui/material';
import deleteIcon from "../../../assets/img/delete-icon.svg";

const DeleteModal=({
    confirmdelete,
    handleCloseDelete,
    handleDeleteForm
})=> {

  const classes = useStyles();  

  return (
    <>
      <Dialog
        onClose={handleCloseDelete}
        aria-labelledby="customized-dialog-title"
        open={confirmdelete}
        className='customDialog'
      >
        <IconButton
          aria-label="close"
          onClick={handleCloseDelete}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
          className='dialogClose'
        >
          <CloseIcon />
        </IconButton>
        <DialogContent className={classes.dialogContainer} dividers>
          <Box className='d-flex flex-column'>
            <img src={deleteIcon} className='dialogIcon' />
            <Typography gutterBottom className='msgText'>
              Are you sure you want to delete this form?
            </Typography>
          </Box>
          <Box className='dialogButtons'>
            <Button 
              variant='outlined' 
              className='btn-outline large' 
              onClick={handleCloseDelete}
            >
              No
            </Button>
            <Button 
              variant='outlined' 
              className='btn-primary large' 
              onClick={handleDeleteForm}
            >
              Yes
            </Button>
        </Box>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default DeleteModal;