import React, { useCallback, useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useStyles } from './styles';
import { styled } from '@mui/material/styles';
import {
  Box,
  Card,
  Grid,
  Breadcrumbs,
  Link,
  Typography,
  TextField,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import HomeIcon from '@mui/icons-material/Home';
import { fetchdashboardList, fetchdashboardStreamsList, resetStreamData }
  from '../../redux/dashboard/dashboardSlice';
import { useTranslation } from 'react-i18next';
import {
  fetchservicerequestCreate,
  fetchservicerequestUpload,
  fetchservicerequestUploadSuccess,
  fetchservicerequestUploadFailure,
  fetchExcelExport,
  fetchExcelExportSuccess,
} from '../../redux/servicerequest/servicerequestSlice';
import * as XLSX from 'xlsx';


const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const RequestNewDashboard = () => {
  const [lang, setLang] = React.useState('');
  const classes = useStyles();
  const [file1, setFile1] = useState(null); // Add this state
  const [file2, setFile2] = useState(null);
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  const language = useSelector(state => state.language);
  const { data, fetchStatus, fetchStreamStatus, streamData } = useSelector(state => state.dashboardList);
  const uploadStatus = useSelector(state => state.servicerequest.fetchUploadStatus);
  const uploadResponse = useSelector(state => state.servicerequest.data);
  const [streams, setStreams] = useState([]);
  const [dashboardName, setDashboardName] = useState('');
  const [businessDomain, setBusinessDomain] = useState('');
  const [priority, setPriority] = useState('');
  const [purpose, setPurpose] = useState('');
  const [isSuccessDialogOpen, setIsSuccessDialogOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [showReasonField, setShowReasonField] = useState(false);
  const [comment, setComment] = useState('');
  const [isErrorDialogOpen, setIsErrorDialogOpen] = useState(false);

  const purposeData = [
    { key: 1, value: 'Daily operation' },
    { key: 2, value: 'Reconciliation' },
    { key: 3, value: 'Monitoring' },
    { key: 4, value: 'Others' }
  ]

  const priorityData = [
    { key: 1, value: 'High' },
    { key: 2, value: 'Medium' },
    { key: 3, value: 'Low' }
  ]

  const handlePurposeChange = (event) => {
    setPurpose(event.target.value);
    setShowReasonField(event.target.value === 'Others');
  };

  const handleCommentChange = (event) => {
    setComment(event.target.value);
  };

  useEffect(() => {
    i18n.changeLanguage(language);

    if (data && data.output) {
      setStreams(data.output);
    }
  }, [i18n, language, data]);

  useEffect(() => {
    dispatch(fetchdashboardList());
  }, []);

  const closeSuccessDialog = () => {
    if (uploadStatus.status) {
      setIsSuccessDialogOpen(false);
    }
  };

// Inside the useEffect for uploadStatus
useEffect(() => {
  if (uploadStatus.status && !uploadStatus.isLoading && dashboardName !== '') {
    const streamId = streams.find((stream) => stream.stream_name === businessDomain)?.stream_id;
    const formattedPurpose = purpose.toLowerCase() === 'daily operation' ? 'daily_operation' : purpose.toLowerCase();
    const createPayload = {
      request_type: 'new_dashboard',
      business_domain_id: streamId,
      business_domain_name: businessDomain,
      dashboard_id: streamId,
      dashboard_name: dashboardName,
      priority: priority.toLowerCase(),
      purpose: formattedPurpose,
      comment: comment,
      file_id: 1
    };

    if (formattedPurpose === 'others') {
      createPayload.reason = reason;
    }

    if (dashboardName !== "" && comment && formattedPurpose && businessDomain) {
      dispatch(fetchservicerequestCreate(createPayload));
      setIsSuccessDialogOpen(true);
    } 
    else {
      setIsErrorDialogOpen(true); // Set isErrorDialogOpen to true if file1 is not provided
    }
    
  }
}, [uploadStatus]);



  const handleDownload = () => {
    dispatch(fetchExcelExport())
  };


  const handleFileUpload = (event) => {
    const uploadedFile = event.target.files[0];
    setFile1(uploadedFile);
  };

  const handleFileUploadSample = (event) => {
    const uploadedFile = event.target.files[0];
    setFile2(uploadedFile);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();

    if (file1) {
      const formData = new FormData();
      formData.append('business_template', file1);
      if (file2) {
        formData.append('sample_template', file2);
      }
      dispatch(fetchservicerequestUpload({
        'business_template': file1,
        'sample_template': file2
      })) 
    }
    else {
      setIsErrorDialogOpen(true); // Set isErrorDialogOpen to true if file1 is not provided
    }
  };

  const handleBusinessDomainChange = (event) => {
    setBusinessDomain(event.target.value);
  };

  const handlePriorityChange = (event) => {
    setPriority(event.target.value);
  };

  const closeErrorDialog = () => {
    setIsErrorDialogOpen(false);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ p: 0, mb: 3 }}>
        <Box sx={{ pt: 4, px: 3 }}>
          <Breadcrumbs aria-label="breadcrumb">
            <Link
              underline="none"
              to='/home'
              className={classes.breadCrumb}
            >
              Home
            </Link>
            <Link underline="none" to='/request-dashboard' className={classes.activeBreadCrumb}>Request New Dashboard</Link>
          </Breadcrumbs>
        </Box>
        <Box sx={{ width: '100%', px: 3, py: 1 }} className={classes.mainheading}>
          <Typography variant="h1" gutterBottom>
            New Dashboard
          </Typography>
        </Box>
      </Box>
      <Box sx={{ px: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} lg={8}>
            <Card className="boxRounded2">
              <Box className="blockHeading2">
                <Typography variant="h3" gutterBottom>
                  New Dashboard
                </Typography>
              </Box>
              <Box sx={{ width: '100%', my: 3 }} component="form">
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Download Sample File
                      </label>
                      <Box>
                        <Link variant="text" className="downloadLink" onClick={handleDownload}>
                          <CloudDownloadIcon className="smallicon" />
                          download business info template
                        </Link>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Business Info Template <span className="required">*</span> <p className='text-small'>( Excel, Word, Ppt, PNG, JPEG, PDF ) </p>
                      </label>
                      <Box>
                        <Button
                          className='btn-outline upload-file'
                          component="label"
                          variant="contained"
                          startIcon={<CloudUploadIcon sx={{ opacity: 0.6 }} />}
                        >
                          Upload file
                          <input
                            type="file"
                            style={{ display: 'none' }}
                            onChange={handleFileUpload}
                          />

                          <VisuallyHiddenInput type="file" sx={{ opacity: 0.6 }} />
                        </Button>
                      </Box>
                      {file1 && (
                        <Typography variant="body1" sx={{ mt: 1 }}>
                          File: {file1.name}
                        </Typography>
                      )}
                    </Box>
                  </Grid>

                  <Grid item xs={12} md={4}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Sample Design <p className='text-small'>( Excel, Word, Ppt, PNG, JPEG, PDF ) </p>
                      </label>
                      <Box>
                        <Button
                          className='btn-outline upload-file'
                          component="label"
                          variant="contained"
                          startIcon={<CloudUploadIcon sx={{ opacity: 0.6 }} />}
                        >
                          Upload file
                          <input
                            type="file"
                            style={{ display: 'none' }}
                            onChange={handleFileUploadSample}
                          />
                        </Button>
                        {file2 && (
                          <Typography variant="body1" sx={{ mt: 1 }}>
                            File: {file2.name}
                          </Typography>
                        )}
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Business Domain <span className="required">*</span>
                      </label>
                      <Box className='custom-select'>
                        <FormControl variant="standard" sx={{ width: '100%' }}>
                          <Select
                            value={businessDomain}
                            onChange={handleBusinessDomainChange}
                            label="Select"
                            displayEmpty

                          >
                            <MenuItem value="" disabled>
                              Please Select
                            </MenuItem>
                            {streams?.map((stream) => (
                              <MenuItem key={stream.stream_id} value={stream.stream_name}>
                                {stream.stream_name}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Dashboard Name <span className="required">*</span>
                      </label>
                      <TextField
                        sx={{ width: '100%' }}
                        size="small"
                        type="text"
                        placeholder="Enter dashboard name"
                        required
                        value={dashboardName}
                        onChange={(event) => setDashboardName(event.target.value)}
                      />
                    </Box>
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Priority <span className="required">*</span>
                      </label>
                      <Box className='custom-select'>
                        <FormControl variant="standard" sx={{ width: '100%' }}>
                          <Select
                            value={priority}
                            onChange={handlePriorityChange}
                            label="Select"
                            displayEmpty
                          >
                            <MenuItem value="">
                              Please Select
                            </MenuItem>
                            {priorityData.map((item) => (
                              <MenuItem key={item.key} value={item.value}>
                                {item.value}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Purpose <span className="required">*</span>
                      </label>
                      <Box className='custom-select'>
                        <FormControl variant="standard" sx={{ width: '100%' }}>
                          <Select
                            label="Select"
                            displayEmpty
                            value={purpose}
                            onChange={handlePurposeChange}
                          >
                            <MenuItem value="">
                              Please Select
                            </MenuItem>
                            {purposeData.map((item) => (
                              <MenuItem key={item.key} value={item.value}>
                                {item.value}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>
                  {showReasonField && (
                    <Grid item xs={12} md={6}>
                      <Box className="form-group d-flex flex-column w-100">
                        <label>
                          Reason <span className="required">*</span>
                        </label>
                        <TextField
                          sx={{ width: '100%' }}
                          size="small"
                          type="text"
                          placeholder="Enter reason"
                          value={reason}
                          onChange={(event) => setReason(event.target.value)}
                        />
                      </Box>
                    </Grid>
                  )}

                  <Grid item xs={12}>
                    <Box className="form-group d-flex flex-column w-100">
                      <label>
                        Comments
                      </label>
                      <TextField
                        sx={{ width: '100%' }}
                        multiline
                        rows={4}
                        size=""
                        type="text"
                        placeholder="Enter here..."
                        className="input-filled textarea"
                        value={comment}
                        onChange={handleCommentChange}
                      />
                    </Box>
                  </Grid>
                </Grid>
                <Box sx={{ my: 3 }}>
                  <Button variant="contained" className="btn-primary" onClick={handleFormSubmit}>
                    Request
                  </Button>
                </Box>
              </Box>
            </Card>
          </Grid>
        </Grid>
      </Box>

      <Dialog open={isSuccessDialogOpen} onClose={closeSuccessDialog}>
        <DialogTitle>Request Created Successfully</DialogTitle>
        <DialogContent>
          <Typography variant="body1">Your request has been created successfully.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeSuccessDialog} variant="contained" autoFocus>
            OK
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={isErrorDialogOpen} onClose={closeErrorDialog}>
        <DialogTitle>Required Fields Missing</DialogTitle>
        <DialogContent>
          <Typography variant="body1">Please fill all the required fields.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeErrorDialog} variant="contained" autoFocus>
            OK
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default RequestNewDashboard;
