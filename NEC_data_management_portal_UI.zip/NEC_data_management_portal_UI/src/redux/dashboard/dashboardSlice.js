import { createSlice } from "@reduxjs/toolkit";

const dashboardInitialState = {
  data: [],
  fetchStatus: {
    isLoading: false,
    status: false,
    errors: null
  },
  fetchStreamStatus: {
    isLoading: false,
    status: false,
    errors: null,
  },
  fetchReportStatus: {
    isLoading: false,
    status: false,
    errors: null,
  },
  fetchItemsPerReportStatus: {
    isLoading: false,
    status: false,
    errors: null,
  },
  
  fetchReportinPdfStatus: {
    isLoading: false,
    status: false,
    errors: null,
  },
  
  assignStatus: {
    isLoading: false,
    errors: null,
  },
  bearerToken: "",
  lastAssignedUser: null,
  sharingAlterStatus: "",
  sharingAlterMessage: ""
};

export const dashboardSlice = createSlice({
  name: "dashboardList",
  initialState: dashboardInitialState,
  reducers: {
    fetchdashboardList: (state) => {
      state.fetchStatus.isLoading = true;
      state.fetchStatus.errors = null;
    },
    fetchdashboardListSuccess: (state, action) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.status = true;
      state.data = action.payload;
    },
    fetchdashboardListFailure: (state, { payload: error }) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.errors = error;
    },
    fetchdashboardStreamsList: (state) => {
      state.fetchStreamStatus.isLoading = true;
      state.fetchStreamStatus.errors = null;
    },
    fetchdashboardStreamsListSuccess: (state, action) => {
      state.fetchStreamStatus.isLoading = false;
      state.fetchStreamStatus.status = true;
      state.streamData = action.payload;
    },
    fetchdashboardStreamsListFailure: (state, { payload: error }) => {
      state.fetchStreamStatus.isLoading = false;
      state.fetchStreamStatus.errors = error;
    },
    //
    fetchreportList: (state) => {
      state.fetchReportStatus.isLoading = true;
      state.fetchReportStatus.errors = null;
    },
    fetchreportListSuccess: (state, action) => {
      state.fetchReportStatus.isLoading = false;
      state.fetchReportStatus.status = true;
      state.reportsData = action.payload;
    },
    fetchreportListFailure: (state, { payload: error }) => {
      state.fetchReportStatus.isLoading = false;
      state.fetchReportStatus.errors = error;
    },
    fetchItemsPerReportList: (state) => {
      state.fetchItemsPerReportStatus.isLoading = true;
      state.fetchItemsPerReportStatus.errors = null;
    },
    fetchItemsPerReportListSuccess: (state, action) => {
      state.fetchItemsPerReportStatus.isLoading = false;
      state.fetchItemsPerReportStatus.status = true;
      state.itemsPerReportData = action.payload;
    },
    fetchItemsPerReportListFailure: (state, { payload: error }) => {
      state.fetchItemsPerReportStatus.isLoading = false;
      state.fetchItemsPerReportStatus.errors = error;
    },
    fetchReportinPdf: (state) => {
      state.fetchReportinPdfStatus.isLoading = true;
      state.fetchReportinPdfStatus.errors = null;
    },
    fetchReportinPdfSuccess: (state, action) => {
      state.fetchReportinPdfStatus.isLoading = false;
      state.fetchReportinPdfStatus.status = true;
      state.reportDatainPdf = action.payload;
    },
    fetchReportinPdfFailure: (state, { payload: error }) => {
      state.fetchReportinPdfStatus.isLoading = false;
      state.fetchReportinPdfStatus.errors = error;
    },
    //
    resetDashboard: () => dashboardInitialState,
    resetStreamData: (state) => {
        state.streamData = null;
      }
  },
});

export const {
    fetchdashboardList,
    fetchdashboardListSuccess,
    fetchdashboardListFailure,
    fetchdashboardStreamsList,
    fetchdashboardStreamsListSuccess,
    fetchdashboardStreamsListFailure,
    resetDashboard,
    resetStreamData,
    fetchreportList,
    fetchreportListSuccess,
    fetchreportListFailure,
    fetchItemsPerReportListFailure,
    fetchItemsPerReportListSuccess,
    fetchItemsPerReportList,
    fetchReportinPdf,
    fetchReportinPdfSuccess,
    fetchReportinPdfFailure
} = dashboardSlice.actions;

export default dashboardSlice.reducer;