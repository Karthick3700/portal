import { call, put, takeEvery } from 'redux-saga/effects';
import {
    fetchdashboardList,
    fetchdashboardListSuccess,
    fetchdashboardListFailure,
    fetchdashboardStreamsList,
    fetchdashboardStreamsListSuccess,
    fetchdashboardStreamsListFailure,
    fetchreportListSuccess,
    fetchreportListFailure,
    fetchItemsPerReportListFailure,
    fetchItemsPerReportListSuccess,
    fetchReportinPdfSuccess,
    fetchReportinPdfFailure
} from './dashboardSlice';
import baseApi from "../../app/api";
import axios from 'axios'

export function* fetchDashbaordStreamsSaga(action) {
  try {
    const response = yield call(() => baseApi.get("/dashboards/all-stream/user"));
    yield put(fetchdashboardListSuccess(response.data));
  } catch (error) {
    yield put(fetchdashboardListFailure(error));
  }
}


export function* fetchDashboardStreamsDataSaga(action) {
    try {
      const response = yield call(() =>
        baseApi.post("/dashboards/all-app/stream", action.payload)
      );
 
      yield put(fetchdashboardStreamsListSuccess(response.data));
    } catch (error) {
      yield put(fetchdashboardStreamsListFailure(error.response.data.meta.message));
    }
  }


  export function* fetchReportsDataSaga(action) {
    try {
      const response = yield call(() =>
        baseApi.get("/reports/business-domain")
      );
      yield put(fetchreportListSuccess(response.data));
    } catch (error) {
      yield put(fetchreportListFailure(error.response.data.meta.message));
    }
  }
  
  export function* fetchItemsPerReportDataSaga(action) {
    try {
      const { business_domain } = action.payload;
      const response = yield call(() =>
        baseApi.get(`reports?business_domain=${business_domain}`)
      );
      yield put(fetchItemsPerReportListSuccess(response.data)); 
    } catch (error) {
      yield put(fetchItemsPerReportListFailure(error.message)); 
    }
  }

  export function* fetchReportinPdfSaga(action) {
    try {
      const bearerToken = sessionStorage.getItem("token");

    var config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `JWT ${bearerToken}`,
        "x-access-token": `JWT ${bearerToken}`,
      },
      responseType: "blob" // Set the response type to 'blob' for handling binary data
    };

    const response = yield call(() =>
      axios.get(`http://localhost:3005/api/v1/dynamicpdf/generate`, config)
    );


    yield put(fetchReportinPdfSuccess(response.data));

    // Extract the PDF URL from the response
    const pdfUrl = response.data.data;
    console.log('pdf Url' , pdfUrl)
    // Open the PDF URL in a new tab
    // window.open(pdfUrl, '_blank');
    } catch (error) {
      yield put(fetchReportinPdfFailure(error.response.data.meta.message));
    }
  }
  
