import { createSelector } from '@reduxjs/toolkit';

export const selectUserInfo = (state) => state.users;

export const getBearerToken = createSelector(
  selectUserInfo,
  (users) => users.bearerToken
);

export const getUserDetails = createSelector(
  selectUserInfo,
  (users) => users.data
);

export const getAllUsersLists = createSelector(
  selectUserInfo,
  (users) => users.allusers
);

export const getAllUsersLoading = createSelector(
  selectUserInfo,
  (users) => users.isAllUsersLoading
);
