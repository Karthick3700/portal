import baseApi from "../../app/api";
import { call, put } from "redux-saga/effects";
import {
    getUserSuccessInfo,
    getUserResponseInfo,
    fetchAllUsersSuccess,
    fetchAllUsersFailure,
    getAllUsersSuccess,
    getAllUsersError
} from "./slice";

// Generator function
export function* getUserSaga(action) {
    try {
        const { username, password } = action.payload;
        const response = yield call(() => baseApi.post('users/login', { email: username, password }));
        yield put(getUserSuccessInfo(response.data.data));
    } catch (error) {
        yield put(getUserResponseInfo({ type: 'error', message: error.response.data.meta.message }));
    }
}

export function* getAllUsersSaga(action) {
    try {
        const response = yield call(() => baseApi.get("users/getusers"));
        yield put(getAllUsersSuccess(response?.data?.data));
    } catch (error) {
        yield put(getAllUsersError(error));
    }
}

export function* registerUserSaga(action) {
    try {
        const { usr_email_id, usr_password, usr_first_name, usr_last_name, usr_login_id, usr_mob_code, usr_mobile_number } = action.payload;
        const response = yield call(() => baseApi.post('users/register', { usr_email_id, usr_password, usr_first_name, usr_last_name, usr_login_id, usr_mob_code, usr_mobile_number }));
        if (response && response.status === 200) {
            yield put(getUserResponseInfo({ type: 'success', message: 'Succesfully Registered!' }));
        }
    } catch (error) {
        if (error.response && error.response.data && error.response.data.meta && error.response.data.meta.message) {
            yield put(getUserResponseInfo({ type: 'error', message: error.response.data.meta.message }));
        }
    }
}

export function* forgotPwdSaga(action) {
    try {
        const { email } = action.payload;
        const response = yield call(() => baseApi.post('users/forgotpwd', { usr_email_id: email }));
        if (response && response.status === 200) {
            yield put(getUserResponseInfo({ type: 'success', message: response.data.meta.message }));
        }
    } catch (error) {
        if (error.response && error.response.data && error.response.data.meta && error.response.data.meta.message) {
            yield put(getUserResponseInfo({ type: 'error', message: error.response.data.meta.message }));
        }
    }
}

export function* resetPwdSaga(action) {
    try {
        const { token, password, confirm_password } = action.payload;
        const response = yield call(() => baseApi.post('users/resetpwd', { token, usr_password: password, usr_confirmpwd: confirm_password }));
        if (response && response.status === 200) {
            yield put(getUserResponseInfo({ type: 'success', message: response.data.meta.message }));
        }
    } catch (error) {
        if (error.response && error.response.data && error.response.data.meta && error.response.data.meta.message) {
            yield put(getUserResponseInfo({ type: 'error', message: error.response.data.meta.message }));
        }
    }
}

// get All users 
export function* fetchAllUsersDataSaga(action) {
    try {
        const response = yield call(() => baseApi.get(`users/getusers?form_id=${action.payload}`));
        yield put(fetchAllUsersSuccess(response?.data?.data));
    } catch (error) {
        yield put(fetchAllUsersFailure(error));
    }
}

export function* logoutUserSaga() {
    yield call(removeItemsFromSessionStorage);
}

function removeItemsFromSessionStorage() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('user');
}
