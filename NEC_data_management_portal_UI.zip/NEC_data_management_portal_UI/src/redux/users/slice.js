import { createSlice } from "@reduxjs/toolkit";

const usersInitialState = {
  user: {
    data: null,
    isLoading: false,
    errors: "",
    bearerToken: "",
    isAllUsersLoading: false,
    allusers: null,
    userResponseStatus: "",
    userResponseMessage: ""
  },
};

export const usersSlice = createSlice({
  name: "users",
  initialState: usersInitialState,
  reducers: {
    initUserInfo: (state) => {
      state.isLoading = true;
      state.errors = "";
    },
    initRegisterInfo: (state) => {
      state.isLoading = true;
      state.errors = "";
    },
    initForgotPassword: (state) => {
      state.isLoading = true;
      state.errors = "";
    },
    initResetPassword: (state) => {
      state.isLoading = true;
      state.errors = "";
    },
    getUserResponseInfo: (state, action) => {
      state.isLoading = false;
      state.userResponseStatus = action.payload.type;
      state.userResponseMessage = action.payload.message;
    },
    getUserSuccessInfo: (state, action) => {
      const { user, token } = action.payload;
      state.isLoading = false;
      state.data = user;
      state.bearerToken = token;
      sessionStorage.setItem("token", token);
      sessionStorage.setItem("user", JSON.stringify(user));
    },
    resetUserData: (state) => {
      state.data = null;
      state.bearerToken = "";
      state.errors = "";
      state.isLoading = false;
      state.userResponseMessage = "";
      state.userResponseStatus = "";
    },
    resetUserRegisterData: (state) => {
      state.errors = "";
      state.isLoading = false;
      state.userResponseMessage = "";
      state.userResponseStatus = "";
    },
    fetchAllUsers: (state) => {
      state.isLoading = true;
      state.errors = null;
    },
    fetchAllUsersSuccess: (state, action) => {
      state.isLoading = false;
      state.data = action?.payload;
    },
    fetchAllUsersFailure: (state, { payload: error }) => {
      state.isLoading = false;
      state.errors = error;
    },
    getAllUsers: (state, action) => {
      state.isAllUsersLoading = true;
      state.errors = "";
    },
    getAllUsersSuccess: (state, action) => {
      state.isAllUsersLoading = false;
      state.allusers = action?.payload;
    },
    getAllUsersError: (state, action) => {
      state.isAllUsersLoading = false;
      state.errors = action?.payload;
    }
  },
});

export const {
  initUserInfo,
  initRegisterInfo,
  getUserResponseInfo,
  getUserSuccessInfo,
  resetUserData,
  resetUserRegisterData,
  fetchAllUsers,
  fetchAllUsersSuccess,
  fetchAllUsersFailure,
  getAllUsers,
  getAllUsersSuccess,
  getAllUsersError,
  initForgotPassword,
  initResetPassword
} = usersSlice.actions;

export default usersSlice.reducer;
