import { createSlice } from "@reduxjs/toolkit";

const sharingListInitialState = {
  data: [],
  fetchStatus: {
    isLoading: false,
    errors: null,
  },
  assignStatus: {
    isLoading: false,
    errors: null,
  },
  bearerToken: "",
  lastAssignedUser: null,
  sharingAlterStatus: "",
  sharingAlterMessage: ""
};

export const sharingListSlice = createSlice({
  name: "sharingList",
  initialState: sharingListInitialState,
  reducers: {
    fetchSharingList: (state) => {
      state.fetchStatus.isLoading = true;
      state.fetchStatus.errors = null;
    },
    fetchSharingListSuccess: (state, action) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.status = true
      state.data = action.payload;
    },
    fetchSharingListFailure: (state, { payload: error }) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.errors = error;
    },
    assignUsertoSpace: (state, action) => {
      state.assignStatus.isLoading = true
    },
    assignUsertoSpaceSuccess: (state, action) => {
      state.assignStatus.isLoading = false;
      state.lastAssignedUser = action?.payload;
    },
    assignUsertoSpaceFailure: (state, { payload: error }) => {
      state.assignStatus.isLoading = false;
      state.assignStatus.errors = error;
    },
    //
    deleteSpace: (state, action) => {
      state.fetchStatus.isLoading = true;
      state.fetchStatus.errors = null;
    },
    deleteSpaceSuccess: (state, action) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.status = true;
      // state.data = action.payload;
    },
    deleteSpaceFailure: (state, { payload: error }) => {
      state.fetchStatus.isLoading = false;
      state.fetchStatus.errors = error;
    },
    //
    getSharingAlterInfo: (state, action) => {
      state.isLoading = false;
      state.sharingAlterStatus = action.payload.type;
      state.sharingAlterMessage = action.payload.message;
    },
    resetSharingAlterInfo: (state) => {
      state.sharingAlterStatus = '';
      state.sharingAlterMessage = '';
    }
  },
});

export const {
  fetchSharingList,
  fetchSharingListSuccess,
  fetchSharingListFailure,
  assignUsertoSpaceSuccess,
  assignUsertoSpace,
  assignUsertoSpaceFailure,
  deleteSpace,
  deleteSpaceSuccess,
  deleteSpaceFailure,
  getSharingAlterInfo,
  resetSharingAlterInfo
} = sharingListSlice.actions;

export default sharingListSlice.reducer;