import { call, put, takeEvery } from 'redux-saga/effects';
import {
  fetchSharingList, fetchSharingListSuccess, fetchSharingListFailure,
  assignUsertoSpace, assignUsertoSpaceSuccess, assignUsertoSpaceFailure
  , deleteSpace, deleteSpaceSuccess, deleteSpaceFailure, getSharingAlterInfo
} from './sharingListSlice';
import baseApi from "../../app/api";
import { getUsersByFormIdError, getUsersByFormIdSuccess } from '../sharing/sharingSlice';

export function* fetchSharingListSaga(action) {
  try {
    const response = yield call(() => baseApi.get("workspaces"));
    yield put(fetchSharingListSuccess(response?.data?.data));
  } catch (error) {
    yield put(fetchSharingListFailure(error));
  }
}

export function* getUsersByFormIdSaga(action) {
  try {
    const { form_id } = action.payload;
    const response = yield call(() => baseApi.get(`users/getusers?form_id=${form_id}`));
    yield put(getUsersByFormIdSuccess(response?.data?.data));
  } catch (error) {
    yield put(getUsersByFormIdError(error));
  }
}




export function* assignUserstoSpaceSaga(action) {
  try {
    const { currentSpaceId } = action.payload;
    // const { id } = action.payload.currentSpaceId;


    const response = yield call(() =>
      baseApi.put(`workspaces/update/${currentSpaceId}`, action.payload.payload)
    );

    yield put(assignUsertoSpaceSuccess(response?.data));
  } catch (error) {
    yield put(assignUsertoSpaceFailure(error));
  }
}



export function* deleteSpaceSaga(action) {


  try {
    const { space_id } = action.payload;

    const response = yield call(() =>
      baseApi.put(`workspaces/update/${space_id}`, action.payload.request)
    );


    yield put(deleteSpaceSuccess(response?.data));
    yield put(getSharingAlterInfo({ type: 'success', message: 'Space has been deleted successfully!' }));
  } catch (error) {
    yield put(deleteSpaceFailure(error));
    yield put(getSharingAlterInfo({ type: 'error', message: 'Something went wrong while deleting space!' }));
  }


}