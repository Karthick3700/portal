import { all, takeLatest } from "redux-saga/effects";
import {
  initUserInfo,
  resetUserData,
  initRegisterInfo,
  fetchAllUsers,
  getAllUsers,
  initForgotPassword,
  initResetPassword,
} from "./users/slice";
import {
  deleteFormById,
  getFormListings,
  getFormdataById,
  saveAddForm,
  saveUpdateForm,
} from "./forms/formsSlice";
import {
  createDashboard,
  deleteNewFormData,
  downloadTemplate,
  exportFormDatatoExcel,
  formDatabyApplyFilter,
  getDataByFormId,
  getDomainDataListing,
  getDomainDataByDomainId,
  getFormDatabySearchFilter,
  saveNewFormData,
  updateNewFormData,
  uploadFormdata,
} from "./datasearch/dataSearchSlice";
import {
  getAllWorkspaces,
  getUsersByFormId,
  getWorkspaceById,
  saveNewSpace,
  updateWorkspace,
} from "./sharing/sharingSlice";
import {
  getUserSaga,
  registerUserSaga,
  logoutUserSaga,
  fetchAllUsersDataSaga,
  getAllUsersSaga,
  forgotPwdSaga,
  resetPwdSaga,
} from "./users/sagas";
import {
  deleteFormByIdSaga,
  getFormListingSaga,
  getFormdataByIdSaga,
  saveAddFormSaga,
  saveUpdateFormSaga,
} from "./forms/formsSagas";

import {
  deleteNewFormDataSaga,
  downloadTemplateSaga,
  exportFormDatatoExcelSaga,
  formDatabyApplyFilterSaga,
  getDataByFormIdSaga,
  getFormDatabySearchFilterSaga,
  saveNewFormDataSaga,
  updateNewFormDataSaga,
  uploadFormdataSaga,
  createDashboardDataSaga,
  getDomainDataListingSaga,
  getDomainDataByDomainIdSaga
} from "./datasearch/dataSearchSagas";

import {
  getWorkspaceByIdSaga,
  saveNewSpaceSaga,
  updateWorkspaceSaga,
} from "./sharing/sharingSagas";
import {
  fetchSharingListSaga,
  assignUserstoSpaceSaga,
  deleteSpaceSaga,
  getUsersByFormIdSaga,
} from "./sharinglist/sharingListSaga";

import {
  fetchSharingList,
  assignUsertoSpace,
  deleteSpace,
} from "./sharinglist/sharingListSlice";

import {
  fetchItemsPerReportList,
  fetchdashboardList,
  fetchdashboardStreamsList,
  fetchreportList,
  fetchReportinPdf
} from "./dashboard/dashboardSlice";
import {
  fetchDashbaordStreamsSaga,
  fetchDashboardStreamsDataSaga,
  fetchItemsPerReportDataSaga,
  fetchReportsDataSaga,
  fetchReportinPdfSaga
} from "./dashboard/dashboardSaga";
import {
  fetchservicerequestCreate,
  fetchservicerequestUpload,
  fetchExcelExport,
} from "./servicerequest/servicerequestSlice";
import {
  fetchservicerequestCreateSaga,
  fetchservicerequestUploadSaga,
  getExcelExportSaga,
} from "./servicerequest/servicerequestSaga";

import {
  initNotifications,
  initReadNotification,
} from "./notifications/notificationSlice";
import {
  getNotificationsSaga,
  readNotificationaga,
} from "./notifications/notificationSagas";

function* watcherSaga() {
  yield takeLatest(initUserInfo, getUserSaga);
  yield takeLatest(initRegisterInfo, registerUserSaga);
  yield takeLatest(initForgotPassword, forgotPwdSaga);
  yield takeLatest(initResetPassword, resetPwdSaga);
  yield takeLatest(resetUserData, logoutUserSaga);
  yield takeLatest(saveAddForm, saveAddFormSaga);
  yield takeLatest(getFormdataById, getFormdataByIdSaga);
  yield takeLatest(getFormListings, getFormListingSaga);
  yield takeLatest(saveUpdateForm, saveUpdateFormSaga);
  yield takeLatest(saveNewFormData, saveNewFormDataSaga);
  yield takeLatest(downloadTemplate, downloadTemplateSaga);
  yield takeLatest(getDataByFormId, getDataByFormIdSaga);
  yield takeLatest(updateNewFormData, updateNewFormDataSaga);
  yield takeLatest(deleteNewFormData, deleteNewFormDataSaga);
  yield takeLatest(exportFormDatatoExcel, exportFormDatatoExcelSaga);
  yield takeLatest(deleteFormById, deleteFormByIdSaga);
  yield takeLatest(getAllUsers, getAllUsersSaga);
  yield takeLatest(saveNewSpace, saveNewSpaceSaga);
  yield takeLatest(getWorkspaceById, getWorkspaceByIdSaga);
  yield takeLatest(getAllWorkspaces, getWorkspaceByIdSaga);
  yield takeLatest(updateWorkspace, updateWorkspaceSaga);
  yield takeLatest(fetchSharingList, fetchSharingListSaga);
  yield takeLatest(fetchAllUsers, fetchAllUsersDataSaga);
  yield takeLatest(getUsersByFormId, getUsersByFormIdSaga);
  yield takeLatest(assignUsertoSpace, assignUserstoSpaceSaga);
  yield takeLatest(deleteSpace, deleteSpaceSaga);
  yield takeLatest(uploadFormdata, uploadFormdataSaga);
  yield takeLatest(getFormDatabySearchFilter, getFormDatabySearchFilterSaga);
  yield takeLatest(formDatabyApplyFilter, formDatabyApplyFilterSaga);
  yield takeLatest(fetchdashboardList, fetchDashbaordStreamsSaga);
  yield takeLatest(fetchdashboardStreamsList, fetchDashboardStreamsDataSaga);
  yield takeLatest(initNotifications, getNotificationsSaga);
  yield takeLatest(initReadNotification, readNotificationaga);
  yield takeLatest(createDashboard, createDashboardDataSaga);
  yield takeLatest(fetchservicerequestCreate, fetchservicerequestCreateSaga);
  yield takeLatest(fetchservicerequestUpload, fetchservicerequestUploadSaga);
  yield takeLatest(getDomainDataListing, getDomainDataListingSaga);
  yield takeLatest(getDomainDataByDomainId, getDomainDataByDomainIdSaga);
  yield takeLatest(fetchExcelExport, getExcelExportSaga);
  yield takeLatest(fetchreportList, fetchReportsDataSaga);
  yield takeLatest(fetchItemsPerReportList, fetchItemsPerReportDataSaga);
  yield takeLatest(fetchReportinPdf, fetchReportinPdfSaga);
}

export default function* rootSaga() {
  yield all([watcherSaga()]);
}
