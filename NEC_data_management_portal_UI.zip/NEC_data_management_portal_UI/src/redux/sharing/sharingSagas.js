import baseApi from "../../app/api";
import { call, put } from "redux-saga/effects";
import { 
  getAllWorkspacesError,
  getAllWorkspacesSuccess,
  getWorkspaceByIdError,
  getWorkspaceByIdSuccess,
  saveNewSpaceError, 
  saveNewSpaceSuccess, 
  updateWorkspaceError, 
  updateWorkspaceSuccess
} from "./sharingSlice";
import { fetchSharingListSuccess } from "../sharinglist/sharingListSlice";


export function* saveNewSpaceSaga(action) {
  try {
    const addedNewspace = yield call(() => baseApi.post('workspaces/create',action.payload));
    const response = yield call(() => baseApi.get("workspaces"));
    yield put(fetchSharingListSuccess(response?.data?.data));
    yield put(saveNewSpaceSuccess(addedNewspace?.data?.data));
  } catch (error) {
    yield put(saveNewSpaceError(error.response.data.meta.message));
  }
}

export function* getWorkspaceByIdSaga(action) {
  try {
    const { space_id } = action.payload;
    const response = yield call(() => baseApi.get(`workspaces/${space_id}`));
    yield put(getWorkspaceByIdSuccess(response?.data?.data));
  } catch (error) {
    yield put(getWorkspaceByIdError(error));
  }
}

export function* getAllWorkspacesSaga(action) {
  try {
    const response = yield call(() => baseApi.get('workspaces'));
    yield put(getAllWorkspacesSuccess(response?.data?.data));
  } catch (error) {
    yield put(getAllWorkspacesError(error));
  }
}

export function* updateWorkspaceSaga(action) {
  try {
    const { space_id, spaceData } = action.payload;
    const response = yield call(() => baseApi.put(`workspaces/update/${space_id}`, spaceData));
    const workspaces = yield call(() => baseApi.get("workspaces"));
    yield put(fetchSharingListSuccess(workspaces?.data?.data));
    yield put(updateWorkspaceSuccess(response?.data?.data));
  } catch (error) {
    yield put(updateWorkspaceError(error.response.data.meta.message));
  }
}








