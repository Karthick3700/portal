import { createSlice } from "@reduxjs/toolkit";

const sharingInitialState ={
  isLoading: false,
  errors: "",
  allSpaces:null,
  isSpaceLoading:false,
  workspace: null,
  isListSpaceLoading: false,
  worspacelisting: null,
  isSelectedUserByFormLoading: false,
  userlistingbyid: null,
  isSaveSharingLoading: false,
  savenewspaceMsg: null,
  savenewspaceType: null,
}

export const sharingSlice = createSlice({
    name: 'sharing',
    initialState: sharingInitialState,
    reducers:{
        saveNewSpace:(state, action)=>{
            state.isSaveSharingLoading = true
        },
        saveNewSpaceSuccess: (state, action) => {
            state.isSaveSharingLoading = false;
            state.savenewspaceMsg = 'Space Created Successfully!';
            state.savenewspaceType = 'success';
            state.data = action?.payload;
        },
        saveNewSpaceError: (state, action) => {
            state.isSaveSharingLoading = false;
            state.savenewspaceMsg = action?.payload;
            state.savenewspaceType = 'error';
            state.errors = action?.payload;
        },
        updateWorkspace:(state, action)=>{
            state.isSpaceLoading = true
        },
        updateWorkspaceSuccess: (state, action) => {
            state.isSpaceLoading = false;
            state.savenewspaceMsg = 'Space Updated Successfully!';
            state.savenewspaceType = 'success';
            state.updatedata = action?.payload;
        },
        updateWorkspaceError: (state, action) => {
            state.isSpaceLoading = false;
            state.savenewspaceMsg = action?.payload;
            state.savenewspaceType = 'error';
            state.errors = action?.payload;
        },
        getWorkspaceById:(state, action)=>{
            state.isSpaceLoading = true
        },
        getWorkspaceByIdSuccess: (state, action) => {
            state.isSpaceLoading = false;
            state.workspace = action?.payload;
        },
        getWorkspaceByIdError: (state, action) => {
            state.isSpaceLoading = false;
            state.errors =  action?.payload;
        },
        getAllWorkspaces: (state, action) => {
            state.isListSpaceLoading = true;
        },
        getAllWorkspacesSuccess: (state, action) => {
            state.isListSpaceLoading = false;
            state.worspacelisting = action?.payload;
        },
        getAllWorkspacesError: (state, action) => {
            state.isListSpaceLoading = false;
            state.errors = action?.payload;
        },
        getUsersByFormId: (state, action) => {
            state.isSelectedUserByFormLoading = true;
        },
        getUsersByFormIdSuccess: (state, action) => {
            state.isSelectedUserByFormLoading = false;
            state.userlistingbyid = action?.payload;
        },
        getUsersByFormIdError: (state, action) => {
            state.isSelectedUserByFormLoading = false;
            state.errors = action?.payload;
        },
        clearSpaceMessage: (state, action) => {
            state.savenewspaceMsg = null;
            state.savenewspaceType = null;
        }
    }
})

export const {
    saveNewSpace,
    saveNewSpaceSuccess,
    saveNewSpaceError,
    updateWorkspace,
    updateWorkspaceSuccess,
    updateWorkspaceError,
    getWorkspaceById,
    getWorkspaceByIdSuccess,
    getWorkspaceByIdError,
    getAllWorkspaces,
    getAllWorkspacesSuccess,
    getAllWorkspacesError,
    getUsersByFormId,
    getUsersByFormIdSuccess,
    getUsersByFormIdError,
    clearSpaceMessage
} = sharingSlice.actions

export default sharingSlice.reducer;