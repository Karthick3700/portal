import { createSelector } from "@reduxjs/toolkit";

export const selectSpaceListing = (state) => state.sharing;

export const selectSpaceLoading = createSelector(
  selectSpaceListing,
  (space) => space?.isSpaceLoading
);

export const selectWorkspaceById = createSelector(
  selectSpaceListing,
  (space) => space?.workspace
);

export const selectWorkspaceListing = createSelector(
  selectSpaceListing,
  (space) => space?.worspacelisting
);

export const selectUserListingByFormId = createSelector(
  selectSpaceListing,
  (space) => space?.userlistingbyid
);

export const selectUsersbyFormLoading = createSelector(
  selectSpaceListing,
  (space) => space?.isSelectedUserByFormLoading
);

export const selectSaveNewSpaceMsg = createSelector(
  selectSpaceListing,
  (space) => space?.savenewspaceMsg
);

export const selectSaveNewSpaceType = createSelector(
  selectSpaceListing,
  (space) => space?.savenewspaceType
);



  