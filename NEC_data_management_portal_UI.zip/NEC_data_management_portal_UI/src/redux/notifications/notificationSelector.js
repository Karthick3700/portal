import { createSelector } from '@reduxjs/toolkit';

export const selectNotificationsInfo = (state) => state.notifications;

export const getNotifications = createSelector(
  selectNotificationsInfo,
  (notifications) => notifications.notifications || []
);
