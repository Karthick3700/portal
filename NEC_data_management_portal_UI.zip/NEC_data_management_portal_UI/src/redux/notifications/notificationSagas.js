import baseApi from "../../app/api";
import { call, put } from "redux-saga/effects";
import { getNotificationsSuccess, getNotificationsError, readNotificationSuccess } from "./notificationSlice";

export function* getNotificationsSaga() {
    try {
        const response = yield call(baseApi.get, "notifications");
        yield put(getNotificationsSuccess(response.data.data));
    } catch (error) {
        const errorMessage = error.response?.data?.meta?.message || "An error occurred";
        yield put(getNotificationsError(errorMessage));
    }
}

export function* readNotificationaga(action) {
    try {
        const { notificationId } = action.payload;
        const response = yield call(baseApi.get, `notifications/${notificationId}/mark-as-read`);
        yield put(readNotificationSuccess(response.data.data));
    } catch (error) {
        const errorMessage = error.response?.data?.meta?.message || "An error occurred";
        yield put(getNotificationsError(errorMessage));
    }
}
