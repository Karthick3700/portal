import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  notifications: [],
  notificationsLoading: false,
  notificationsError: ""
};

const notificationsSlice = createSlice({
  name: "notifications",
  initialState,
  reducers: {
    initNotifications: (state) => {
      state.notificationsLoading = true;
    },
    getNotificationsSuccess: (state, action) => {
      state.notificationsLoading = false;
      state.notificationsError = "";
      state.notifications = action.payload;
    },
    getNotificationsError: (state, action) => {
      state.notificationsLoading = false;
      state.notificationsError = action.payload;
    },
    addNotification: (state, action) => {
      state.notifications = [action.payload, ...state.notifications];
    },
    initReadNotification: (state) => {
      state.notificationsLoading = true;
    },
    readNotificationSuccess: (state, action) => {
      const notification_id = action.payload.notification_id;
      const index = state.notifications.findIndex(notification => notification.notification_id.toString() === notification_id.toString());

      if (index !== -1) {
        state.notifications[index].relatedUsers = {
          ...state.notifications[index].relatedUsers,
          isRead: true
        };
      }
    }
  },
});

export const {
  initNotifications,
  getNotificationsSuccess,
  getNotificationsError,
  addNotification,
  initReadNotification,
  readNotificationSuccess
} = notificationsSlice.actions;

export default notificationsSlice.reducer;
