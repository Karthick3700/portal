import { createSlice } from "@reduxjs/toolkit";

const dataSearchInitialState = {
  isLoading: false,
  errors: "",
  formDataSearchValues: [],
  formdata: null,
  updatedata: null,
  isFormdataLoading: false,
  isFormsLoading: false,
  formDataSavedMsg: null,
  formDataSavedType: null,
  formDataAlterStatus: "",
  formDataAlterMessage: "",
  createDashboard: [],
  isDomainDataListingLoading: false,
  domainDataListing: null,
  isDomainDataByDomainIdLoading: false,
  domainDataByDomainId: null
};

export const dataSearchSlice = createSlice({
  name: "datasearch",
  initialState: dataSearchInitialState,
  reducers: {
    saveNewFormData: (state, action) => {
      state.isFormdataLoading = true;
    },
    saveNewFormDataSuccess: (state, action) => {
      state.isFormdataLoading = false;
      state.data = action?.payload;
    },
    saveNewFormDataError: (state, { payload: error }) => {
      state.isFormdataLoading = false;
      state.errors = error;
    },
    updateNewFormData: (state, action) => {
      state.isFormdataLoading = true;
    },
    updateNewFormDataSuccess: (state, action) => {
      state.isFormdataLoading = false;
      state.updatedata = action?.payload;
    },
    updateNewFormDataError: (state, { payload: error }) => {
      state.isFormdataLoading = false;
      state.errors = error;
    },
    deleteNewFormData: (state, action) => {
      state.isFormdataLoading = true;
    },
    deleteNewFormDataSuccess: (state, action) => {
      state.isFormdataLoading = false;
      state.updatedata = action?.payload;
    },
    deleteNewFormDataError: (state, { payload: error }) => {
      state.isFormdataLoading = false;
      state.errors = error;
    },
    downloadTemplate: (state, action) => {
      state.isLoading = true;
    },
    downloadTemplateSuccess: (state, action) => {
      state.isLoading = false;
      state.data = action?.payload;
    },
    downloadTemplateError: (state, { payload: error }) => {
      state.isLoading = false;
      state.errors = error;
    },
    getDataByFormId: (state, { payload: error }) => {
      state.isFormsLoading = true;
      state.errors = error;
    },
    getDataByFormIdSuccess: (state, action) => {
      state.isFormsLoading = false;
      state.formdata = action?.payload;
    },
    getDataByFormIdError: (state, { payload: error }) => {
      state.isFormsLoading = false;
      state.errors = error;
    },
    exportFormDatatoExcel: (state, action) => {
      state.isLoading = true;
    },
    exportFormDatatoExcelSuccess: (state, action) => {
      state.isLoading = false;
      state.data = action?.payload;
    },
    exportFormDatatoExcelError: (state, { payload: error }) => {
      state.isLoading = false;
      state.errors = error;
    },
    uploadFormdata: (state, action) => {
      state.isLoading = true;
    },
    uploadFormdataSuccess: (state, action) => {
      state.isLoading = false;
      state.formDataSavedMsg = "Data imported successfully!";
      state.formDataSavedType = "success";
    },
    uploadFormdataError: (state, action) => {
      state.isLoading = false;
      state.formDataSavedMsg = action?.payload;
      state.formDataSavedType = "error";
    },
    clearFormDataMessage: (state, action) => {
      state.formDataSavedMsg = null;
      state.formDataSavedType = null;
    },
    getformDataAlterInfo: (state, action) => {
      state.isFormsLoading = false;
      state.formDataAlterStatus = action.payload.type;
      state.formDataAlterMessage = action.payload.message;
    },
    resetformDataAlterInfo: (state) => {
      state.formDataAlterStatus = "";
      state.formDataAlterMessage = "";
    },
    getFormDatabySearchFilter: (state, action) => {
      state.isLoading = true;
    },
    getFormDatabySearchFilterSuccess: (state, action) => {
      state.isLoading = true;
      state.searchedColumnValues = action?.payload;
    },
    getFormDatabySearchFilterError: (state, action) => {
      state.isLoading = true;
      state.errors = action?.payload;
    },
    formDatabyApplyFilter: (state, action) => {
      state.isLoading = true;
    },
    formDatabyApplyFilterSuccess: (state, action) => {
      state.isLoading = true;
      state.searchedColumnValues = action?.payload;
    },
    formDatabyApplyFilterError: (state, action) => {
      state.isLoading = true;
      state.errors = action?.payload;
    },
    getDashboardId: (state, { payload: error }) => {
      state.isFormsLoading = true;
      state.errors = error;
    },
    getDashboardIdSuccess: (state, action) => {
      state.isFormsLoading = false;
      state.dashboardId = action?.payload;
    },
    getDashboardIdError: (state, { payload: error }) => {
      state.isFormsLoading = false;
      state.errors = error;
    },
    createDashboard: (state, { payload: error }) => {
      state.isFormsLoading = true;
      state.errors = error;
    },
    createDashboardSuccess: (state, action) => {
      state.isFormsLoading = false;
      state.createDashboard = action?.payload;
    },
    createDashboardError: (state, { payload: error }) => {
      state.isFormsLoading = false;
      state.errors = error;
    },
    getDomainDataListing: (state, action) => {
      state.isDomainDataListingLoading = true;
    },
    getDomainDataListingSuccess: (state, action) => {
      state.isDomainDataListingLoading = false;
      state.domainDataListing = action?.payload;
    },
    getDomainDataListingError: (state, action) => {
      state.isDomainDataListingLoading = false;
      state.domainDataListing = [];
    },
    getDomainDataByDomainId: (state, action) => {
      state.isDomainDataByDomainIdLoading = true;
    },
    getDomainDataByDomainIdSuccess: (state, action) => {
      state.isDomainDataByDomainIdLoading = false;
      state.domainDataByDomainId = action?.payload;
    },
    getDomainDataByDomainIdError: (state, action) => {
      state.isDomainDataByDomainIdLoading = false;
      state.domainDataByDomainId = [];
    },
  },
});

export const {
  saveNewFormData,
  saveNewFormDataSuccess,
  saveNewFormDataError,
  downloadTemplate,
  downloadTemplateSuccess,
  downloadTemplateError,
  getDataByFormId,
  getDataByFormIdSuccess,
  getDataByFormIdError,
  updateNewFormData,
  updateNewFormDataSuccess,
  updateNewFormDataError,
  exportFormDatatoExcel,
  exportFormDatatoExcelSuccess,
  exportFormDatatoExcelError,
  deleteNewFormData,
  deleteNewFormDataSuccess,
  deleteNewFormDataError,
  uploadFormdata,
  uploadFormdataSuccess,
  uploadFormdataError,
  clearFormDataMessage,
  getformDataAlterInfo,
  resetformDataAlterInfo,
  getFormDatabySearchFilter,
  getFormDatabySearchFilterSuccess,
  getFormDatabySearchFilterError,
  formDatabyApplyFilter,
  formDatabyApplyFilterSuccess,
  formDatabyApplyFilterError,
  getDashboardId,
  getDashboardIdError,
  getDashboardIdSuccess,
  createDashboard,
  createDashboardError,
  createDashboardSuccess,
  getDomainDataListing,
  getDomainDataListingSuccess,
  getDomainDataListingError,
  getDomainDataByDomainId,
  getDomainDataByDomainIdSuccess,
  getDomainDataByDomainIdError,
} = dataSearchSlice.actions;

export default dataSearchSlice.reducer;
