import baseApi from "../../app/api";
import { call, put } from "redux-saga/effects";
import {
  downloadTemplateError,
  formDatabyApplyFilterError,
  formDatabyApplyFilterSuccess,
  getDataByFormIdError,
  getDataByFormIdSuccess,
  getFormDatabySearchFilterError,
  getFormDatabySearchFilterSuccess,
  saveNewFormDataError,
  saveNewFormDataSuccess,
  updateNewFormDataError,
  updateNewFormDataSuccess,
  uploadFormdataError,
  uploadFormdataSuccess,
  getformDataAlterInfo,
  createDashboardSuccess,
  createDashboardError,
  getDashboardIdSuccess,
  getDashboardIdError,
  getDomainDataListingSuccess,
  getDomainDataListingError,
  getDomainDataByDomainIdSuccess,
  getDomainDataByDomainIdError,
} from "./dataSearchSlice";
import axios from "axios";

export function* saveNewFormDataSaga(action) {
  try {
    const { form_id, fields, offset, limit, search, ...createPayload } =
      action?.payload;

    const createResponse = yield call(() =>
      baseApi.post(`formdata/create/`, { form_id, fields, ...createPayload })
    );

    const getDataPayload = { id: form_id, offset, limit, search };
    yield call(getDataByFormIdSaga, { payload: getDataPayload });

    yield put(saveNewFormDataSuccess(createResponse?.data));
    yield put(
      getformDataAlterInfo({
        type: "success",
        message: "New data has been added successfully!",
      })
    );
  } catch (error) {
    yield put(saveNewFormDataError(error));
    yield put(
      getformDataAlterInfo({
        type: "error",
        message: "Something went wrong while adding data!",
      })
    );
  }
}

export function* downloadTemplateSaga(action) {
  try {
    const { id } = action.payload;
    yield call(() =>
      axios
        .get(`http://localhost:3005/exceltemplate/${id}.xlsx`, {
          headers: {
            "Content-Disposition": "attachment; filename=template.xlsx",
            "Content-Type":
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          },
          responseType: "arraybuffer",
        })
        .then((response) => {
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", "template.xlsx");
          document.body.appendChild(link);
          link.click();
        })
    );
  } catch (error) {
    yield put(downloadTemplateError(error));
  }
}

export function* getDomainDataListingSaga(action) {
  try {
    const { offset, limit } = action.payload;
    const response = yield call(() =>
      baseApi.get(`forms/domainvalue?offset=${offset}&limit=${limit}`)
    );
    yield put(getDomainDataListingSuccess(response?.data?.data));
  } catch (error) {
    yield put(getDomainDataListingError(error?.response?.data?.meta?.message));
  }
}

export function* getDomainDataByDomainIdSaga(action) {
  try {
    const { offset, limit, form_id } = action.payload;
    const response = yield call(() =>
      baseApi.get(
        `formdata/domainvaluedata?form_id=${form_id}&offset=${offset}&limit=${limit}`
      )
    );
    yield put(getDomainDataByDomainIdSuccess(response.data.data));
  } catch (error) {
    yield put(getDomainDataByDomainIdError(error.response.data.meta.message));
  }
}

export function* getDataByFormIdSaga(action) {
  try {
    const { id, offset, limit, search } = action.payload;
    const queryParams = search ? `&search=${search}` : "";

    const response = yield call(() =>
      baseApi.get(
        `formdata?form_id=${id}&offset=${offset}&limit=${limit}${queryParams}`
      )
    );
    yield put(getDataByFormIdSuccess(response?.data));
  } catch (error) {
    yield put(getDataByFormIdError(error?.response?.data?.meta?.message));
  }
}

export function* formDatabyApplyFilterSaga(action) {
  try {
    const response = yield call(() =>
      baseApi.post(`formdata/getResponsesByResponseId`, action.payload)
    );
    yield put(getDataByFormIdSuccess(response?.data));
  } catch (error) {
    yield put(formDatabyApplyFilterError(error?.response?.data?.meta?.message));
  }
}

export function* getFormDatabySearchFilterSaga(action) {
  try {
    const { id, offset, limit, search, field_label } = action.payload;
    const queryParams = search ? `&search=${search}` : "";

    const response = yield call(() =>
      baseApi.get(
        `formdata/filterDataResponse?form_id=${id}&offset=${offset}&field_label=${field_label}&limit=${limit}${queryParams}`
      )
    );
    const data = [];
    response.data.data?.map((row) => {
      data[row[field_label]] = false;
    });
    yield put(getFormDatabySearchFilterSuccess(data));
  } catch (error) {
    yield put(getFormDatabySearchFilterError(error));
  }
}

export function* updateNewFormDataSaga(action) {
  try {
    const { form_response_id, fields, form_id, offset, limit, search } =
      action?.payload;

    const response = yield call(() =>
      baseApi.put(`formdata/update/${form_response_id}`, { fields })
    );

    yield call(getDataByFormIdSaga, {
      payload: { id: form_id, offset, limit, search },
    });
    yield put(updateNewFormDataSuccess(response?.data?.data));
    yield put(
      getformDataAlterInfo({
        type: "success",
        message: "Data has been updated successfully!",
      })
    );
  } catch (error) {
    yield put(updateNewFormDataError(error));
    yield put(
      getformDataAlterInfo({
        type: "error",
        message: "Something went wrong while updating data!",
      })
    );
  }
}

export function* deleteNewFormDataSaga(action) {
  try {
    const { id, form_id, offset, limit, search } = action?.payload;
    const response = yield call(() =>
      baseApi.put(`formdata/update/${id}`, {
        form_response_status: "deleted",
      })
    );
    yield call(getDataByFormIdSaga, {
      payload: { id: form_id, offset, limit, search },
    });

    yield put(updateNewFormDataSuccess(response?.data?.data));
    yield put(
      getformDataAlterInfo({
        type: "success",
        message: "Data has been deleted successfully!",
      })
    );
  } catch (error) {
    yield put(updateNewFormDataError(error));
    yield put(
      getformDataAlterInfo({
        type: "error",
        message: "Something went wrong while deleting data!",
      })
    );
  }
}

export function* exportFormDatatoExcelSaga(action) {
  try {
    const bearerToken = sessionStorage.getItem("token");
    const { id } = action.payload;
    yield call(() =>
      axios
        .get(`http://localhost:3005/api/v1/formdata/export/${id}`, {
          headers: {
            "Content-Disposition": "attachment; filename=template1.xlsx",
            "Content-Type":
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            Authorization: `JWT ${bearerToken}`,
            "x-access-token": `JWT ${bearerToken}`,
          },
          responseType: "arraybuffer",
        })
        .then((response) => {
          const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", "template1.xlsx");
          document.body.appendChild(link);
          link.click();
          link.remove();
        })
    );
  } catch (error) {
    yield put(downloadTemplateError(error));
  }
}

export function* uploadFormdataSaga(action) {
  try {
    const { offset, limit, search, ...createPayload } = action?.payload;
    const bearerToken = sessionStorage.getItem("token");
    // const response = yield call(() => baseApi.post('formdata/import', action?.payload ));
    var config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `JWT ${bearerToken}`,
        "x-access-token": `JWT ${bearerToken}`,
      },
    };

    const response = yield call(() =>
      axios
        .post(
          "http://localhost:3005/api/v1/formdata/import",
          createPayload,
          config
        )
        .then((response) => response.data.meta)
    );

    const { formId } = action.payload;
    yield call(getDataByFormIdSaga, {
      payload: { id: formId, offset, limit, search },
    });

    yield put(uploadFormdataSuccess(response?.data?.meta));
  } catch (error) {
    yield put(uploadFormdataError(error.response.data.meta.message));
  }
}

export function* createDashboardDataSaga(action) {
  try {
    const response = yield call(() =>
      baseApi.post(`dashboards/app/create/`, action.payload)
    );
    yield put(createDashboardSuccess(response.data));
  } catch (error) {
    yield put(createDashboardError(error));
  }
}

export function* getDashboardIdSaga(action) {
  try {
    const response = yield call(() => baseApi.post(`forms`, action.payload));
    yield put(getDashboardIdSuccess(response.data));
  } catch (error) {
    yield put(getDashboardIdError(error));
  }
}
