import { createSelector } from "@reduxjs/toolkit";

export const selectDataSearch = (state) => state.datasearch;

export const isDataLoading = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.isLoading
);

export const getformDataListing = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.formdata
);

export const isformDataLoading = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.isFormdataLoading
);

export const isformsLoading = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.isFormsLoading
);

export const selectSaveFormDataMsg = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.formDataSavedMsg
);

export const selectSaveFormDataType = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.formDataSavedType
);

export const selectSearchedColumnValues = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.searchedColumnValues
);

export const getDashboardId = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.dashboardId
);

export const createDashboardData = createSelector(
  selectDataSearch,
  (datasearch) => datasearch?.createDashboard
);
