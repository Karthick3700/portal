import baseApi from "../../app/api";
import { call, put } from "redux-saga/effects";
import {
  deleteFormByIdError,
  deleteFormByIdSuccess,
  getFormListingsError,
  getFormListingsSuccess,
  getFormdataByIdError,
  getFormdataByIdSuccess,
  saveAddFormError,
  saveAddFormSuccess,
  saveUpdateFormError,
  saveUpdateFormSuccess,
} from "../forms/formsSlice";

// Generator function
export function* saveAddFormSaga(action) {
  try {
    const response = yield call(() =>
      baseApi.post("forms/create", action.payload)
    );
    const formlists = yield call(() => baseApi.get("forms"));
    yield put(getFormListingsSuccess(formlists?.data?.data));
    yield put(saveAddFormSuccess(response?.data?.data));
  } catch (error) {
    yield put(saveAddFormError(error.response.data.meta.message));
  }
}

export function* getFormListingSaga(action) {
  try {
    const response = yield call(() => baseApi.get("forms"));
    yield put(getFormListingsSuccess(response?.data?.data));
  } catch (error) {
    yield put(getFormListingsError(error));
  }
}

export function* getFormdataByIdSaga(action) {
  try {
    const { id } = action?.payload;
    const response = yield call(() => baseApi.get(`forms/${id}`));
    yield put(getFormdataByIdSuccess(response?.data?.data));
  } catch (error) {
    yield put(getFormdataByIdError(error));
  }
}

export function* saveUpdateFormSaga(action) {
  try {

    const { id } = action.payload;
    const { formData } = action.payload;
    const response = yield call(() =>
      baseApi.put(`forms/update/${id}`, formData)
    );
    const formlists = yield call(() => baseApi.get("forms"));
    yield put(getFormListingsSuccess(formlists?.data?.data));
    yield put(saveUpdateFormSuccess(response?.data));
  } catch (error) {
    yield put(saveUpdateFormError(error.response.data.meta.message));
  }
}

export function* deleteFormByIdSaga(action) {
  try {
    const { form_id } = action.payload;
    const response = yield call(() =>
      baseApi.put(`forms/update/${form_id}`, {
        form_status: "deleted"
    }));
    const formlists = yield call(() => baseApi.get("forms"));
    yield put(getFormListingsSuccess(formlists?.data?.data));
    yield put(deleteFormByIdSuccess(response?.data));
  } catch (error) {
    yield put(deleteFormByIdError(error));
  }
}
