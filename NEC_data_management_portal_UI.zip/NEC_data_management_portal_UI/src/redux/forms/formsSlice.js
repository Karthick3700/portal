import { createSlice } from "@reduxjs/toolkit";

const formsInitialState = {
  data: null,
  isLoading: false,
  errors: "",
  bearerToken: "",
  allforms: [],
  formdetails: null,
  updateform: null,
  deletedform: null,
  formlistingLoading: false,
  formsavedMsg: null,
  formsavedType: null

};

export const formsSlice = createSlice({
  name: "forms",
  initialState: formsInitialState,
  reducers: {
    saveAddForm: (state, action) => {
      state.isLoading = true;
    },
    saveAddFormSuccess: (state, action) => {
      state.isLoading = false;
      state.formsavedMsg =  'Form Saved Successfully!';
      state.formsavedType = 'success';
    },
    saveAddFormError: (state, action) => {
      state.isLoading = false;
      state.formsavedMsg = action?.payload;
      state.formsavedType = 'error';
    },
    saveUpdateForm: (state, action) => {
      state.isLoading = true;
    },
    saveUpdateFormSuccess: (state, action) => {
      state.isLoading = false;
      state.formsavedMsg = 'Form Updated Successfully!';
      state.formsavedType = 'success';
    },
    saveUpdateFormError: (state, action) => {
      state.isLoading = false;
      state.formsavedMsg = action?.payload;
      state.formsavedType = 'error';
    },
    getFormListings: (state, action) => {
      state.formlistingLoading = true;
    },
    getFormListingsSuccess: (state, action) => {
      state.formlistingLoading = false;
      state.allforms = action?.payload;
    },
    getFormListingsError: (state, { payload: error }) => {
      state.formlistingLoading = false;
      state.errors = error;
    },
    getFormdataById: (state, action) => {
      state.isLoading = false;
      state.errors = "";
    },
    getFormdataByIdSuccess: (state, action) => {
      state.isLoading = false;
      state.formdetails = action?.payload;
    },
    getFormdataByIdError: (state, { payload: error }) => {
      state.isLoading = false;
      state.errors = error;
    },
    deleteFormById: (state, action) => {
      state.formlistingLoading = true;
    },
    deleteFormByIdSuccess: (state, action) => {
      state.formlistingLoading = false;
      state.deletedform = action?.payload;
    },
    deleteFormByIdError: (state, { payload: error }) => {
      state.formlistingLoading = false;
      state.errors = error;
    },
    clearFormMessage: (state, action) => {
      state.formsavedMsg = null;
      state.formsavedType = null;
    },
  },
});

export const {
  saveAddForm,
  saveAddFormSuccess,
  saveAddFormError,
  saveUpdateForm,
  saveUpdateFormSuccess,
  saveUpdateFormError,
  getFormListings,
  getFormListingsSuccess,
  getFormListingsError,
  getFormdataById,
  getFormdataByIdSuccess,
  getFormdataByIdError,
  deleteFormById,
  deleteFormByIdSuccess,
  deleteFormByIdError,
  clearFormMessage
} = formsSlice.actions;

export default formsSlice.reducer;
