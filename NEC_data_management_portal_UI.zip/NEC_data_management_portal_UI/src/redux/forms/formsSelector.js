import { createSelector } from "@reduxjs/toolkit";

export const selectForms = (state) => state.forms;

export const getAllFormsData = createSelector(
  selectForms,
  (form) => form?.allforms
);

export const getFormdetails = createSelector(
  selectForms,
  (form) => form?.formdetails
);

export const isFormLoading = createSelector(
  selectForms,
  (form) => form?.isLoading
);

export const isFormListLoading = createSelector(
  selectForms,
  (form) => form?.formlistingLoading
);

export const selectSaveFormMsg = createSelector(
  selectForms,
  (form) => form?.formsavedMsg
);

export const selectSaveFormType = createSelector(
  selectForms,
  (form) => form?.formsavedType
);