import { put, takeLatest } from 'redux-saga/effects';
import { setLanguage } from './languageSlice';

// You can handle side effects here if needed
function* handleLanguageChange(action) {
  // use the action creator to create an action object
  const actionObj = setLanguage(action.payload);

  yield put(actionObj); // dispatch the action object, not the action creator
}

export default function* watchLanguageChange() {
  yield takeLatest(setLanguage.type, handleLanguageChange);
}