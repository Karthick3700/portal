import { createSlice } from "@reduxjs/toolkit";

const servicerequestInitialState = {
  data: [],
  fetchCreateStatus: {
    isLoading: false,
    status: false,
    errors: null
  },
  fetchUploadStatus: {
    isLoading: false,
    status: false,
    errors: null
  },
  fetchExcelExportStatus : {
      isLoading: false,
      status: false,
      errors: null
  },
  
  bearerToken: "",
  lastAssignedUser: null,
  sharingAlterStatus: "",
  sharingAlterMessage: ""
};

export const servicerequestSlice = createSlice({
  name: "servicerequest",
  initialState: servicerequestInitialState,
  reducers: {
    fetchservicerequestCreate: (state) => {
      state.fetchCreateStatus.isLoading = true;
      state.fetchCreateStatus.errors = null;
    },
    fetchservicerequestCreateSuccess: (state, action) => {
      state.fetchCreateStatus.isLoading = false;
      state.fetchCreateStatus.status = true;
      state.data = action.payload;
    },
    fetchservicerequestCreateFailure: (state, { payload: error }) => {
      state.fetchCreateStatus.isLoading = false;
      state.fetchCreateStatus.errors = error;
    },
    fetchservicerequestUpload: (state) => {
      state.fetchUploadStatus.isLoading = true;
      state.fetchUploadStatus.errors = null;
    },
    fetchservicerequestUploadSuccess: (state, action) => {
      state.fetchUploadStatus.isLoading = false;
      state.fetchUploadStatus.status = true;
      state.data = action.payload;
    },
    fetchservicerequestUploadFailure: (state, { payload: error }) => {
      state.fetchUploadStatus.isLoading = false;
      state.fetchUploadStatus.errors = error;
    },
    fetchExcelExport : (state) =>{
      state.fetchExcelExportStatus.isLoading =true;
      state.fetchExcelExportStatus.errors =null;
    },
    fetchExcelExportSuccess : (state, action) => {
      state.fetchExcelExportStatus.isLoading = false;
      state.fetchExcelExportStatus.status = true;
      state.data =action.payload;
    },
    fetchExcelExportFailure : (state,  {payload : error}) => {
      state.fetchExcelExportStatus.isLoading =false;
      state.fetchExcelExportStatus.errors = error;
    },
    resetStatus: (state) => {
      state.fetchUploadStatus.isLoading = false;
      state.fetchUploadStatus.status = false;
    }
  },
});

export const {
  fetchservicerequestCreate,
  fetchservicerequestCreateSuccess,
  fetchservicerequestCreateFailure,
  fetchservicerequestUpload,
  fetchservicerequestUploadSuccess,
  fetchservicerequestUploadFailure,
  fetchExcelExport,
  fetchExcelExportSuccess,
  fetchExcelExportFailure,
  resetStatus
} = servicerequestSlice.actions;

export default servicerequestSlice.reducer;