import { call, put, takeEvery } from 'redux-saga/effects';
import {
   fetchservicerequestCreate,
   fetchservicerequestCreateSuccess,
   fetchservicerequestCreateFailure,
   fetchservicerequestUpload,
   fetchservicerequestUploadSuccess,
   fetchservicerequestUploadFailure,
   fetchExcelExport,
   fetchExcelExportSuccess,
   fetchExcelExportFailure
} from './servicerequestSlice';
import baseApi from "../../app/api";
import axios from 'axios'


export function* fetchservicerequestCreateSaga(action) {
    try {
      const response = yield call(() =>
        baseApi.post("/service/request/create", action.payload)
      );
      yield put(fetchservicerequestCreateSuccess(response.data));
    } catch (error) {
      yield put(fetchservicerequestCreateFailure(error.response.data.meta.message));
    }
  }
  

  export function* fetchservicerequestUploadSaga(action) {
    try {
      const { ...createPayload } = action?.payload;
      const bearerToken = sessionStorage.getItem("token");
      var config = {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `JWT ${bearerToken}`,
          "x-access-token": `JWT ${bearerToken}`,
        },
      };

      const response = yield call(() =>
        axios
          .post(
            "http://localhost:3005/api/v1/service/request/upload",
            createPayload,
            config
          )
          .then((response) => response.data.meta)
      );

  
      yield put(fetchservicerequestUploadSuccess(response.data));
    } catch (error) {
      yield put(fetchservicerequestUploadFailure(error.response.data.meta.message));
    }
  }
   
  export function* getExcelExportSaga(action) {
    try {
      const response = yield call(() =>
        axios({
          url: "http://localhost:3005/business-info/business_info_template.xlsx",
          method: "GET",
          responseType: "blob" // Set the response type to 'blob' for handling binary data
        })
      );
  
      // Create a blob and a link for download
      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'business_info_template.xlsx');
      document.body.appendChild(link);
      link.click();
  
      // Dispatch success action if the download was successful
      yield put(fetchExcelExportSuccess(response.data));
    } catch (error) {
      // Dispatch failure action if an error occurs during the download
      yield put(fetchExcelExportFailure(error));
    }
  }