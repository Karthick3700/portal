import { combineReducers } from "@reduxjs/toolkit";
import usersReducer from "./users/slice";
import formsReducer from "./forms/formsSlice";
import dataSearchReducer from './datasearch/dataSearchSlice';
import languageReducer from './language/languageSlice';
import sharingReducer from './sharing/sharingSlice'
import sharingListReducer from "./sharinglist/sharingListSlice";
import dashboardReducer from "./dashboard/dashboardSlice";
import notificationsReducer from './notifications/notificationSlice';
import servicerequestReducer from "./servicerequest/servicerequestSlice";

export const rootReducers = combineReducers({
  users: usersReducer,
  forms: formsReducer,
  datasearch: dataSearchReducer,
  language: languageReducer,
  sharing: sharingReducer,
  sharingList: sharingListReducer,
  dashboardList: dashboardReducer,
  notifications: notificationsReducer,
  servicerequest: servicerequestReducer
});

export default rootReducers;
