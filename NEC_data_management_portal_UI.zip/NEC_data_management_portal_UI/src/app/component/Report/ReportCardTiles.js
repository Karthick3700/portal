import {
  Box,
  Typography,
  Grid,
  Card,
  CardActions,
  CardContent,
  Button,
} from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { fetchReportinPdf, fetchItemsPerReportList }
  from '../../../redux/dashboard/dashboardSlice'


const ReportCardTiles = ({ items, showLink = true }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLinkClick = (item) => {
    const link = `/reports/${item.business_domain_id}`;
    dispatch(fetchItemsPerReportList({ business_domain: item.business_domain_id }));
    navigate(link);
  };

  const getReportDownloadPdf = (check) => {
    //dispatch(fetchReportinPdf())
    if (!check.approved) {
      navigate("/access-report")
    } else {
      const currentDate = dayjs().format("DD-MM-YYYY");
      if (check.report_name.toLowerCase().includes("riyadh")) {
        window.open(`http://localhost:3005/Riyadh-Season.pdf`, "_blank");
      } else if (check.report_name.toLowerCase().includes("jeddah")) {
        window.open(`http://localhost:3005/Jeddah-Season.pdf`, "_blank");
      }
    }
  }

  const { data, fetchStatus, fetchStreamStatus, streamData, reportsData, itemsPerReportData } =
    useSelector(state => state.dashboardList);

  return (
    <Box sx={{ mt: 3 }}>
      <Grid container spacing={2}>
        {items !== undefined && Array.isArray(items.data) && items.data.map((item) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={item.business_domain_name ? item.business_domain_name : item.report_name} marginBottom={1}>
            <Card className="boxRounded2 formbuilder">
              <CardContent sx={{ p: 0 }}>
                <Box className='blockHeading'>
                  <Typography variant="h3">
                    {item.business_domain_name ? item.business_domain_name : item.report_name}
                  </Typography>
                </Box>
                <Box className='blocContent'>
                  <Typography variant="body2" color="text.secondary">
                    {item.business_domain_desc ? item.business_domain_desc : item.report_desc}
                  </Typography>
                </Box>
              </CardContent>
              {showLink && (
                <CardActions>
                  <Button
                    className='btn-nooutline border-light'
                    onClick={() => handleLinkClick(item)}

                    sx={{ p: 0 }}
                  >
                    <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                  </Button>
                </CardActions>
              )}
              {!showLink && (
                <CardActions sx={{ mt: "auto" }}>
                  <Button
                    className="btn-outline"
                    onClick={() => getReportDownloadPdf({ approved: item.isApproved, report_name: item.report_name })}

                  >
                    {item.isApproved ? "View" : "Request"}
                  </Button>
                </CardActions>
              )}
            </Card>
          </Grid>
        ))}

      </Grid>
    </Box >
  );
};

export default ReportCardTiles;