import React, { useState } from "react";
import {
  Box,
  Typography,
  Grid,
  SvgIcon,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  IconButton,
  Button,
} from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import { ReactComponent as Rightpinkarrow } from '../../../assets/rightpinkarrow.svg';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Swal from "sweetalert2";
import AlertMessage from "../../common/AlertMessage";

const CardTiles = ({ items, showLink = true }) => {
  const navigate = useNavigate();

  const [noDashboardAssociated, setNoDashboardAssociated] = useState(false);

  const handleLinkClick = (tile) => {
    const link = `/dashboard/${tile.stream_id}`;
    navigate(link);
  };


  const handleRoute = (data) => {
    //
    let stream_name = data.stream_name;
    let app_name = data.app_name;
    let app_id = data.app_id;
    let custom_property = data.custom_properties[0]?.value;
    let stream_id = data.stream_id
    const qlik_sens_mashup_api = `https://172.20.60.71/extensions/`; //https://172.20.60.71/
    const qlik_sens_api = `https://172.20.60.71/sense/app/`; //https://172.20.60.71/
    //window.localStorage.setItem("business-area-dashboard", stream_name);
    if (data.is_app_request === true) {
      localStorage.setItem("view-dashboard-name", app_name);
      if (custom_property != "" && custom_property != undefined) {

        const before = custom_property.slice(0, custom_property.indexOf('-'));
        if (before.toLowerCase() == "mashup") {
          const mashup_name_new = custom_property.slice(custom_property.indexOf('-') + 1);
          let mashup_url =
            qlik_sens_mashup_api +
            mashup_name_new +
            "/" +
            mashup_name_new +
            ".html#" +
            stream_id;
          window.open(mashup_url);
        }
        else if (before.toLowerCase() == "application") {
          let app_url = qlik_sens_api + app_id;
          window.open(app_url);
        }
        else if (before.toLowerCase() == "both") {
          mashup_application_form(
            `("Mashup / Application")`,
            `("Where You want to Go")`,
            function (resp) {
              if (resp && resp.action === 1) {
                const mashup_name_new = custom_property.slice(custom_property.indexOf('-') + 1);
                let mashup_url =
                  qlik_sens_mashup_api +
                  mashup_name_new +
                  "/" +
                  mashup_name_new +
                  ".html#" +
                  stream_id;
                window.open(mashup_url);

              }
              else if (resp && resp.action === 2) {

                // 
                let app_url = qlik_sens_api + app_id;
                window.open(app_url);


              }
            }
          );

        }
        else {

          let app_url = qlik_sens_api + app_id;
          window.open(app_url);



        }

      } else {
        // errorFormFieldsNotComplete(
        //   "Dashboard Issue",
        //   "dashboard does not exist in this application, please contact with BI Admin"
        // );
      }
    } else {
      if (custom_property) {
        localStorage.setItem("permission-dashboard-name", app_name);
        localStorage.setItem("app_id", app_id);
        localStorage.setItem("stream_name", stream_name)
        localStorage.setItem("dashboard_custom_property", JSON.stringify(data.custom_properties[0]))
        navigate("/access-dashboard")
      } else {
        setNoDashboardAssociated(true);
      }
    }
  };

  const mashup_application_form = (title, text, cb_api) => {
    Swal.fire({
      title: title,
      text: text,
      // input: "textarea",
      // inputValidator: ( result ) => !result && "Your comment is required",
      showCloseButton: true,
      // inputAttributes: {
      //   autocapitalize: "off",
      // },
      customClass: {
        //validationMessage: "my-validation-message",
        confirmButton: "bg-success btn btn-primary me-md-3",
        denyButton: "btn btn-secondary me-md-3",
      },
      buttonsStyling: false,
      inputPlaceholder: "please enter your comments",
      showCancelButton: false,
      confirmButtonText: "Mashup",
      showDenyButton: true,
      denyButtonText: `Application`,
      showLoaderOnConfirm: true,
      showLoaderOnDeny: true,
      allowOutsideClick: false,
      //returnInputValueOnDeny: true,
      preConfirm: () => {
        let respData = { action: 1 };
        cb_api(respData);
      },
      preDeny: () => {
        let respData = { action: 2 };
        cb_api(respData);
      },
    });
  };

  // Ensure items is an array before trying to map over it
  if (!Array.isArray(items)) {
    console.error(`Expected 'items' to be an array but received ${typeof items}`);
    return null;  // Render nothing if items is not an array
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Grid container spacing={2}>
        <AlertMessage
          type="error"
          message="No dashboard found for this App. Please request for a new dashboard from the menu"
          open={noDashboardAssociated}
          onClose={() => setNoDashboardAssociated(false)}
        />
        {items.map((tile) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={tile.stream_id} marginBottom={1}>
            <Card className="boxRounded2 formbuilder">
              {/* <CardActionArea> */}
              <CardContent sx={{ p: 0 }}>
                <Box className='blockHeading'>
                  <Typography variant="h3">
                    {showLink === true ? tile.stream_name : tile.app_name}
                  </Typography>
                </Box>
                <Box className='blocContent'>
                  <Typography variant="body2" color="text.secondary">
                    {
                      showLink === true
                        ? "Click the arrow link for more information"
                        : tile.app_name === "Market Analysis Level2"
                          ? tile.app_desc.slice(-85)
                          : tile.app_desc
                    }
                  </Typography>
                </Box>
              </CardContent>
              {/* </CardActionArea> */}
              {showLink && (
                <CardActions>
                  <Button
                    className='btn-nooutline border-light'
                    onClick={() => handleLinkClick(tile)}
                    sx={{ p: 0 }}
                  >
                    <span className='tdu'>Click here </span><ArrowForwardIosIcon sx={{ pl: 1, width: 14, color: '#777' }} />
                  </Button>
                </CardActions>
              )}
              {!showLink && (
                <CardActions sx={{ mt: "auto" }}>
                  {showLink ? (
                    <Button onClick={() => handleLinkClick(tile)}>
                      <ArrowForwardIosIcon className='white' sx={{ pl: 1, width: 16 }} />
                    </Button>
                  ) : (
                    <Button
                      onClick={() => handleRoute(tile)}
                      className="btn-outline"
                    >
                      {tile.is_app_request === false ? "Request" : "View"}
                    </Button>
                  )}
                </CardActions>
              )}
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box >
  );
};

export default CardTiles;