import React, { useEffect } from 'react';
import { useNavigate, useLocation, Link } from "react-router-dom";
import { Outlet } from 'react-router';
import { useSelector } from "react-redux";
import { Grid, Box, Breadcrumbs, Paper } from '@mui/material';
import Header from '../Header';
import Footer from '../Footer';
import Sidebar from '../Sidebar';
import background from '../../../assets/backgroundvideo.mp4';

const Layout = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const token = sessionStorage.getItem("token");
    const user = useSelector((state) => state.users.data);

    useEffect(() => {
        // if (location.pathname !== '/') {
        if (!user && !token) {
            navigate('/login');
        }
        // }
    }, [location.pathname, navigate, user, token])

    return (
        <Box position="relative" overflow="auto" style={{ minHeight: '100vh' }}>
            {/* <video autoPlay loop muted
                style={{
                    position: "fixed",
                    width: "100%",
                    left: "50%",
                    top: "50%",
                    minHeight: "100%",
                    minWidth: "100%",
                    objectFit: "cover",
                    transform: "translate(-50%, -50%)",
                    zIndex: "-1",
                }}>
                <source src={background} type="video/mp4" />
            </video> */}

            <Grid style={{ zIndex: 1 }}>

                <Header />

                <Box className="mainContainer">
                    <Box className="sidebar">
                        <Sidebar />
                    </Box>
                    <Box className="mainContent">
                        <Outlet />
                    </Box>
                </Box>
            </Grid>

            {/* <Footer /> */}

        </Box>
    );
}

export default Layout;
