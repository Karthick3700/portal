import {Box, Typography} from '@mui/material';
import React ,{useEffect , useState}from "react";
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

const Footer = () => {

    const { t, i18n } = useTranslation();

    // Get language from Redux store
    const language = useSelector(state => state.language);
  
    useEffect(() => {
      // Change i18n language when `language` changes
      i18n.changeLanguage(language);
    }, [i18n, language]); 
    
    return (
        <Box height='50px' position="fixed"
            bottom={0}
            bgcolor='#212121'
            width='100%'
            display='flex'
            justifyContent='center'
            alignItems='center'>
            <Box>
                <Typography sx={
                    {
                        color: '#BFBFCE',
                        //fontFamily: 'Montserrat',
                        fontSize: '14px'
                    }
                }>{t('footer')}</Typography>
            </Box>
        </Box>
    )
}

export default Footer;
