import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import io from 'socket.io-client';
import dayjs from 'dayjs';
import {
    Box,
    FormControl,
    MenuItem,
    Paper,
    Select,
    Modal,
    Avatar,
    Typography,
    Button,
    Menu,
    IconButton,
    Popover
} from '@mui/material';
import SvgIcon from '@mui/material/SvgIcon';
import { ReactComponent as Logo } from '../../../assets/logo.svg'
import { ReactComponent as NotificationBell } from '../../../assets/notificationbell.svg';
import { ReactComponent as SettingIcon } from '../../../assets/settingicon.svg';
import { ReactComponent as UserIcon } from '../../../assets/usericon.svg';
import { resetUserData } from '../../../redux/users/slice';
import { setLanguage } from '../../../redux/language/languageSlice'
import { initNotifications, addNotification, initReadNotification } from '../../../redux/notifications/notificationSlice';
import { getNotifications } from '../../../redux/notifications/notificationSelector';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import alertIcon from '../../../assets/alerticon.svg';
import NotificationSound from '../../../assets/audio/notification.wav';
import Badge from '@mui/material/Badge';
import MarkunreadIcon from '@mui/icons-material/Markunread';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';
import BellIcon from '../../../assets/img/bellicon.svg';
import avatarIcon from '../../../assets/img/avatar.png';
import ArrowIcon from '../../../assets/img/down-arrow.svg';

const socket = io('http://localhost:3006');
const audio = new Audio(NotificationSound);
audio.volume = 1;

const Header = () => {
    const [localLanguage, setLocalLanguage] = useState('en'); // renamed local state setter
    const dispatch = useDispatch();
    const userdata = sessionStorage.getItem("user");
    const user = useSelector((state) => state.users.data);
    const userdetails = JSON.parse(userdata);
    const [anchorEl, setAnchorEl] = useState(null);
    const [openNotifyPopup, setOpenNotifyPopup] = useState(false);
    const [popupNotifications, setPopupNotifications] = useState([]);
    const notifications = useSelector(getNotifications);
    const userSelectedLanguage = sessionStorage.getItem('lang');

    const unreadNotifications = notifications.filter(notification => {
        return !notification.relatedUsers.isRead;
    });

    const unreadCount = unreadNotifications.length;

    const usr_login_id = userdetails?.usr_first_name || "Sign In";

    const { t, i18n } = useTranslation();
    const navigate = useNavigate();
    const [open, setOpen] = useState(false);

    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const toggleNotifyPopup = () => {
        setOpenNotifyPopup((wasOpened) => !wasOpened);
    };

    const handleCloseNotifyPopup = () => {
        setOpenNotifyPopup(false);
    };

    const handleChange = (event) => {
        const selectedLanguage = event.target.value === "ar" ? "ar" : "en";
        setLocalLanguage(selectedLanguage);
        dispatch(setLanguage(selectedLanguage));
        sessionStorage.setItem('lang', selectedLanguage);
    };

    useEffect(() => {
        if (!userSelectedLanguage) {
            sessionStorage.setItem('lang', 'en');
        }
        else {
            setLocalLanguage(userSelectedLanguage);
        }
    }, [userSelectedLanguage])

    useEffect(() => {
        if (localLanguage === "en") {
            document.body.setAttribute('dir', 'ltr');
        } else {
            document.body.setAttribute('dir', 'rtl');
        }
        i18n.changeLanguage(localLanguage);
        return () => {
            document.body.removeAttribute('dir');
        };
    }, [i18n, localLanguage]);

    const handleLogout = () => {
        dispatch(resetUserData());
        handleClose();
    }

    const style = {
        position: 'absolute',
        top: '25%',
        left: '80%',
        transform: 'translate(0%, -150%)',
        width: 150,
        bgcolor: 'background.paper',
        borderRadius: '6px',
        boxShadow: 12,
        p: 2,
    };

    const logoutStyle = {
        color: 'rgba(0, 0, 0, 0.87)',
        textDecoration: 'none',
    }

    useEffect(() => {
        dispatch(initNotifications());
    }, [dispatch]);

    useEffect(() => {
        if (notifications?.length) {
            const firstFourNotifications = notifications.slice(0, 4);
            setPopupNotifications(firstFourNotifications);
        }
    }, [notifications]);

    const handleNotificationResponse = (data) => {
        var resp = audio.play();
        if (resp !== undefined) {
            resp.then(_ => {
                // Autoplay started!
            }).catch(error => {
                // Autoplay was prevented.
                console.log(error)
            });
        }
        dispatch(addNotification(data));
    };

    useEffect(() => {
        if (socket && userdetails?.usr_id_pk) {
            socket.on(`onNotificationResponse${userdetails.usr_id_pk}`, handleNotificationResponse);
        }

        return () => {
            socket?.off(`onNotificationResponse${userdetails?.usr_id_pk}`);
        };
    }, [socket, userdetails]);

    const markReadNotification = (notificationId, notificationUrl) => {
        dispatch(initReadNotification({ notificationId }));
        navigate(notificationUrl);
    };

    /* Start- New Notification Popover */

    const openPopOver = Boolean(anchorEl);
    const notificationPopId = openPopOver ? 'simple-popover' : undefined;

    const handlePopoverClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handlePopoverClose = () => {
        setAnchorEl(null);
    };

    /*End - */

    return (
        <Box width="100%">
            <Paper height='60px' width='100%' elevation={0}
                sx={
                    { borderRadius: '0px', position: 'relative', zIndex: 100 }
                }>
                <Box display='flex' justifyContent='space-between' alignItems='center' padding='0 8px'>
                    <Box sx={
                        { cursor: 'pointer' }
                    }>
                        <SvgIcon sx={
                            {
                                height: '50px',
                                width: '180px',
                                padding: '0 10px'
                            }
                        }
                            component={Logo}
                            onClick={() => navigate('/home')}
                            inheritViewBox />
                    </Box>
                    <Box display='flex' alignItems='center' justifyContent='flex-start'>
                        <Box className="lang-box">
                            <FormControl variant="standard" sx={{ m: 0, minWidth: 60 }}>
                                <Select value={localLanguage}
                                    onChange={handleChange}
                                    size='small'
                                    displayEmpty
                                    inputProps={{ 'aria-label': 'Without label' }}
                                    className="lang-select"
                                >
                                    <MenuItem value="en">English</MenuItem>
                                    <MenuItem value="ar">Arabic</MenuItem>
                                </Select>
                            </FormControl>
                        </Box>
                        {userdata ? (
                            <>
                             {/* Push notification popup */}
                            <Box>
                                <Box
                                    className='notification-icons' 
                                    aria-describedby={notificationPopId} 
                                    onClick={handlePopoverClick}
                                    sx={{ cursor: 'pointer' }}
                                >
                                    <Badge color="error" badgeContent={unreadCount} sx={{ lineHeight: 'normal'}}>
                                        <img src={BellIcon} alt="" />
                                    </Badge>
                                </Box>
                                <Popover
                                    id={notificationPopId}
                                    open={openPopOver}
                                    anchorEl={anchorEl}
                                    onClose={handlePopoverClose}
                                    anchorOrigin={{
                                        vertical: 'bottom',
                                        horizontal: 'right',
                                    }}
                                    transformOrigin={{
                                        vertical: 'top',
                                        horizontal: 'right',
                                    }}
                                    className='notificationPops'
                                >
                                    <Box sx={{ p: 0, width: 300 }} className='notificatioPopup topArrow'>
                                        <List sx={{ width: '100%', maxHeight: '300px', overflowY: 'auto', p: 0 }} >
                                            {popupNotifications.map((notification, index) => (
                                                <React.Fragment key={notification.notification_id}>
                                                    <ListItem
                                                        alignItems="flex-start"
                                                        sx={{ p: 0, cursor: 'pointer' }}
                                                        className={`notification ${notification.relatedUsers?.isRead ? '' : 'unread'}`}
                                                        onClick={() => {
                                                                markReadNotification(notification.notification_id, notification.relatedUsers?.redirectUrl);
                                                                handlePopoverClose()
                                                            }
                                                        }
                                                    >
                                                        <ListItemAvatar sx={{ minWidth: '40px' }}>
                                                            {notification.relatedUsers?.isRead ?
                                                                <MarkEmailReadIcon sx={{ width: '24px', height: '24px', color: '#666' }} /> :
                                                                <MarkunreadIcon sx={{ width: '24px', height: '24px', color: '#666' }} />}
                                                        </ListItemAvatar>
                                                        <ListItemText>
                                                            <Typography
                                                                sx={{ display: 'inline' }}
                                                                component="span"
                                                                variant="body2"
                                                            >
                                                                {notification.message}
                                                            </Typography>
                                                            <p className='notification-date'>{dayjs(notification.createdAt).format('llll')}</p>
                                                        </ListItemText>
                                                    </ListItem>
                                                    {index < popupNotifications.length - 1 && (
                                                        <Divider component="li" sx={{ my: 0 }} />
                                                    )}
                                                </React.Fragment>
                                            ))}
                                        </List>
                                        <Box sx={{ display: 'flex', justifyContent: 'end', p: 1, position: 'relative', height: '45px' }}>
                                            <Button
                                                variant='text'
                                                onClick={handlePopoverClose}
                                                className='btn-text btn-viewall'
                                                component={Link} to="/push-notifications"
                                            >
                                                View All
                                            </Button>
                                        </Box>
                                    </Box>
                                </Popover>
                            </Box>
                                {/* <Box className="setting-icons">
                                    <Box sx={{ cursor: 'pointer' }}>
                                        <SvgIcon sx={
                                            {
                                                height: '26px',
                                                width: '21px'

                                            }
                                        }
                                            component={SettingIcon}
                                            inheritViewBox />
                                    </Box>
                                </Box> */}
                            </>
                        ) : (<></>)}

                        <Box sx={
                            { cursor: 'pointer' }
                        }
                            display='flex'>
                            {userdata ? (
                                // <Box padding='16px'>
                                //     <SvgIcon sx={
                                //         {
                                //             height: '22px',
                                //             width: '21px',

                                //         }
                                //     }
                                //         component={UserIcon}
                                //         onClick={handleOpen}
                                //         inheritViewBox />
                                // </Box>
                                <Box className="user-menu">
                                    <Avatar
                                        onClick={handleOpen}
                                        src={avatarIcon}
                                        sx={{
                                            cursor: 'pointer',
                                            backgroundColor: '#E3EAF1',
                                            width: 30,
                                            height: 30,
                                        }}
                                    />
                                    <div>
                                        <Box>
                                            <Link
                                                className='userName'
                                                to={
                                                    user || userdetails
                                                        ? '/home'
                                                        : '/login'
                                                }
                                            >
                                                {usr_login_id}
                                            </Link>
                                            <IconButton
                                                onClick={handleOpen}
                                                id="user-button"
                                                aria-controls={open ? 'positioned-menu' : undefined}
                                                aria-haspopup="true"
                                                aria-expanded={open ? 'true' : undefined}
                                                sx={{ ml: 2, p: 0 }}
                                            >
                                                <img src={ArrowIcon} className="caret" alt="caret" />
                                            </IconButton>
                                        </Box>
                                        <Menu
                                            id="positioned-menu"
                                            aria-labelledby="positioned-button"
                                            open={open}
                                            onClose={handleClose}
                                            anchorOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'right',
                                            }}
                                            sx={{
                                                mt: 3,
                                            }}
                                        >
                                            <MenuItem>Setting</MenuItem>
                                            <MenuItem onClick={handleLogout}>Logout</MenuItem>
                                        </Menu>
                                    </div>
                                </Box>
                            ) : (<></>)}
                            {/* <Box sx={{ cursor: 'pointer' }} paddingLeft={0}>
                                <Box sx={{ padding: '16px', textTransform: 'capitalize' }}>
                                    <Link
                                        to={
                                            user || userdetails
                                                ? '/home'
                                                : '/login'
                                        }
                                    >
                                        {usr_login_id}
                                    </Link>
                                </Box>
                            </Box> */}
                        </Box>
                    </Box>
                </Box>
            </Paper>
            {/* <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Link to="/login" style={logoutStyle} onClick={handleLogout}>Log Out</Link>
                </Box>
            </Modal> */}
        </Box>
    );
};

export default Header;
