import React ,{useEffect , useState}from "react";
import { NavLink } from 'react-router-dom';
import {
  Box,
  ListItemText,
  ListItemIcon,
  List,
  ListItemButton,
  Collapse,
} from '@mui/material';
import { ExpandLess, ExpandMore } from '@mui/icons-material';
import IosShareIcon from '@mui/icons-material/IosShare';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import FormatAlignJustifyOutlinedIcon from '@mui/icons-material/FormatAlignJustifyOutlined';
import ManageSearchOutlinedIcon from '@mui/icons-material/ManageSearchOutlined';
import DashboardCustomizeOutlinedIcon from '@mui/icons-material/DashboardCustomizeOutlined';

const Sidebar = () => {
    const [open, setOpen] = React.useState(true);
    const handleClick = () => {
        setOpen(!open);
    };

    const { t, i18n } = useTranslation();

    // Get language from Redux store
    const language = useSelector(state => state.language);
  
    useEffect(() => {
      // Change i18n language when `language` changes
      i18n.changeLanguage(language);
    }, [i18n, language]);

    const handleAccessDashboardClick = () => {
        localStorage.removeItem('permission-dashboard-name');
        localStorage.setItem('initalLoad-access-dashboard', true)
        localStorage.removeItem('stream_name')
        localStorage.removeItem('dashboard_custom_property')
    };

    const handleAccessReportClick = () => {
        localStorage.setItem('permission-report-name', '');
        localStorage.setItem('initalLoad-access-report', true)
        localStorage.setItem('stream_name', '')
    };


    return (
        <Box sx={{width: '100%' , height: '100%'}}>
            <List
                sx={{ width: '100%', p:0, mt:0 }}
                component="nav"
                className='side-menu'
                >
                <ListItemButton sx={{ pl:2 }} className='side-menu-item' component={NavLink} activeClassName="active" to="/dashboard">
                    <ListItemIcon sx={{minWidth: 30}}>
                        <DashboardOutlinedIcon className='menuicon'/>
                    </ListItemIcon>
                    <ListItemText primary={t('Dashboard_Reports')} />
                </ListItemButton>   
                <ListItemButton className='side-menu-item' component={NavLink} activeClassName="active" to="/formbuilder">
                    <ListItemIcon sx={{minWidth: 30}}>
                        <FormatAlignJustifyOutlinedIcon className='menuicon' />
                    </ListItemIcon>
                    <ListItemText primary={t('Form_Builder')} />
                </ListItemButton> 
                <ListItemButton className='side-menu-item'component={NavLink} activeClassName="active" to="/Sharingandcollaboration">
                    <ListItemIcon sx={{minWidth: 30}}>
                        <IosShareIcon className='menuicon'/>
                    </ListItemIcon>
                    <ListItemText primary={t('Sharing_and_Collaboration')} />
                </ListItemButton>
                <ListItemButton sx={{ pl:2 }} className='side-menu-item' component={NavLink} activeClassName="active" to="/Datasearch">
                    <ListItemIcon sx={{minWidth: 30}}>
                        <ManageSearchOutlinedIcon className='menuicon'/>
                    </ListItemIcon>
                    <ListItemText primary={t('Data_Search')} />
                </ListItemButton>
                {/* <ListItemButton sx={{ pl:2 }} className='side-menu-item'>
                    <ListItemIcon sx={{minWidth: 30}}>
                        <ImportExportIcon className='menuicon'/>
                    </ListItemIcon>
                    <ListItemText primary="Data Import / Upload" />
                </ListItemButton> */}
                <ListItemButton 
                    onClick={handleClick} 
                    className='side-menu-item'
                >
                <ListItemIcon sx={{minWidth: 30}}>
                    <DashboardCustomizeOutlinedIcon className='menuicon' />
                </ListItemIcon>
                <ListItemText primary={t('Request_Dashboard')} />
                    {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
                <Collapse in={open} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                        <ListItemButton sx={{ pl:4 }} className='side-menu-subitem' component={NavLink} activeClassName="active" to="/request-dashboard">
                            <ListItemText primary={t('Request_New_Dashboard')} />
                        </ListItemButton>
                        {/* <ListItemButton sx={{ pl:4 }} className='side-menu-subitem' 
                            component={NavLink} 
                            activeClassName="active"
                            onClick={handleAccessDashboardClick}
                            to='/access-dashboard'>
                            <ListItemText primary={t('Access_to_Dashboard')} />
                        </ListItemButton> */}
                        <ListItemButton sx={{ pl:4 }} className='side-menu-subitem' 
                            component={NavLink} 
                            activeClassName="active"
                            onClick={handleAccessReportClick}
                            to='/access-report'>
                            <ListItemText primary="Access to Report" />
                        </ListItemButton>
                    </List>
                </Collapse>
            </List>
        </Box>
    );
};

export default Sidebar;
