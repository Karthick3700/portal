import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    msgBoxContainer: {
        display: 'flex', 
        flexDirection:'column',
        justifyContent: 'center',
        alignItems: 'center', 
        minWidth: '490px', 
        minHeight: '200px',
    },
    titleBox: {
        color: '#1F1F1F',
        textAlign: 'center',
        fontSize: '18px',
        fontStyle: 'normal',
        fontWeight: 500,
        lineHeight: '22px',
    },
    contentBox: {
        color: '#1F1F1F',
        textAlign: 'center',
        fontSize: '16px',
        fontStyle: 'normal',
        fontWeight: 400,
        lineHeight: '24px',
    },
    btnAction:{
        borderRadius: '6px !important',
        border: 'none !important',
        color: '#FFF !important',
        background: '#D34562 !important',
        padding: '8px 20px !important',
        '&:hover':{
            border: 'none !important',
            color: '#FFF !important',
            background: '#D34562 !important'
        }
    },
    btnContainer: {
        width: '100%',
        padding: '40px 0',
        display:"flex",
        justifyContent:'center',
        alignItems:'center'
    }
})

export { useStyles };