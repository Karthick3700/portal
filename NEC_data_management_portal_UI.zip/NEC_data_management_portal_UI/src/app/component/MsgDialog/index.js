import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { useStyles } from './MsgDialogStyles';
import { Box, Button, DialogActions } from '@mui/material';
import { ReactComponent as ErrorIcon } from '../../../assets/RedCross.svg';
import { ReactComponent as GreenTickIcon } from '../../../assets/GreenTickIcon.svg';
import { useNavigate } from 'react-router';

const MsgDialog=({ 
  open,
  handleClose, 
  title, 
  bodycontent,
  type,
  showGotoSpaceButton,
  url,
  btnText
})=> {
  const classes = useStyles();  
  const navigate = useNavigate();
  
  const handleBtnClick=()=>{
    navigate(url);
  }

  return (
    <React.Fragment>
      <Dialog
        minWidth={'490px'}
        height={'256px'}
        sx={{padding: 0}}
        onClose={handleClose}
        open={open}
      >
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
            <Box className={classes.msgBoxContainer}>
                <Box paddingBottom={3} >{type==='success' ? <GreenTickIcon /> : (type==='error' ? <ErrorIcon /> : '')}</Box>
                <Box paddingBottom={1} className={classes.titleBox}>{ title }</Box>
                <Box className={classes.contentBox}>{ bodycontent }</Box>
            </Box>
        </DialogContent>
        {showGotoSpaceButton && <DialogActions>
          <Box className={classes.btnContainer}>
            <Button className={classes.btnAction} onClick={handleBtnClick}>
              {btnText}
            </Button>
          </Box>
        </DialogActions>}
      </Dialog>
    </React.Fragment>
  );
}

export default MsgDialog;
