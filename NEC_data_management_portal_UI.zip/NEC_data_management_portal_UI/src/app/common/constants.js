export const defaultInputElement = [
    {
        id: 1,
        name: "text",
        type: "text",
        category: "draggedElements",
        label:'',
        value:'',
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false
    },
    {
        id: 2,
        name: "dropdown",
        options:[],
        type: "dropdown",
        category: "draggedElements",
        label:'',
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false
    },
    {
        id: 3,
        name: "date",
        type: "date",
        category: "draggedElements",
        label:'',
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false
    },
    {
        id: 4,
        name: "number",
        type: "number",
        category: "draggedElements",
        label:'',
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false
    },
    {
        id: 5,
        name: "checkbox",
        type: "checkbox",
        category: "draggedElements",
        label:'',
        field_text:'',
        field_info:'',
        field_is_req: false,
        field_is_read_only: false,
        field_is_hidden: false,
        field_is_multi_sel: false,
    }
];

export const DRAGGED = "draggedElements";
export const DROPPED = "droppedElements";

