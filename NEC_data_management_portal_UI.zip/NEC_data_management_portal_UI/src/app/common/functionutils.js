export const getformdetailsDroppedElements = (formfields) => {
  return formfields?.map((field) => {
    if (field?.field_type === "checkbox") {
      return {
        id: parseInt(field?.field_id),
        name: field?.field_type,
        type: field?.field_type,
        category: "droppedElements",
        label: field?.field_label,
        field_text: field?.field_text,
        field_info: field?.field_info,
        field_is_req: field?.field_is_req,
        field_is_read_only: field?.field_is_read_only,
        field_is_hidden: field?.field_is_hidden,
        field_is_multi_sel: field?.field_is_multi_sel,
      };
    } else if (field?.field_type === "dropdown") {
      return {
        id: parseInt(field?.field_id),
        name: field?.field_type,
        type: field?.field_type,
        category: "droppedElements",
        label: field?.field_label,
        value: "",
        options: field?.dropdownValues ?? [],
        field_is_req: field?.field_is_req,
        field_is_read_only: field?.field_is_read_only,
        field_is_hidden: field?.field_is_hidden,
        field_is_multi_sel: field?.field_is_multi_sel,
      };
    } else {
      return {
        id: parseInt(field?.field_id),
        name: field?.field_type,
        type: field?.field_type,
        category: "droppedElements",
        label: field?.field_label,
        value: "",
        field_is_req: field?.field_is_req,
        field_is_read_only: field?.field_is_read_only,
        field_is_hidden: field?.field_is_hidden,
        field_is_multi_sel: field?.field_is_multi_sel,
      };
    }
  });
};
