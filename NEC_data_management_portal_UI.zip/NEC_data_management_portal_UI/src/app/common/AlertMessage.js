import React from 'react';
import { Alert, Collapse } from '@mui/material';
import { Box } from '@mui/system';

const AlertMessage = ({ type, message, open, onClose }) => {
    return (
        <Collapse in={open}>
            <Alert severity={type} onClose={onClose} className='alertToast'>
                <Box sx={{ display: 'flex', columnGap: 2, alignItems: 'center'}}>
                    {message}
                </Box>
            </Alert>
        </Collapse>
    );
};

export default AlertMessage;
