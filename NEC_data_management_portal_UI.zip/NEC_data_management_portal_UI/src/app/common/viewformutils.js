import React from "react";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  MenuItem,
  Select,
  SvgIcon,
  TextField,
  Typography,
} from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import { ReactComponent as TextfieldIcon } from "../../assets/textfield.svg";
import { ReactComponent as RightdottedIcon } from "../../assets/rightdotted.svg";
import { ReactComponent as DropdownIcon } from "../../assets/dropdown.svg";
import { ReactComponent as DatefieldIcon } from "../../assets/datefield.svg";
import { ReactComponent as NumberfieldIcon } from "../../assets/numberfield.svg";
import { ReactComponent as CheckboxIcon } from "../../assets/checkbox.svg";
import { DesktopDatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";

export const getViewDroppedElementByType = (
  elements,
  handleLableClick,
  datevalue,
  handleDateChange,
  deleteElement,
  onSelectInputChange,
  enableCustomeInputHandler,
  selectenable,
  addDropdownOptions,
  checkBoxChangeHandler,
  addCheckboxOptions,
  textBoxChangeHandler
) => {
  const options =
    elements && elements?.name === "dropdown"
      ? elements?.options.map((el) => {
          return (
            <MenuItem value={el.value_id} contenteditable="true">
              {el.value_text}
            </MenuItem>
          );
        })
      : "";

  switch (elements.type) {
    case "text":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <Box>
              <Typography
                id="labelname"
                onBlur={(e) => handleLableClick(e, elements?.id)}
              >
                {elements?.label}
              </Typography>
            </Box> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className='btn-outline danger'
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              id="labelname"
              onBlur={(e) => handleLableClick(e, elements?.id)}
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
            >
              {elements?.label}
            </Typography>
            {/* <TextField
              fullWidth
              onChange={(e) => {
                textBoxChangeHandler(e, elements?.id);
              }}
              sx={{
                input: {
                  background: "#FCFDFF",
                  borderRadius: "6px",
                  color: "#19223B",
                },
              }}
            /> */}
          </Box>
        </>
      );
    case "dropdown":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            <Typography
              variant="body2"
              onBlur={(e) => handleLableClick(e, elements?.id)}
              sx={{mb:1, pb:1}}
            >
              {elements?.label}
            </Typography>
            <Box className='absolute-right withlabel'>
              {selectenable?.id &&
              selectenable?.id === parseInt(elements?.id) &&
              elements?.type === selectenable?.type ? (
                <Button
                  
                onClick={(e) => addDropdownOptions(e, elements)}
                  size="small"
                  variant="contained"
                  sx={{ bgcolor: "#E51448", cursor: "pointer" }}
                >
                  Add Option
                </Button>
              ) : (
                <Button
                  disabled   
                  id={elements.id}
                  onClick={deleteElement}
                  size="small"
                  variant="text"
                  className='btn-outline danger'
                >
                  Remove
                </Button>
              )}
            </Box>
          </Box>
          <Box className='relative'>
            {selectenable?.id &&
            selectenable?.id === parseInt(elements?.id) &&
            selectenable?.type === elements?.type ? (
              <Typography
                onBlur={(e) => handleLableClick(e, elements?.id)}
                sx={{
                  background: "#FCFDFF",
                  borderRadius: "6px",
                  color: "#000",
                  height: '40px !important',
                  padding: '10px 16px',
                  border: "1px solid #c2c2c4",
                  outline: 0,
                  width: '80%',
                }}
              >
                {elements?.label}
            </Typography>

              // <TextField
              //   fullWidth
              //   id={`${elements?.id}text`}
              //   onChange={(e) => onSelectInputChange(e, elements)}
              //   sx={{
              //     input: {
              //       background: "#FCFDFF",
              //       borderRadius: "6px",
              //       color: "#19223B",
              //     },
              //   }}
              // />
            ) : (
            <FormControl fullWidth>
              <Select
                sx={{ backgroundColor: "#FCFDFF", color: "#19223B" }}
                value={"English"}
                inputProps={{
                  MenuProps: {
                    MenuListProps: {
                      sx: {
                        backgroundColor: "#FCFDFF",
                        color: "#19223B",
                      },
                    },
                  },
                }}
                fullWidth
                // onChange={handleChange}
                size="small"
                displayEmpty
              >
                <MenuItem
                  onClick={() =>
                    enableCustomeInputHandler(elements?.id, elements?.name)
                  }
                >
                  [Type your custom input]
                </MenuItem>
                {options}
              </Select>
            </FormControl>
            )}
          </Box>
        </>
      );
    case "date":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <Box>
              <Typography
                id="labelname"
                onBlur={(e) => handleLableClick(e, elements?.id)}
              >
                {elements?.label}
              </Typography>
            </Box> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className='btn-outline danger'
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              id="labelname"
              onBlur={(e) => handleLableClick(e, elements?.id)}
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
            >
              {elements?.label}
            </Typography>
          </Box>
          {/* <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              disabled  
              inputFormat="DD/MM/YYYY"
              value={datevalue}
              sx={{
                input: {
                  background: "#FCFDFF",
                  svg: { background: "red" },
                  borderRadius: "6px",
                  color: "#19223B",
                },
              }}
              slotProps={{ textField: { fullWidth: true } }}
              onChange={handleDateChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider> */}
        </>
      );
    case "number":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <Box>
              <Typography
                id="labelname"
                onBlur={(e) => handleLableClick(e, elements?.id)}
              >
                {elements?.label}
              </Typography>
            </Box> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className='btn-outline danger'
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              id="labelname"
              onBlur={(e) => handleLableClick(e, elements?.id)}
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
            >
              {elements?.label}
            </Typography>
            {/* <TextField
              fullWidth 
              type="number"
              sx={{
                input: {
                  background: "#FCFDFF",
                  borderRadius: "6px",
                  color: "#19223B",
                },
              }}
            /> */}
          </Box>
        </>
      );
    case "checkbox":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <Typography
              //onBlur={(e) => handleLableClick(e, elements?.id)}
            >
              {elements?.label ?? 'Checkbox'}
            </Typography> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={(e) => addCheckboxOptions(e, elements)}
                size="small"
                variant="contained"
                sx={{
                  bgcolor: "#E51448",
                  marginRight: "16px",
                  cursor: "pointer"
                }}
                className="btn-nooutline"
              >
                Add
              </Button>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className='btn-outline danger'
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
            //   onBlur={(e) => handleLableClick(e, elements?.id)}
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
            >
              {elements?.label ?? 'Checkbox'}
            </Typography>
          </Box>
          {/* <Typography>Label*</Typography>
          <TextField
            name="field_info"
            fullWidth
            disabled 
            onChange={(e) =>
              checkBoxChangeHandler(e, elements?.id, "field_info")
            }
            sx={{
              input: {
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#19223B",
              },
            }}
          />
          <Typography>Info - Text</Typography>
          <TextField
            name="field_text"
            fullWidth
            disabled 
            onChange={(e) => checkBoxChangeHandler(e, elements?.id, "field_text")}
            sx={{
              input: {
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#19223B",
              },
            }}
          />
          <Typography>Settings</Typography> */}
          <FormControlLabel
            className="formLabel"
            label="Required"
            control={
              <Checkbox
                disabled 
                name="field_is_req"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_req")
                }
                defaultChecked={ elements?.field_is_req }
              />
            }
          />
          <FormControlLabel
            className="formLabel"
            label="Read Only"
            control={
              <Checkbox
                disabled 
                defaultChecked={elements?.field_is_read_only}
                name="field_is_read_only"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_read_only")
                }
              />
            }
          />
          <FormControlLabel
            className="formLabel"
            label="Hidden Field"
            control={
              <Checkbox
                disabled 
                defaultChecked={elements?.field_is_hidden}
                name="field_is_hidden"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_hidden")
                }
              />
            }
          />
        </>
      );

    default:
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            <Box>
              <Typography
                id="labelname"
                onBlur={(e) => handleLableClick(e, elements?.id)}
              >
                Form Name
              </Typography>
            </Box>
            <Box>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className='btn-outline danger'
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box paddingBottom={2}>
            <Button
              id={elements.id}
              onClick={deleteElement}
              size="small"
              variant="text"
              className='btn-outline danger'
            >
              Remove
            </Button>
          </Box>
        </>
      );
  }
};

export const getDraggedElementByType = (type) => {
  switch (type) {
    case "text":
      return (
        <>
          <SvgIcon
            sx={{ height: "20px", width: "20px", alignItems: "center" }}
            component={TextfieldIcon}
            inheritViewBox
          />
          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Text Field
          </Typography>
          <SvgIcon
            sx={{ height: "20px", width: "20px" }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );
    case "dropdown":
      return (
        <>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
              alignItems: "center",
            }}
            component={DropdownIcon}
            inheritViewBox
          />

          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Dropdown
          </Typography>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
            }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );
    case "date":
      return (
        <>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
              alignItems: "center",
            }}
            component={DatefieldIcon}
            inheritViewBox
          />

          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Date Field
          </Typography>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
            }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );
    case "number":
      return (
        <>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
              alignItems: "center",
            }}
            component={NumberfieldIcon}
            inheritViewBox
          />

          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Number Field
          </Typography>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
            }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );
    case "checkbox":
      return (
        <>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
              alignItems: "center",
            }}
            component={CheckboxIcon}
            inheritViewBox
          />

          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Checkbox
          </Typography>
          <SvgIcon
            sx={{
              height: "20px",
              width: "20px",
            }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );

    default:
      return (
        <>
          <SvgIcon
            sx={{ height: "20px", width: "20px", alignItems: "center" }}
            component={TextfieldIcon}
            inheritViewBox
          />
          <Typography
            sx={{
              color: "#3C3C3C",
              fontSize: "15px",
            }}
          >
            Text Field
          </Typography>
          <SvgIcon
            sx={{ height: "20px", width: "20px" }}
            component={RightdottedIcon}
            inheritViewBox
          />
        </>
      );
  }
};
