import React from "react";
import {
  Box,
  Button,
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
  SvgIcon,
  TextField,
  Typography,
} from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import { ReactComponent as TextfieldIcon } from "../../assets/textfield.svg";
import { ReactComponent as RightdottedIcon } from "../../assets/rightdotted.svg";
import { ReactComponent as DropdownIcon } from "../../assets/dropdown.svg";
import { ReactComponent as DatefieldIcon } from "../../assets/datefield.svg";
import { ReactComponent as NumberfieldIcon } from "../../assets/numberfield.svg";
import { ReactComponent as CheckboxIcon } from "../../assets/checkbox.svg";
import { DesktopDatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import editIcon from "../../assets/img/edit.svg";
import removeIcon from "../../assets/img/remove.svg";
import moveIcon from "../../assets/img/moveicon.svg";
import textfieldIcon2 from "../../assets/img/textfield.svg";
import dropdownIcon from "../../assets/img/dropdown.svg";
import datefieldIcon from "../../assets/img/datefield.svg";
import numListIcon from "../../assets/img/numlist.svg";
import checkboxIcon from "../../assets/img/checkbox.svg";

export const getDroppedElementByType = (
  elements,
  handleLableClick,
  datevalue,
  handleDateChange,
  deleteElement,
  onSelectInputChange,
  enableCustomeInputHandler,
  selectenable,
  addDropdownOptions,
  checkBoxChangeHandler,
  addCheckboxOptions,
  textBoxChangeHandler,
  tempCheckboxInput,
  chkoptionDone,
  enableDomainInputHandler,
  domainDataListingLength
) => {
  const options =
    elements && elements?.name === "dropdown"
      ? elements?.options.map((el) => {
        return (
          <MenuItem value={el.value_id} contenteditable="true">
            {el.value_text}
          </MenuItem>
        );
      })
      : "";

  switch (elements.type) {
    case "text":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <InputLabel>Enter Labelname  </InputLabel> */}
            {/* <div className="d-flex flex-row align-items-center">
              <Typography
                id="labelname"
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                }}
                onBlur={(e) => handleLableClick(e, elements?.id)}
                contenteditable="true"
              >
                {elements?.label || "Enter Labelname"}
              </Typography>
            </div> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className="btn-outline danger"
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            {/* <TextField
              fullWidth
              placeholder="Enter here..."
              onChange={(e) => {
                textBoxChangeHandler(e, elements?.id);
              }}
              sx={{
                input: {
                  background: "#FCFDFF",
                  borderRadius: "6px",
                  color: "#fff",
                  border: "1px solid #E3EAF1",
                },
              }}
            /> */}
            <Typography
              id="labelname"
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
              onBlur={(e) => handleLableClick(e, elements?.id)}
              contenteditable="true"
            >
              {elements?.label || "Text Label"}
            </Typography>
            <img src={editIcon} className="edit-icon absolute-left" />
          </Box>
        </>
      );
    case "dropdown":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <InputLabel>Enter Labelname </InputLabel> */}
            <Box className="d-flex flex-row align-items-center" sx={{ mb: 1 }}>
              <Typography
                variant="body2"
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                  outline: 'none'
                }}
                contenteditable="true"
                onBlur={(e) => handleLableClick(e, elements?.id)}
              >
                {elements?.label || "Dropdown Label"}
              </Typography>
              <img src={editIcon} className="edit-icon" />
            </Box>
            <Box className='absolute-right withlabel'>
              {selectenable?.id &&
                selectenable?.id === parseInt(elements?.id) &&
                elements?.type === selectenable?.type ? (
                <Button
                  onClick={(e) => addDropdownOptions(e, elements)}
                  size="small"
                  variant="contained"
                  className="btn-nooutline"
                  sx={{ cursor: "pointer" }}
                >
                  Add Option
                </Button>
              ) : (
                <Button
                  id={elements.id}
                  onClick={deleteElement}
                  size="small"
                  variant="text"
                  className="btn-outline danger"
                >
                  Remove
                </Button>
              )}
            </Box>
          </Box>
          <Box className='relative'>
            {selectenable?.id &&
              selectenable?.id === parseInt(elements?.id) &&
              selectenable?.type === elements?.type ? (
              <TextField
                fullWidth
                id={`${elements?.id}text`}
                onChange={(e) => onSelectInputChange(e, elements)}
                sx={{
                  input: {
                    background: "#fff",
                    borderRadius: "6px",
                    color: "#000",
                  },
                }}
              />
            ) : (
              <FormControl fullWidth>
                <Select
                  contenteditable="true"
                  sx={{ backgroundColor: "#FCFDFF", color: "#9196A7" }}
                  value={"English"}
                  inputProps={{
                    MenuProps: {
                      MenuListProps: {
                        sx: {
                          color: "#3E4174",
                          border: "1px solid #E3EAF1",
                        },
                      },
                    },
                  }}
                  fullWidth
                  // onChange={handleChange}
                  size="small"
                  displayEmpty
                >
                  <MenuItem
                    onClick={() =>
                      enableCustomeInputHandler(elements?.id, elements?.name)
                    }
                  >
                    [Type your custom input]
                  </MenuItem>
                  {domainDataListingLength > 0 &&
                    <MenuItem
                      onClick={() =>
                        enableDomainInputHandler(
                          elements?.id,
                          elements?.name,
                          elements
                        )
                      }
                    >
                      [Get Domain Value]
                    </MenuItem>
                  }
                  {options}
                </Select>
              </FormControl>
            )}
          </Box>
        </>
      );
    case "date":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            <div className="d-flex flex-row align-items-center">
              {/* <InputLabel>Enter Labelname </InputLabel> */}
              {/* <Typography
                id="labelname"
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                }}
                onBlur={(e) => handleLableClick(e, elements?.id)}
                contenteditable="true"
              >
                {elements?.label || "Enter Labelname"}
              </Typography> */}
            </div>
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className="btn-outline danger"
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              id="labelname"
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
              onBlur={(e) => handleLableClick(e, elements?.id)}
              contenteditable="true"
            >
              {elements?.label || "Date Label"}
            </Typography>
            <img src={editIcon} className="edit-icon absolute-left" />
            {/* <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              inputFormat="DD/MM/YYYY"
              value={datevalue}
              sx={{
                input: {
                  background: "#FCFDFF",
                  svg: { background: "red" },
                  borderRadius: "6px",
                  color: "#fff",
                },
              }}
              slotProps={{ textField: { fullWidth: true } }}
              onChange={handleDateChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider> */}
          </Box>
        </>
      );
    case "number":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <div className="d-flex flex-row align-items-center">
              <InputLabel>Enter Labelname </InputLabel>
              <Typography
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                }}
                id="labelname"
                onBlur={(e) => handleLableClick(e, elements?.id)}
                contenteditable="true"
              >
                {elements?.label || "Enter Labelname"}
              </Typography>
            </div> */}
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                variant="text"
                className="btn-outline danger"
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
              id="labelname"
              onBlur={(e) => handleLableClick(e, elements?.id)}
              contenteditable="true"
            >
              {elements?.label || "Number Label"}
            </Typography>
            <img src={editIcon} className="edit-icon absolute-left" />
            {/* <TextField
              fullWidth
              type="number"
              sx={{
                input: {
                  background: "#fcfdff",
                  borderRadius: "6px",
                  color: "#fff",
                },
              }}
            /> */}
          </Box>
        </>
      );
    case "checkbox":
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            {/* <div className="d-flex flex-row align-items-center">
              <InputLabel>Enter Labelname </InputLabel>
              <Typography
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                }}
                onBlur={(e) => handleLableClick(e, elements?.id)}
                contenteditable="true"
              >
                {elements?.label.trim() || "Enter Labelname"}
              </Typography>
            </div> */}
            <Box className='absolute-right'>
              {/* <Button
                id={elements.id}
                onClick={(e) => addCheckboxOptions(e, elements)}
                size="small"
                variant="contained"
                className="btn-nooutline"
                sx={{
                  cursor: "pointer",
                  marginRight: "16px",
                }}
                disabled={!tempCheckboxInput?.id}
              >
                Done
              </Button> */}
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className="btn-outline danger"
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='relative'>
            <Typography
              sx={{
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#000",
                height: '40px !important',
                padding: '10px 16px',
                border: "1px solid #c2c2c4",
                outline: 0,
                width: '80%',
              }}
              onBlur={(e) => handleLableClick(e, elements?.id)}
              contenteditable="true"
            >
              {elements?.label.trim() || "Checkbox Label"}
            </Typography>
            <img src={editIcon} className="edit-icon absolute-left" />
          </Box>
          {/* <Typography sx={{ mt: 1 }}>Label*</Typography> */}
          {/* <TextField
            name="field_info"
            fullWidth
            onChange={(e) =>
              checkBoxChangeHandler(e, elements?.id, "field_info")
            }
            sx={{
              input: {
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#fff",
              },
            }}
          /> */}
          {/* <Typography sx={{ mt: 1 }}>Info - Text</Typography>
          <TextField
            name="field_text"
            fullWidth
            onChange={(e) =>
              checkBoxChangeHandler(e, elements?.id, "field_text")
            }
            sx={{
              input: {
                background: "#FCFDFF",
                borderRadius: "6px",
                color: "#fff",
              },
            }}
          /> */}
          {/* <Typography sx={{ mt: 1 }}>Settings</Typography> */}
          <FormControlLabel
            label="Required"
            control={
              <Checkbox
                name="field_is_req"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_req")
                }
                defaultChecked={elements?.field_is_req}
              />
            }
            className="formLabel"
          />
          <FormControlLabel
            label="Read Only"
            control={
              <Checkbox
                defaultChecked={elements?.field_is_read_only}
                name="field_is_read_only"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_read_only")
                }
              />
            }
            className="formLabel"
          />
          <FormControlLabel
            label="Hidden Field"
            control={
              <Checkbox
                defaultChecked={elements?.field_is_hidden}
                name="field_is_hidden"
                onChange={(e) =>
                  checkBoxChangeHandler(e, elements?.id, "field_is_hidden")
                }
              />
            }
            className="formLabel"
          />
        </>
      );

    default:
      return (
        <>
          <Box display="flex" justifyContent="space-between">
            <div className="d-flex flex-row align-items-center">
              <InputLabel>Enter Labelname </InputLabel>
              <Typography
                id="labelname"
                sx={{
                  marginBottom: "8px",
                  padding: "0 8px 0 0",
                }}
                onBlur={(e) => handleLableClick(e, elements?.id)}
                contenteditable="true"
              >
                Form Name <img src={editIcon} className="edit-icon" />
              </Typography>
            </div>
            <Box className='absolute-right'>
              <Button
                id={elements.id}
                onClick={deleteElement}
                size="small"
                variant="text"
                className="btn-outline danger"
              >
                Remove
              </Button>
            </Box>
          </Box>
          <Box className='absolute-right'>
            <Button
              id={elements.id}
              onClick={deleteElement}
              size="small"
              variant="text"
              className="btn-outline danger"
            >
              Remove
            </Button>
          </Box>
        </>
      );
  }
};

export const getDraggedElementByType = (type) => {
  switch (type) {
    case "text":
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={textfieldIcon2} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Text Field
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );
    case "dropdown":
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={dropdownIcon} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Dropdown
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );
    case "date":
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={datefieldIcon} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Date Field
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );
    case "number":
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={numListIcon} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Number Field
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );
    case "checkbox":
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={checkboxIcon} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Checkbox
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );

    default:
      return (
        <>
          <Box className="formField">
            <div className="fieldIcon">
              <img src={textfieldIcon2} />
            </div>
            <Typography
              sx={{
                color: "#3C3C3C",
                fontSize: "15px",
              }}
            >
              Text Field
            </Typography>
          </Box>
          <Box className="moveField">
            <img src={moveIcon} />
          </Box>
        </>
      );
  }
};
