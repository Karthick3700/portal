import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
    fieldlabels:{
        width: '300px',
        border: 'solid 1px #ccc',
        borderRadius: '4px',
        padding: '8px',
        '&p:empty:before': {
            content: 'attr(data-placeholder)',
            color: 'gray'
        }
    }
})

export { useStyles };