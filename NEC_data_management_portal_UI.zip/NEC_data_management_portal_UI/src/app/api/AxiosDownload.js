import axios from "axios";

const bearerToken = sessionStorage.getItem('token');

export const AxiosDownload = axios.create({
  baseURL : 'http://localhost:3005/',
  headers: {
    responseType: 'arraybuffer',
    Authorization: `JWT ${bearerToken}`,
    'x-access-token': `JWT ${bearerToken}`,
  
     
    timeout : 30000,
  }, 
});
