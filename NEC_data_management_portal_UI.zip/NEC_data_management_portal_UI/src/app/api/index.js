import axios from "axios";

const baseApi = axios.create({
  baseURL: 'http://localhost:3005/api/v1/',
  headers: {
    'Content-Type': 'application/json',
    timeout: 30000,
  },
});

baseApi.interceptors.request.use((config) => {
  const bearerToken = sessionStorage.getItem('token');
  if (bearerToken) {
    config.headers.Authorization = `JWT ${bearerToken}`;
    config.headers['x-access-token'] = `JWT ${bearerToken}`;
  }
  return config;
});

export default baseApi;
