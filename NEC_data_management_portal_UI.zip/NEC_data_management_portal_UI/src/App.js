import React, { useEffect } from "react";
import { Route, Routes } from "react-router";
import Dashboard from "./features/Dashboard";
import Formbuilder from "./features/Formbuilder";
import Sharingandcollaboration from "./features/Sharing-and-Collaboration";
import sharingView from "./features/Sharing-and-Collaboration/sharingView";
import Datasearch from "./features/DataSearch";
import HomePage from "./features/Homepage";
import AddForm from "./features/Formbuilder/AddForm";
import LoginPage from "./features/Login";
import Landingpage from "./features/Landingpage";
import EditForm from "./features/Formbuilder/EditForm";
import ViewForm from "./features/Formbuilder/ViewForm";
import ForgotPwd from "./features/Login/ForgotPwd";
import Signup from "./features/Login/Signup";
import Chat from "./features/DataSearch/Chat";
import AddSpace from "./features/Sharing-and-Collaboration/AddSpace";
import AddUser from "./features/Sharing-and-Collaboration/AddSpace/components/AddUsers";
import AuthLayout from "./app/component/AuthLayout";
import Layout from "./app/component/Layout";
import AddSharing from "./features/Sharing-and-Collaboration/AddSharing";
import ResetPwd from "./features/Login/ResetPwd";
import RequestNewDashboard from "./features/RequestNewDashboard";
import AccessDashboard from "./features/AccessDashboard";
import AccessReport from "./features/AccessReport";
import PushNotifications from "./features/PushNotifications";


const App = () => {

  return (
    <Routes>
      <Route element={<AuthLayout />}>
        <Route exact path="/" Component={LoginPage} />
        <Route path="/login" Component={LoginPage} />
        <Route path="/forgot-password" Component={ForgotPwd} />
        <Route path="/reset-password" Component={ResetPwd} />
        <Route path="/signup" Component={Signup} />
      </Route>
      <Route Component={Layout}>
        <Route path="/home" Component={HomePage} />
        <Route path="/dashboard" Component={Dashboard} />
        <Route path="/report" Component={Dashboard} />
        <Route path="/dashboard/:stream_id" Component={Dashboard} />
        <Route path="/reports/:business_domain_id" Component={Dashboard} />
        <Route path="/formbuilder" Component={Formbuilder} />
        <Route path="/addform" Component={AddForm} />
        <Route path="/formbuilder/editform/:id" Component={EditForm} />
        <Route path="/formbuilder/viewform/:id" Component={ViewForm} />
        <Route
          path="/Sharingandcollaboration"
          Component={Sharingandcollaboration}
        />
        <Route path="/datasearch" Component={Datasearch} />
        <Route path="/chat" Component={Chat} />
        <Route path="/addspace" Component={AddSpace} />
        <Route path="/adduser" Component={AddUser} />
        <Route path="/sharingview" Component={sharingView} />
        <Route path="/addsharing/:id" Component={AddSharing} />
        <Route path="/request-dashboard" Component={RequestNewDashboard} />
        <Route path="/access-dashboard" Component={AccessDashboard} />
        <Route path="/access-report" Component={AccessReport} />
        <Route path="/push-notifications" Component={PushNotifications} />
      </Route>
    </Routes>
  );
};

export default App;
